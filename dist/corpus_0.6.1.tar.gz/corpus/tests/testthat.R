library(testthat)
library(corpus)

test_check("corpus")
