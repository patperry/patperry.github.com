Todo
====

## Features

  * Some sort of index for allowing KWIC queries.
