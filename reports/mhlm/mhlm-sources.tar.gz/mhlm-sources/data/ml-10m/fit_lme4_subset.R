

library("methods", quietly=TRUE)
library("lme4", quietly=TRUE, warn.conflicts=FALSE)
library("nlme", quietly=TRUE, warn.conflicts=FALSE)
library("optimx", quietly=TRUE, warn.conflicts=FALSE)


data <- readRDS("data.rds")

set.seed(31337)
ptest <- 0.05
subset.test <- (runif(nrow(data)) < ptest)
test <- subset(data, subset.test)
ntest <- nrow(test)
train <- subset(data, !subset.test)
rm("data")


control <- glmerControl(calc.derivs = FALSE,
                        check.nobs.vs.nlev = "ignore",
                        check.nlev.gtr.1 = "ignore",
                        check.nobs.vs.nRE = "ignore",
                        check.rankX = "stop.deficient",
                        check.scaleX = "warning")
nAGQ <- 0L

log10.pkeep <- seq(-5, 0, by=0.5)
pkeep <- 10^(log10.pkeep)

time <- list()
pred <- list()

nobs <- list()
ngroup <- list()


get.time <- function(t) {
    with(as.list(summary(t)), user + system)
}


for (i in seq_along(pkeep)) {
    data <- readRDS("data.rds")
    train <- subset(data, !subset.test)

    set.seed(0)
    s <- (runif(nrow(train)) < pkeep[[i]])
    train.s <- subset(train, s)
    train.s$group <- droplevels(train.s$group)
    nobs[[i]] <- nrow(train.s)
    ngroup[[i]] <- nlevels(train.s$group)
    rm("data", "train")

    time[[i]] <- system.time({
        model <- with(train.s,
                      glmer(y ~ x - 1 + (z - 1 | group), family=binomial,
                            control=control, nAGQ=nAGQ))
    })

    mu <- predict(model, test, type="response", allow.new.levels=TRUE)
    pred[[i]] <- mu
    rm("model")

    miss.loss <- ifelse(test$y, mu <= 0.5, mu > 0.5)
    log.loss <- -(ifelse(test$y == 1, log(mu), log(1 - mu)))
    sq.loss  <- ifelse(test$y == 1, (1 - mu)^2, (mu)^2)

    cat("pkeep      : ", pkeep[[i]], "\n", sep="")
    cat("time       : ", get.time(time[[i]]), "\n", sep="")
    cat("log.loss   : ", mean(log.loss),
        " (", sd(log.loss)/sqrt(ntest),")\n", sep="")
    cat("miss.loss  : ", mean(miss.loss),
        " (", sd(miss.loss)/sqrt(ntest), ")\n", sep="")
    cat("sq.loss    : ", mean(sq.loss),
        " (", sd(sq.loss)/sqrt(ntest), ")\n", sep="")
    cat("---\n")
}


results <- data.frame(pkeep = unlist(pkeep),
                      nobs = unlist(nobs),
                      ngroup = unlist(ngroup),
                      time = sapply(time, get.time),
                      predict = I(pred))

saveRDS(results, "lme4-subset.rds")

# pkeep      : 1e-05
# time       : 4.797
# log.loss   : 0.8175796 (0.001533484)
# miss.loss  : 0.3552078 (0.0006767867)
# sq.loss    : 0.2573168 (0.0004481525)
# ---
# pkeep      : 3.162278e-05
# time       : 8.311
# log.loss   : 0.660211 (0.00101046)
# miss.loss  : 0.3341893 (0.0006670714)
# sq.loss    : 0.2231554 (0.0003619044)
# ---
# pkeep      : 1e-04
# time       : 19.775
# log.loss   : 0.5964494 (0.0006558916)
# miss.loss  : 0.3181024 (0.0006586333)
# sq.loss    : 0.2048091 (0.0002740814)
# ---
# pkeep      : 0.0003162278
# time       : 44.685
# log.loss   : 0.5941063 (0.0006061381)
# miss.loss  : 0.3182604 (0.0006587206)
# sq.loss    : 0.2040889 (0.0002596097)
# ---
# pkeep      : 0.001
# time       : 128.004
# log.loss   : 0.5919664 (0.0005884911)
# miss.loss  : 0.3157625 (0.0006573314)
# sq.loss    : 0.2031489 (0.0002526945)
# ---
# pkeep      : 0.003162278
# time       : 1374.952
# log.loss   : 0.588836 (0.000587799)
# miss.loss  : 0.3134327 (0.0006560159)
# sq.loss    : 0.2018389 (0.0002526166)
# ---
# pkeep      : 0.01
# time       : 3775.604
# log.loss   : 0.5811861 (0.0005790889)
# miss.loss  : 0.3066731 (0.00065209)
# sq.loss    : 0.1987036 (0.0002491905)
# ---
# pkeep      : 0.03162278
# time       : 1412.691
# log.loss   : 0.569456 (0.0006089679)
# miss.loss  : 0.2981337 (0.0006468944)
# sq.loss    : 0.1939581 (0.0002575804)
# ---
# pkeep      : 0.1
# time       : 2874.1
# log.loss   : 0.5555789 (0.0006387539)
# miss.loss  : 0.2884464 (0.0006406739)
# sq.loss    : 0.1883964 (0.0002655213)
# ---
# pkeep      : 0.3162278
# time       : 10333.12
# log.loss   : 0.5422244 (0.0006587338)
# miss.loss  : 0.278861 (0.0006341676)
# sq.loss    : 0.1830538 (0.0002698985)
# ---
# pkeep      : 1
# time       : 36539.82
# log.loss   : 0.5323218 (0.0006706252)
# miss.loss  : 0.2718835 (0.0006292055)
# sq.loss    : 0.1791476 (0.0002721694)
# ---

