
library("inline", quietly=TRUE)
source("../../code/sgd.fit.R")

data <- readRDS("data.rds")

set.seed(31337)
ptest <- 0.05
subset.test <- (runif(nrow(data)) < ptest)
test <- subset(data, subset.test)
ntest <- nrow(test)
train <- subset(data, !subset.test)
rm("data")

log10.pkeep <- seq(-5, 0, by=0.5)
pkeep <- 10^(log10.pkeep)

time.cv <- list()
time.fit <- list()
pred <- list()

nobs <- list()
ngroup <- list()


get.time <- function(t) {
    with(as.list(summary(t)), user + system)
}


for (i in seq_along(pkeep)) {
    data <- readRDS("data.rds")
    train <- subset(data, !subset.test)
    
    set.seed(0)
    s <- (runif(nrow(train)) < pkeep[[i]])
    train.s <- subset(train, s)
    train.s$group <- droplevels(train.s$group)
    nobs[[i]] <- nrow(train.s)
    ngroup[[i]] <- nlevels(train.s$group)
    rm("data", "train")

    time.cv[[i]] <- system.time({
        cv <- with(train.s, hglm.sgd.cv(x, z, y, group, family=binomial()))
    })

    penalty <- cv$optimal.penalty

    time.fit[[i]] <- system.time({
        fit <- with(train.s, hglm.sgd.fit(x, z, y, group, family=binomial(),
                                          penalty = penalty, path=TRUE))
    })
    rm("train.s")

    eta <- test$x %*% fit$fixef
    group.ix <- match(test$group, rownames(fit$ranef))
    old <- !is.na(group.ix)
    eta[old] <- eta[old] + rowSums(test$z[old,,drop=FALSE]
                                   * fit$ranef[group.ix[old],,drop=FALSE])
    mu <- binomial()$linkinv(eta)
    rm("fit")

    pred[[i]] <- mu

    miss.loss <- ifelse(test$y, mu <= 0.5, mu > 0.5)
    log.loss <- -(ifelse(test$y == 1, log(mu), log(1 - mu)))
    sq.loss  <- ifelse(test$y == 1, (1 - mu)^2, (mu)^2)

    cat("pkeep      : ", pkeep[[i]], "\n", sep="")
    cat("cv time    : ", get.time(time.cv[[i]]), "\n", sep="")
    cat("fit time   : ", get.time(time.fit[[i]]), "\n", sep="")
    cat("log.loss   : ", mean(log.loss),
        " (", sd(log.loss)/sqrt(ntest),")\n", sep="")
    cat("miss.loss  : ", mean(miss.loss),
        " (", sd(miss.loss)/sqrt(ntest), ")\n", sep="")
    cat("sq.loss    : ", mean(sq.loss),
        " (", sd(sq.loss)/sqrt(ntest), ")\n", sep="")
    cat("---\n")
}

results <- data.frame(pkeep = unlist(pkeep),
                      nobs = unlist(nobs),
                      ngroup = unlist(ngroup),
                      time.cv = sapply(time.cv, get.time),
                      time.fit = sapply(time.fit, get.time),
                      predict = I(pred))

saveRDS(results, "sgd-subset.rds")

# pkeep      : 1e-05
# cv time    : 0.257
# fit time   : 0.008
# log.loss   : 0.6141852 (0.0004973711)
# miss.loss  : 0.3355832 (0.000667761)
# sq.loss    : 0.2127646 (0.0002240872)
# ---
# pkeep      : 3.162278e-05
# cv time    : 0.366
# fit time   : 0.012
# log.loss   : 0.6009053 (0.0004747062)
# miss.loss  : 0.3209662 (0.0006602007)
# sq.loss    : 0.2068869 (0.0002130963)
# ---
# pkeep      : 1e-04
# cv time    : 0.932
# fit time   : 0.026
# log.loss   : 0.6000839 (0.0004899517)
# miss.loss  : 0.3207542 (0.0006600857)
# sq.loss    : 0.2065622 (0.0002179045)
# ---
# pkeep      : 0.0003162278
# cv time    : 3.698
# fit time   : 0.098
# log.loss   : 0.6001403 (0.0004686707)
# miss.loss  : 0.3199142 (0.0006596283)
# sq.loss    : 0.2065235 (0.0002103032)
# ---
# pkeep      : 0.001
# cv time    : 11.659
# fit time   : 0.332
# log.loss   : 0.6007478 (0.0004837764)
# miss.loss  : 0.3219001 (0.0006607057)
# sq.loss    : 0.2068498 (0.000215675)
# ---
# pkeep      : 0.003162278
# cv time    : 48.36
# fit time   : 1.424
# log.loss   : 0.5979166 (0.0004585952)
# miss.loss  : 0.3172464 (0.0006581593)
# sq.loss    : 0.205579 (0.0002061206)
# ---
# pkeep      : 0.01
# cv time    : 323.689
# fit time   : 7.254
# log.loss   : 0.5903917 (0.0004780492)
# miss.loss  : 0.3111508 (0.0006547089)
# sq.loss    : 0.202497 (0.0002111873)
# ---
# pkeep      : 0.03162278
# cv time    : 1252.097
# fit time   : 26.3
# log.loss   : 0.5772435 (0.0005233283)
# miss.loss  : 0.3020535 (0.0006493123)
# sq.loss    : 0.1970874 (0.000226443)
# ---
# pkeep      : 0.1
# cv time    : 4437.46
# fit time   : 91.455
# log.loss   : 0.561731 (0.0005628185)
# miss.loss  : 0.2916342 (0.0006427597)
# sq.loss    : 0.1907531 (0.0002394314)
# ---
# pkeep      : 0.3162278
# cv time    : 16095.38
# fit time   : 318.403
# log.loss   : 0.5474323 (0.0005863364)
# miss.loss  : 0.2806949 (0.0006354399)
# sq.loss    : 0.1848893 (0.0002470123)
# ---
# pkeep      : 1
# cv time    : 60181.26
# fit time   : 1214.584
# log.loss   : 0.5381468 (0.0006170768)
# miss.loss  : 0.2744993 (0.0006310884)
# sq.loss    : 0.1811852 (0.0002566525)
# ---

