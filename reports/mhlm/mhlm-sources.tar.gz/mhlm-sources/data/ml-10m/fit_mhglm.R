
library("devtools", quietly=TRUE)
load_all("../../lib/mbest", export_all=FALSE, quiet=TRUE)

data <- readRDS("data.rds")

time <- system.time({
    fit <- with(data, mhglm.fit(x, z, y, group, family=binomial()))
})

fixef <- fixef.mhglm(fit)
ranef <- ranef.mhglm(fit)[[1]]

saveRDS(list(time=time, fit=fit, fixef=fixef, ranef=ranef),
        "mhglm.rds")

