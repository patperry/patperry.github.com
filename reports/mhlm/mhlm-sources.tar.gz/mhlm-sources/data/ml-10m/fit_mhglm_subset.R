
library("devtools", quietly=TRUE)
library("methods", quietly=TRUE)
load_all("../../lib/mbest", export_all=FALSE, quiet=TRUE)

data <- readRDS("data.rds")

set.seed(31337)
ptest <- 0.05
subset.test <- (runif(nrow(data)) < ptest)
test <- subset(data, subset.test)
ntest <- nrow(test)
train <- subset(data, !subset.test)
rm("data")

log10.pkeep <- seq(-5, 0, by=0.5)
pkeep <- 10^(log10.pkeep)

time <- list()
time.model <- list()
pred <- list()

nobs <- list()
ngroup <- list()


get.time <- function(t) {
    with(as.list(summary(t)), user + system)
}


for (i in seq_along(pkeep)) {
    data <- readRDS("data.rds")
    train <- subset(data, !subset.test)
    
    set.seed(0)
    s <- (runif(nrow(train)) < pkeep[[i]])
    train.s <- subset(train, s)
    train.s$group <- droplevels(train.s$group)
    nobs[[i]] <- nrow(train.s)
    ngroup[[i]] <- nlevels(train.s$group)
    rm("data", "train")

    time[[i]] <- system.time({
        fit <- with(train.s, mhglm.fit(x, z, y, group, family=binomial()))
    })
    rm("fit")

    time.model[[i]] <- system.time({
        model <- mhglm(y ~ x - 1 + (z - 1 | group), data = train.s,
                       family=binomial)
    })

    mu <- predict(model, test, type="response")
    rm("model")

    pred[[i]] <- mu

    miss.loss <- ifelse(test$y, mu <= 0.5, mu > 0.5)
    log.loss <- -(ifelse(test$y == 1, log(mu), log(1 - mu)))
    sq.loss  <- ifelse(test$y == 1, (1 - mu)^2, (mu)^2)

    cat("pkeep      : ", pkeep[[i]], "\n", sep="")
    cat("fit time   : ", get.time(time[[i]]), "\n", sep="")
    cat("model time : ", get.time(time.model[[i]]), "\n", sep="")
    cat("log.loss   : ", mean(log.loss),
        " (", sd(log.loss)/sqrt(ntest),")\n", sep="")
    cat("miss.loss  : ", mean(miss.loss),
        " (", sd(miss.loss)/sqrt(ntest), ")\n", sep="")
    cat("sq.loss    : ", mean(sq.loss),
        " (", sd(sq.loss)/sqrt(ntest), ")\n", sep="")
    cat("---\n")
}

results <- data.frame(pkeep = unlist(pkeep),
                      nobs = unlist(nobs),
                      ngroup = unlist(ngroup),
                      time = sapply(time.model, get.time),
                      time.fit = sapply(time, get.time),
                      predict = I(pred))

saveRDS(results, "mhglm-subset.rds")

