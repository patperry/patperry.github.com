
data <- readRDS("data.rds")

set.seed(0)

ptest <- 0.50

nobs <- nrow(data)
ntrain <- round(ptest * nobs)
train <- sample.int(nobs, ntrain)
test <- seq_len(nobs)[-train]

saveRDS(data[train,], "train.rds")
saveRDS(data[test,], "test.rds")
