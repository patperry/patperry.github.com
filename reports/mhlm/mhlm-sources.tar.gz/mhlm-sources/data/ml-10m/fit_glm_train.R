
data <- readRDS("train.rds")

time <- system.time({
    fit <- with(data, glm.fit(x, y, family=binomial()))
})

coef <- coef(fit)

saveRDS(list(time=time, fit=fit, coef=coef),
        "glm-train.rds")

