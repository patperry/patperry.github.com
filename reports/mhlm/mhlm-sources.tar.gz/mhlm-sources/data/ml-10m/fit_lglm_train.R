
library("devtools", quietly=TRUE)
load_all("../../lib/mbest", export_all=FALSE, quiet=TRUE)

data <- readRDS("train.rds")

time <- system.time({
    fit <- with(data, mbest:::rdglm.group.fit(x, y, group, family=binomial()))
})

coef <- fit$coefficients

saveRDS(list(time=time, fit=fit, coef=coef),
        "lglm-train.rds")

