# data/ml-10m/make_features.py
# --

import collections
import csv
import sys

# read in movies
with open("movie.csv", "r") as f:
    f.readline() # discard header
    movie = [tuple(r) for r in csv.reader(f)]

MOVIE_ID = 0
MOVIE_TITLE = 1
MOVIE_GENRES = 2

movie_ix = {}
for i,m in enumerate(movie):
    movie_ix[m[MOVIE_ID]] = i

# read in raw ratings
with open("rating.csv", "r") as f:
    f.readline() # discard header
    raw_rating = [tuple(r) for r in csv.reader(f)]

RAW_RATING_USER = 0
RAW_RATING_MOVIE = 1
RAW_RATING_SCORE = 2
RAW_RATING_TIMESTAMP = 3

# build user list
user = list(set([(r[RAW_RATING_USER],) for r in raw_rating]))
USER_ID = 0
user.sort(key=lambda u: int(u[USER_ID]))

user_ix = {}
for i,u in enumerate(user):
    user_ix[u[USER_ID]] = i

# normalize ratings, sort in order of timestamps
rating = [(i, user_ix[r[RAW_RATING_USER]], movie_ix[r[RAW_RATING_MOVIE]],
            float(r[RAW_RATING_SCORE]), int(r[RAW_RATING_TIMESTAMP]))
            for i,r in enumerate(raw_rating)]
del raw_rating # free up memory

RATING_ID = 0
RATING_USER_IX = 1
RATING_MOVIE_IX = 2
RATING_SCORE = 3
RATING_TIMESTAMP = 4
rating.sort(key=lambda r: r[RATING_TIMESTAMP])

rating_ix = {}
for i,r in enumerate(rating):
    rating_ix[r[RATING_ID]] = i


# recent reviews for each movie
MOVIE_WINDOW_LEN = 30
movie_y = [collections.deque(maxlen=MOVIE_WINDOW_LEN)
           for i in range(len(movie))]

# length of current positive review streak for each user
user_pos_len = [0] * len(user)
user_neg_len = [0] * len(user)

rating_var = []
RATING_VAR_USER_POS_LEN = 0 # number of user's positive reviews before the current one
RATING_VAR_USER_NEG_LEN = 1 # number of user's negative reviews before the current one
RATING_VAR_MOVIE_POS = 2 # number of recent positive reviews for the movie
RATING_VAR_MOVIE_NEG = 3 # number of recent negative reviews for the movie


for r in rating:
    u = r[RATING_USER_IX]
    pu = user_pos_len[u]
    nu = user_neg_len[u]
    
    m = r[RATING_MOVIE_IX]
    ym = movie_y[m]
    tm = len(ym)
    pm = ym.count(True)
    nm = tm - pm
    
    rating_var.append((pu,nu,pm,nm))
    
    y = r[RATING_SCORE] >= 4.0
    if y:
        user_pos_len[u] = pu + 1
        user_neg_len[u] = 0
    else:
        user_pos_len[u] = 0
        user_neg_len[u] = nu + 1
    ym.append(y)


with open("rating-feature.csv", "w") as f:
    f.write("user_pos_len,user_neg_len,movie_pos,movie_neg\n")
    w = csv.writer(f)
    
    for rid in range(len(rating)):
        i = rating_ix[rid]
        rx = rating_var[i]
        w.writerow(rx)

