

library("methods", quietly=TRUE)
library("lme4", quietly=TRUE, warn.conflicts=FALSE)
library("nlme", quietly=TRUE, warn.conflicts=FALSE)
library("optimx", quietly=TRUE, warn.conflicts=FALSE)


data <- readRDS("data.rds")

control <- glmerControl(calc.derivs = FALSE,
                        check.nobs.vs.nlev = "ignore",
                        check.nlev.gtr.1 = "ignore",
                        check.nobs.vs.nRE = "ignore",
                        check.rankX = "stop.deficient",
                        check.scaleX = "warning")
nAGQ <- 0L

time <- system.time({
    model <- with(data, glmer(y ~ x - 1 + (z - 1 | group), family=binomial,
                              control=control, nAGQ=nAGQ))
})

#      user    system   elapsed 
# 25324.993  6172.933 43701.360 
#

fixef <- fixef(model)
fixef.vcov <- as.matrix(vcov(model))

ranef <- as.matrix(ranef(model)[["group"]])

ranef.cov <- VarCorr(model)[["group"]]
attr(ranef.cov, "stddev") <- NULL
attr(ranef.cov, "correlation") <- NULL

yhat <- fitted.values(model)

converged <- is.null(model@optinfo$conv$lme4)
iter <- model@optinfo$feval


saveRDS(list(time=time, fixef=fixef, fixef.vcov=fixef.vcov,
             ranef=ranef, ranef.cov=ranef.cov, yhat=yhat,
             converged=converged, iter=iter),
        "lme4.rds")

