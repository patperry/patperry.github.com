
library("inline", quietly=TRUE)
source("../../code/sgd.fit.R")

data <- readRDS("train.rds")

cv.time <- system.time({
    cv <- with(data, hglm.sgd.cv(x, z, y, group, family=binomial()))
})

# > cv.time
#      user    system   elapsed 
# 28005.213   163.513 28695.773

penalty <- cv$optimal.penalty

# > penalty
# [1] 3.162278

time <- system.time({
    fit <- with(data, hglm.sgd.fit(x, z, y, group, family=binomial(),
                                          penalty = penalty, path=FALSE))
})

# > time
#    user  system elapsed 
# 477.734   2.533 480.297 


fixef <- fit$fixef
ranef <- fit$ranef

saveRDS(list(time=time, cv.time=cv.time, cv=cv, fit=fit, fixef=fixef,
             ranef=ranef),
        "sgd-train.rds")

