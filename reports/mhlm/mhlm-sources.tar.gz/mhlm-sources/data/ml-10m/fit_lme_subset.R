

library("nlme", quietly=TRUE, warn.conflicts=FALSE)
library("MASS", quietly=TRUE)
source("../../code/condition.R")
source("../../code/fit.method.R")


data <- readRDS("data.rds")

set.seed(31337)
ptest <- 0.05
subset.test <- (runif(nrow(data)) < ptest)
test <- subset(data, subset.test)
ntest <- nrow(test)
train <- subset(data, !subset.test)
rm("data")


log10.pkeep <- seq(-3, 0, by=0.5)
pkeep <- 10^(log10.pkeep)

time <- list()
pred <- list()

nobs <- list()
ngroup <- list()


get.time <- function(t) {
    with(as.list(summary(t)), user + system)
}


for (i in seq_along(pkeep)) {
    data <- readRDS("data.rds")
    train <- subset(data, !subset.test)

    set.seed(0)
    s <- (runif(nrow(train)) < pkeep[[i]])
    train.s <- subset(train, s)
    train.s$group <- droplevels(train.s$group)
    nobs[[i]] <- nrow(train.s)
    ngroup[[i]] <- nlevels(train.s$group)
    rm("data", "train")

    control <- lmeControl(gradHess=FALSE, msMaxIter=1000, msMaxEval=4000)
    model <- NULL
    time[[i]] <- system.time({
        cond <- collect.conditions(
            model <- with(train.s,
                          glmmPQL(y ~ x - 1, random = ~ z - 1 | group,
                                  control=control, family=binomial()))
        )
    })

    if (is.null(model)) {
        next
    }

    # predict on test set
    fixef <- fixef(model)
    ranef <- as.matrix(ranef(model))
    eta <- test$x %*% fixef
    group.ix <- match(test$group, ranef)
    old <- !is.na(group.ix)
    eta[old] <- eta[old] + rowSums(test$z[old,,drop=FALSE]
                                   * ranef[group.ix[old],,drop=FALSE])
    mu <- binomial()$linkinv(eta)


    # record results
    pred[[i]] <- mu
    rm("model")

    miss.loss <- ifelse(test$y, mu <= 0.5, mu > 0.5)
    log.loss <- -(ifelse(test$y == 1, log(mu), log(1 - mu)))
    sq.loss  <- ifelse(test$y == 1, (1 - mu)^2, (mu)^2)

    cat("pkeep      : ", pkeep[[i]], "\n", sep="")
    cat("time       : ", get.time(time[[i]]), "\n", sep="")
    cat("log.loss   : ", mean(log.loss),
        " (", sd(log.loss)/sqrt(ntest),")\n", sep="")
    cat("miss.loss  : ", mean(miss.loss),
        " (", sd(miss.loss)/sqrt(ntest), ")\n", sep="")
    cat("sq.loss    : ", mean(sq.loss),
        " (", sd(sq.loss)/sqrt(ntest), ")\n", sep="")
    cat("---\n")
}


results <- data.frame(pkeep = unlist(pkeep),
                      nobs = unlist(nobs),
                      ngroup = unlist(ngroup),
                      time = sapply(time, get.time),
                      predict = I(pred))

saveRDS(results, "lme-subset.rds")


# This runs for awhile, then runs out of RAM (~20GB).
 
# iteration 1
# iteration 2
# iteration 3
# iteration 4
# iteration 5
# iteration 6
# iteration 7
# iteration 8
# iteration 9
# iteration 10
# pkeep      : 0.001
# time       : 3228.421
# log.loss   : 0.8234611 (0.001864588)
# miss.loss  : 0.3162865 (0.0006576246)
# sq.loss    : 0.2376368 (0.0004694896)
# ---
# iteration 1
# iteration 2
# iteration 3
# iteration 4
# iteration 5
# iteration 6
# iteration 7
# iteration 8
# iteration 9
# iteration 10
# pkeep      : 0.003162278
# time       : 5812.624
# log.loss   : 0.6769331 (0.001258221)
# miss.loss  : 0.3162645 (0.0006576123)
# sq.loss    : 0.2200657 (0.000401383)
# ---
# iteration 1
# iteration 2
# iteration 3
# iteration 4
# iteration 5
# iteration 6
# iteration 7
# iteration 8
# iteration 9
# iteration 10
# pkeep      : 0.01
# time       : 6138.693
# log.loss   : 0.5945194 (0.0006607145)
# miss.loss  : 0.3162545 (0.0006576067)
# sq.loss    : 0.2038894 (0.0002741238)
# ---
# iteration 1
# iteration 2
# iteration 3
# iteration 4
# iteration 5
# iteration 6
# pkeep      : 0.03162278
# time       : 9434.005
# log.loss   : 0.5937514 (0.0005915129)
# miss.loss  : 0.3170464 (0.0006580482)
# sq.loss    : 0.2038303 (0.0002527179)
# ---
# iteration 1
# iteration 2
# iteration 3
# iteration 4
# iteration 5
# pkeep      : 0.1
# time       : 19661.8
# log.loss   : 0.5956794 (0.0005808763)
# miss.loss  : 0.3186123 (0.0006589145)
# sq.loss    : 0.2046631 (0.0002491223)
# ---
# iteration 1
# iteration 2
# iteration 3
# iteration 4
# iteration 5
# pkeep      : 0.3162278
# time       : 61141.61
# log.loss   : 0.5978275 (0.000577826)
# miss.loss  : 0.3197103 (0.0006595169)
# sq.loss    : 0.2055924 (0.000248009)
# ---
# iteration 1
# iteration 2

# Approximately 16 hours for the first iteration.  At this point, I noticed
# that RAM usage was ~20GB (I only have 8GB of physical memory; the rest
# was swap).  I killed the process.
#

