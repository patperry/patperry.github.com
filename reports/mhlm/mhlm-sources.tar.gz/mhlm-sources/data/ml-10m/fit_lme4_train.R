

library("methods", quietly=TRUE)
library("lme4", quietly=TRUE, warn.conflicts=FALSE)
library("nlme", quietly=TRUE, warn.conflicts=FALSE)
library("optimx", quietly=TRUE, warn.conflicts=FALSE)


data <- readRDS("train.rds")

control <- glmerControl(calc.derivs = FALSE,
                        check.nobs.vs.nlev = "ignore",
                        check.nlev.gtr.1 = "ignore",
                        check.nobs.vs.nRE = "ignore",
                        check.rankX = "stop.deficient",
                        check.scaleX = "warning")
nAGQ <- 0L

time <- system.time({
    fit <- with(data, glmer(y ~ x - 1 + (z - 1 | group), family=binomial,
                            control=control, nAGQ=nAGQ))
})

# > time
#      user    system   elapsed 
# 43880.985  2690.596 46594.845

fixef <- fixef(fit)
ranef <- as.matrix(ranef(fit)[["group"]])


saveRDS(list(time=time, fit=fit, fixef=fixef, ranef=ranef),
        "lme4-train.rds")

