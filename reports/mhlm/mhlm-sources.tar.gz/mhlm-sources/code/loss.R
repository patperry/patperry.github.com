# loss.R
#

loss <- function(fixef.est, ranef.est, ranef.cov.est, dispersion.est,
                 fitted.values, fixef, ranef, ranef.cov.sqrt, dispersion,
                 means, family)
{
    fixef.loss <- mean.loss(fixef.est, fixef)

    if (!is.null(ranef.est)) {
        ranef.est.full <- matrix(0, nrow(ranef), ncol(ranef))
        ranef.est.full[as.integer(rownames(ranef.est)),] <- ranef.est
        ranef.loss <- (mean.loss(t(ranef.est.full), t(ranef), ranef.cov.sqrt)
                       / nrow(ranef))
    } else {
        ranef.loss <- NA
    }

    ranef.cov.loss <- cov.loss(ranef.cov.est, ranef.cov.sqrt)
    dispersion.loss <- cov.loss(dispersion.est, dispersion)

    if (is.null(fitted.values)) {
        predict.loss <- NA
    } else {
        if (family$family == "gaussian") {
            predict.loss <- mean((fitted.values - means)^2)
        } else if (family$family == "binomial") {
            mu0 <- means
            mu1 <- fitted.values

            kl <- (mu0 * log(mu0 / mu1)
                   + (1 - mu0) * log((1 - mu0)/(1 - mu1)))
            kl[mu0 == 0] <- -log1p(- mu1[mu0 == 0])
            kl[mu0 == 1] <- -log(mu1[mu0 == 1])

            predict.loss <- 2 * mean(kl)
        } else {
            stop("unsupported 'family'")
        }
    }

    list(fixef = fixef.loss,
         ranef = ranef.loss,
         ranef.cov = ranef.cov.loss,
         dispersion = dispersion.loss,
         predict = predict.loss)
}


mean.loss <- function(mean.est, mean, cov.sqrt = NULL)
{
    if (is.null(mean.est))
        return(NA)

    if (is.null(cov.sqrt)) {
        sum((mean.est - mean)^2)
    } else {
        sum((backsolve(cov.sqrt, mean.est - mean, transpose=TRUE))^2)
    }
}


# James-Stein quadratic loss function (equation 75, page 376):
#   L(hat(Sigma), Sigma) = tr((hat(Sigma) * Sigma^(-1) - I)^2)
#
# W. James and C. Stein, "Estimation with quadratic loss," _Proceedings
#   of the Fourth Berkeley Symposium on Mathematical Statistics and
#   Probability_, Berkeley and Los Angeles, University of California Press,
#   1961, pp. 361--379.
#
cov.loss <- function(cov.est, cov.sqrt)
{
    if (is.null(cov.est))
        return(NA)

    resid <- (backsolve(cov.sqrt, transpose=TRUE,
                        t(backsolve(cov.sqrt, transpose=TRUE, cov.est)))
              - diag(NROW(cov.sqrt)))
    sum(resid^2)
}


test.stats <- function(fixef.est, fixef.vcov, fixef)
{
    if (is.null(fixef.est) || is.null(fixef.vcov)
        || length(fixef) == 0)
        return(list(t=NA, tsq=NA))

    qr <- qr(fixef.vcov)
    if (qr$rank == length(fixef)) {
        diff <- fixef.est - fixef
        tstat <- diff / sqrt(diag(fixef.vcov))
        tsqstat <- drop(t(diff) %*% qr.solve(qr, diff))
    } else {
        tstat <- tsqstat <- NA
    }
    list(t=tstat, tsq=tsqstat)
}
