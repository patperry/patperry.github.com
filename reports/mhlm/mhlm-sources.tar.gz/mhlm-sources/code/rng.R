# sim/rng.R
# ---------


take.rng <- function(conn)
{
    id <- dbGetQuery(conn, 'SELECT max("id") AS "id" FROM "Rng"')$id

    if (is.na(id)) {
        id <- 1L
        put.rng(conn, id - 1L)
    }

    load.rng(conn, id)
    id
}


put.rng <- function(conn, id)
{
    lastid <- dbGetQuery(conn, 'SELECT max("id") AS "id" FROM "Rng"')$id
    stopifnot(is.na(lastid) || id == lastid)

    # make sure .Random.seed is set
    if (!exists(".Random.seed", envir=.GlobalEnv))
        runif(1)

    seed <- serialize(get(".Random.seed", envir=.GlobalEnv), NULL)

    dbSendPreparedQuery(conn,
        'INSERT INTO "Rng" VALUES ($id, $kind, $normal_kind, $seed)',
        data.frame(id=id + 1L, kind=RNGkind()[1],
                   normal_kind=RNGkind()[2], seed=I(list(seed))))
    invisible()
}


with.rng <- function(conn, id, expr)
{
    rk <- RNGkind()
    if ((re <- exists(".Random.seed", envir=.GlobalEnv)))
        rs <- get(".Random.seed", envir=.GlobalEnv)

    load.rng(conn, id)
    res <- eval(expr)

    RNGkind(rk[1], rk[2])
    if (re) {
        assign(".Random.seed", rs, envir=.GlobalEnv)
    } else {
        rm(".Random.seed", envir=.GlobalEnv)
    }

    res
}


load.rng <- function(conn, id)
{
    data <- dbGetQuery(conn,
        sprintf(paste('SELECT "kind", "normal_kind", "seed"'
                    , 'FROM "Rng" WHERE "id" = %d'),
                id))

    seed <- unserialize(data$seed[[1]])
    RNGkind(data$kind, data$normal_kind)
    assign(".Random.seed", seed, envir=.GlobalEnv)
    invisible()
}

