
get.condition.type.id <- function(conn, name)
{
    bind.data <- data.frame(name)
    dbSendPreparedQuery(conn,
        'INSERT OR IGNORE INTO "ConditionType"("name") VALUES ($name)',
        bind.data)
    data <- dbGetPreparedQuery(conn,
        'SELECT "id" FROM "ConditionType" WHERE "name" = $name',
        bind.data)
    data$id
}


get.condition.id <- function(conn, class, message = NULL)
{
    type <- get.condition.type.id(conn, class)
    if (is.null(message))
        message <- NA

    bind.data <- data.frame(type, message)
    dbSendPreparedQuery(conn,
        'INSERT OR IGNORE INTO "Condition"("type", "message") VALUES ($type, $message)',
        bind.data)
    data <- dbGetPreparedQuery(conn,
        'SELECT "id" FROM "Condition" WHERE "type" = $type AND "message" = $message',
        bind.data)

    data$id
}


collect.conditions <- function(expr)
{
    append <- function(old, class, e, frames) {
        dump.frames() # writes to last.dump
        calls <- names(last.dump)[seq_len(length(last.dump) - 1L)]
        frames <- paste(format(seq_along(calls)), ': ', calls, sep = '',
                     collapse='\n')

        msg <- conditionMessage(e)
        if (is.null(msg))
            msg <- NA

        rbind(old, data.frame(class=class,
                              message=msg,
                              frames=frames,
                              stringsAsFactors=FALSE))
    }

    cond <- NULL
    withRestarts(
        withCallingHandlers({
            expr
        }, interrupt = function(e) {
            cond <<- append(cond, "interrupt", e)
        }, error = function(e) {
            cond <<- append(cond, "error", e)
            invokeRestart("skip")
        }, warning = function(w) {
            cond <<- append(cond, "warning", w)
            invokeRestart("muffleWarning")
        }),
        skip = function() {})
    return(cond)
}
