# lmer.split.fit.R
# ----------------
# Requires:
#   linalg.R


combine.prec <- function(est, cov.est, vcov=FALSE)
{
    n <- nrow(est)
    p <- ncol(est)

    wt.est <- matrix(NA, n, p)
    prec.est <- array(NA, c(p,p,n))
    for (i in seq_len(n)) {
        prec.est[,,i] <- pseudo.solve(cov.est[,,i])
        wt.est[i,] <- prec.est[,,i] %*% est[i,]
    }

    wt.est.tot <- colSums(wt.est)
    prec.tot <- apply(prec.est, c(1,2), sum)

    est.tot <- as.vector(pseudo.solve(prec.tot, wt.est.tot))

    if (vcov) {
        est.tot.vcov <- pseudo.solve(prec.tot)
        attr(est.tot.vcov, "deficient") <- NULL
        attr(est.tot, "vcov") <- est.tot.vcov
    }

    est.tot
}


fit.lmer.split <- function(x, z, y, group, family=gaussian(), nsplit=10)
{
    if (family$family == "gaussian") {
        control <- lmerControl(check.nobs.vs.nlev = "ignore",
                               check.nlev.gtr.1 = "ignore",
                               check.nobs.vs.nRE = "ignore",
                               check.rankX = "stop.deficient",
                               check.scaleX = "warning")
    } else {
        #control <- glmerControl(optimizer="optimx",
        #                        optCtrl=list(method="L-BFGS-B"),
        #                        check.nobs.vs.nRE="warning")
        control <- glmerControl(calc.derivs = FALSE,
                                check.nobs.vs.nlev = "ignore",
                                check.nlev.gtr.1 = "ignore",
                                check.nobs.vs.nRE = "ignore",
                                check.rankX = "stop.deficient",
                                check.scaleX = "warning")
    }

    group <- as.factor(group)
    n <- length(group)
    nsplit <- 10
    s <- sample.int(nsplit, n, replace=TRUE)
    model <- list()
    for (i in seq_len(nsplit)) {
        ix <- which(s == i)
        xi <- x[ix,,drop=FALSE]
        zi <- z[ix,,drop=FALSE]
        yi <- y[ix]
        groupi <- factor(group[ix]) # drops unused levels

        if (family$family == "gaussian") {
            model[[i]] <- lmer(yi ~ xi - 1 + (zi - 1 | groupi), control=control)
        } else {
            model[[i]] <- glmer(yi ~ xi - 1 + (zi - 1 | groupi), family=family,
                                control=control, nAGQ=0)
        }
        #if (length(fixef(model[[i]])) != ncol(xi))
        #    stop("fixed effect vector is not identifiable")
    }
    stop.time <- proc.time()

    p <- ncol(x)
    beta <- matrix(NA, nsplit, p)
    beta.cov <- array(NA, dim=c(p,p,nsplit))
    for (i in seq_len(nsplit)) {
        m <- model[[i]]
        beta[i,] <- fixef(m)
        beta.cov[,,i] <- as.matrix(vcov(m))
    }
    fixef <- combine.prec(beta, beta.cov, vcov=TRUE)
    fixef.vcov <- attr(fixef, "vcov")
    attr(fixef, "vcov") <- NULL

    q <- ncol(z)
    ng <- nlevels(group)
    u <- array(NA, c(ng, q, nsplit))
    u.cov <- array(NA, c(q, q, ng, nsplit))
    for (i in seq_len(nsplit)) {
        m <- model[[i]]
        re <- ranef(m, condVar=TRUE)
        ix <- match(rownames(re$groupi), levels(group))
        u[ix,,i] <- as.matrix(re$groupi)
        u.cov[,,ix,i] <- attr(re$groupi, "postVar")

        if (length(ix) != ng) {
            u[-ix,,i] <- 0
            u.cov[,,-ix,i] <- as.vector(VarCorr(m)[["groupi"]])
        }
    }
    ranef <- matrix(NA, ng, q)
    rownames(ranef) <- levels(group)
    for (g in seq_len(ng)) {
        ranef[g,] <- combine.prec(t(u[g,,]), u.cov[,,g,])
    }

    eta <- drop(x %*% fixef) + rowSums(z * ranef[as.integer(group),])
    yhat <- family$linkinv(eta)

    if (family$family == "binomial" || family$family == "poisson") {
        dispersion <- 1
    } else {
        dispersion <- mean(sapply(model, sigma)^2)
    }

    cov <- array(NA, c(q, q, nsplit))
    for (i in seq_len(nsplit)) {
        m <- model[[i]]
        cov[,,i] <- as.matrix(VarCorr(m)[["groupi"]])
    }
    ranef.cov <- apply(cov, c(1,2), mean)

    iter <- integer()
    for (i in seq_len(nsplit)) {
        m <- model[[i]]
        iter[[i]] <- m@optinfo$feval
    }
    iter.tot <- sum(iter)

    list(fixef=fixef,
         fixef.vcov=fixef.vcov,
         ranef=ranef,
         ranef.cov=ranef.cov,
         dispersion=dispersion,
         fitted.values=yhat,
         converged=TRUE,
         iter=iter.tot,
         stop.time=stop.time)
}
