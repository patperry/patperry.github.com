
hglm.gaussian.sgd.iter.R <- function(x, z, y, group.int, nobs.group, penalty,
                                     obs, rate0.coef, rate0.ranef, step.coef,
                                     step.ranef, coef, ranef)
{
    nobs <- length(obs)
    for (i in obs) {
        g <- group.int[i]
        ng <- nobs.group[g]

        rate.coef <- (rate0.coef
                      / (1 + step.coef * rate0.coef / nobs))
        rate.ranef <- (rate0.ranef[g]
                       / (1 + step.ranef[g] * rate0.ranef[g] * penalty / ng))
        step.coef <- step.coef + 1L
        step.ranef[g] <- step.ranef[g] + 1L

        xi <- x[i,]
        zi <- z[i,]

        ug <- ranef[g,]
        mu <- sum(xi * coef) + sum(zi * ug)
        r <- y[i] - mu

        grad.coef  <- r * xi
        grad.ranef <- r * zi - (penalty/ng) * ug

        coef      <- rate.coef * grad.coef   + coef
        ranef[g,] <- rate.ranef * grad.ranef + ranef[g,]
    }

    list(step.coef = step.coef, step.ranef = step.ranef,
         coef = coef, ranef = ranef)
}


hglm.binomial.sgd.iter.R <- function(x, z, y, group.int, nobs.group, penalty,
                                     obs, rate0.coef, rate0.ranef, step.coef,
                                     step.ranef, coef, ranef)
{
    nobs <- length(obs)
    for (i in obs) {
        g <- group.int[i]
        ng <- nobs.group[g]

        rate.coef <- (rate0.coef
                      / (1 + step.coef * rate0.coef / nobs))
        rate.ranef <- (rate0.ranef[g]
                       / (1 + step.ranef[g] * rate0.ranef[g] * penalty / ng))
        step.coef <- step.coef + 1L
        step.ranef[g] <- step.ranef[g] + 1L

        xi <- x[i,]
        zi <- z[i,]

        ug <- ranef[g,]
        eta <- sum(xi * coef) + sum(zi * ug)
        mu <- 0.5 + 0.5 * tanh(0.5 * eta)
        r <- y[i] - mu

        grad.coef  <- r * xi
        grad.ranef <- r * zi - (penalty/ng) * ug

        coef      <- rate.coef * grad.coef   + coef
        ranef[g,] <- rate.ranef * grad.ranef + ranef[g,]
    }

    list(step.coef = step.coef, step.ranef = step.ranef,
         coef = coef, ranef = ranef)
}


hglm.gaussian.sgd.iter.C <- cfunction(
    signature(x="numeric", z="numeric", y="numeric", group_int="integer",
              nobs_group="integer", penalty="numeric", obs="integer",
              rate0_coef="numeric", rate0_ranef="numeric",
              step_coef="integer", step_ranef="integer",
              coef="numeric", ranef="numeric"),
    includes="#include <R_ext/BLAS.h>",
    language="C",
    body='
    SEXP res = PROTECT(allocVector(VECSXP, 4));
    SEXP res_names = PROTECT(allocVector(STRSXP, 4));
    int g, i, ng, ngroup, nobs, p, pos, q;
    double mu, r, r_coef, r_ranef, rate_coef, rate_ranef, s, *ug;
    const int ione = 1;
    const double *xi, *zi;

    PROTECT(step_coef = duplicate(step_coef));
    PROTECT(step_ranef = duplicate(step_ranef));
    PROTECT(coef = duplicate(coef));
    PROTECT(ranef = duplicate(ranef));

    p = ncols(x);
    q = ncols(z);
    ngroup = nrows(ranef);

    nobs = LENGTH(obs);
    for (pos = 0; pos < nobs; pos++) {
        i = INTEGER(obs)[pos] - 1;
        g = INTEGER(group_int)[i] - 1;
        ng = INTEGER(nobs_group)[g];

        rate_coef = (REAL(rate0_coef)[0]
                     / (1 + INTEGER(step_coef)[0] * REAL(rate0_coef)[0]
                            / nobs));
        rate_ranef = (REAL(rate0_ranef)[g]
                      / (1 + INTEGER(step_ranef)[g] * REAL(rate0_ranef)[g]
                             * REAL(penalty)[0] / ng));
        INTEGER(step_coef)[0] = INTEGER(step_coef)[0] + 1;
        INTEGER(step_ranef)[g] = INTEGER(step_ranef)[g] + 1;

        xi = &(REAL(x)[i]);
        zi = &(REAL(z)[i]);

        ug = &(REAL(ranef)[g]);

        mu = F77_NAME(ddot)(&p, xi, &nobs, REAL(coef), &ione);
        mu += F77_NAME(ddot)(&q, zi, &nobs, ug, &ngroup);
        r = REAL(y)[i] - mu;
        r_coef = rate_coef * r;
        r_ranef = rate_ranef * r;
        s = 1.0 - rate_ranef * ((REAL(penalty)[0]) / ng);

        F77_NAME(daxpy)(&p, &r_coef, xi, &nobs, REAL(coef), &ione);
        F77_NAME(dscal)(&q, &s, ug, &ngroup);
        F77_NAME(daxpy)(&q, &r_ranef, zi, &nobs, ug, &ngroup);
    }

    SET_VECTOR_ELT(res, 0, step_coef);
    SET_VECTOR_ELT(res, 1, step_ranef);
    SET_VECTOR_ELT(res, 2, coef);
    SET_VECTOR_ELT(res, 3, ranef);

    SET_STRING_ELT(res_names, 0, mkChar("step.coef"));
    SET_STRING_ELT(res_names, 1, mkChar("step.ranef"));
    SET_STRING_ELT(res_names, 2, mkChar("coef"));
    SET_STRING_ELT(res_names, 3, mkChar("ranef"));
    SET_NAMES(res, res_names);

    UNPROTECT(6);
    return res;
')



hglm.binomial.sgd.iter.C <- cfunction(
    signature(x="numeric", z="numeric", y="numeric", group_int="integer",
              nobs_group="integer", penalty="numeric", obs="integer",
              rate0_coef="numeric", rate0_ranef="numeric",
              step_coef="integer", step_ranef="integer",
              coef="numeric", ranef="numeric"),
    includes="#include <R_ext/BLAS.h>",
    language="C",
    body='
    SEXP res = PROTECT(allocVector(VECSXP, 4));
    SEXP res_names = PROTECT(allocVector(STRSXP, 4));
    int g, i, ng, ngroup, nobs, p, pos, q;
    double eta, mu, r, r_coef, r_ranef, rate_coef, rate_ranef, s, *ug;
    const int ione = 1;
    const double *xi, *zi;

    PROTECT(step_coef = duplicate(step_coef));
    PROTECT(step_ranef = duplicate(step_ranef));
    PROTECT(coef = duplicate(coef));
    PROTECT(ranef = duplicate(ranef));

    p = ncols(x);
    q = ncols(z);
    ngroup = nrows(ranef);

    nobs = LENGTH(obs);
    for (pos = 0; pos < nobs; pos++) {
        i = INTEGER(obs)[pos] - 1;
        g = INTEGER(group_int)[i] - 1;
        ng = INTEGER(nobs_group)[g];

        rate_coef = (REAL(rate0_coef)[0]
                     / (1 + INTEGER(step_coef)[0] * REAL(rate0_coef)[0]
                            / nobs));
        rate_ranef = (REAL(rate0_ranef)[g]
                      / (1 + INTEGER(step_ranef)[g] * REAL(rate0_ranef)[g]
                             * REAL(penalty)[0] / ng));
        INTEGER(step_coef)[0] = INTEGER(step_coef)[0] + 1;
        INTEGER(step_ranef)[g] = INTEGER(step_ranef)[g] + 1;

        xi = &(REAL(x)[i]);
        zi = &(REAL(z)[i]);

        ug = &(REAL(ranef)[g]);

        eta = F77_NAME(ddot)(&p, xi, &nobs, REAL(coef), &ione);
        eta += F77_NAME(ddot)(&q, zi, &nobs, ug, &ngroup);
        mu = 0.5 + 0.5 * tanh(0.5 * eta);
        r = REAL(y)[i] - mu;
        r_coef = rate_coef * r;
        r_ranef = rate_ranef * r;
        s = 1.0 - rate_ranef * ((REAL(penalty)[0]) / ng);

        F77_NAME(daxpy)(&p, &r_coef, xi, &nobs, REAL(coef), &ione);
        F77_NAME(dscal)(&q, &s, ug, &ngroup);
        F77_NAME(daxpy)(&q, &r_ranef, zi, &nobs, ug, &ngroup);
    }

    SET_VECTOR_ELT(res, 0, step_coef);
    SET_VECTOR_ELT(res, 1, step_ranef);
    SET_VECTOR_ELT(res, 2, coef);
    SET_VECTOR_ELT(res, 3, ranef);

    SET_STRING_ELT(res_names, 0, mkChar("step.coef"));
    SET_STRING_ELT(res_names, 1, mkChar("step.ranef"));
    SET_STRING_ELT(res_names, 2, mkChar("coef"));
    SET_STRING_ELT(res_names, 3, mkChar("ranef"));
    SET_NAMES(res, res_names);

    UNPROTECT(6);
    return res;
')


hglm.sgd.control0 <- function(family)
{
    if (family$family == "gaussian") {
        list(rate.scale = 0.1, niter=30)
    } else {
        list(rate.scale = 0.1, niter=100)
    }
}

hglm.sgd.fit <- function(x, z, y, group, family = gaussian(),
                         penalty = 100,
                         control = hglm.sgd.control0(family),
                         path = FALSE)
{
    if (family$family == "gaussian" && family$link == "identity") {
        #sgd.iter <- hglm.gaussian.sgd.iter.R
        sgd.iter <- hglm.gaussian.sgd.iter.C
    } else if (family$family == "binomial" && family$link == "logit") {
        #sgd.iter <- hglm.binomial.sgd.iter.R
        sgd.iter <- hglm.binomial.sgd.iter.C
    } else {
        stop("unsupported 'family'")
    }

    x <- as.matrix(x)
    z <- as.matrix(z)
    xnames <- dimnames(x)[[2L]]
    znames <- dimnames(z)[[2L]]
    ynames <- if (is.matrix(y))
        rownames(y)
    else names(y)
    nobs <- NROW(y)
    nfixed <- ncol(x)
    nrandom <- ncol(z)
    nvars <- nfixed + nrandom
    fixed <- (seq_len(nvars) <= nfixed)
    random <- !fixed

    group <- as.factor(group)
    levels <- levels(group)
    ngroups <- length(levels)
    group.int <- as.integer(group) # = match(group, levels)
    nobs.group <- tabulate(group.int, nbins=ngroups)

    coef <- numeric(nfixed)
    ranef <- matrix(0, ngroups, nrandom)

    rate0.coef <- control$rate.scale/nobs
    rate0.ranef <- control$rate.scale/nobs.group
    step.coef <- 0L
    step.ranef <- integer(ngroups)

    if (path) {
        hloglik <- rep(NA, control$niter)
        eta0 <- x %*% coef + rowSums(z * ranef[group.int,])
        mu0 <- family$linkinv(eta0)
        hloglik0 <- sum(family$dev(y, mu0, 1)) + (penalty / 2) * sum(ranef^2)
    }

    for (it in seq_len(control$niter)) {
        obs <- sample.int(nobs) # choose random observation order

        # perform batch
        iter <- sgd.iter(x, z, y, group.int, nobs.group,
                         penalty, obs, rate0.coef,
                         rate0.ranef, step.coef, step.ranef,
                         coef, ranef)

        step.coef <- iter$step.coef
        step.ranef <- iter$step.ranef
        coef <- iter$coef
        ranef <- iter$ranef

        if (path) {
            eta <- x %*% coef + rowSums(z * ranef[group.int,])
            mu <- family$linkinv(eta)
            hloglik[it] <- (sum(family$dev(y, mu, 1))
                            + (penalty / 2) * sum(ranef^2))
        }
    }
    stop.time <- proc.time()

    eta <- drop(x %*% coef) + rowSums(z * ranef[group.int,])
    mu <- family$linkinv(eta)

    ranef.cov <- cov(ranef)

    if (family$family == "gaussian") {
        resid <- y - mu
        dispersion <- var(resid)
    } else if (family$family == "binomial") {
        dispersion <- 1
    }

    names(coef) <- xnames
    rownames(ranef) <- levels
    colnames(ranef) <- znames
    dimnames(ranef.cov) <- list(znames, znames)
    names(mu) <- ynames

    if (path) {
        hloglik.path <- c(hloglik0, hloglik)
    } else {
        hloglik.path <- NULL
    }

    list(fixef = coef,
         fixef.vcov = NULL,
         ranef = ranef,
         ranef.cov = ranef.cov,
         dispersion = dispersion,
         fitted.values = mu,
         converged = TRUE,
         iter = control$niter,
         hloglik.path = hloglik.path,
         stop.time=stop.time)
}



hglm.sgd.cv <- function(x, z, y, group, family = gaussian(),
                        penalty = 10^seq(-3, 4, 0.5), nfold=5,
                        control = hglm.sgd.control0(family))
{
    n <- NROW(y)
    npenalty <- length(penalty)
    group <- as.factor(group)

    cv <- matrix(NA, nfold, npenalty)

    fold <- sample.int(nfold, n, replace=TRUE)
    for (k in seq_len(nfold)) {
        test <- fold == k
        train <- !test

        x0 <- x[train,,drop=FALSE]
        z0 <- x[train,,drop=FALSE]
        y0 <- y[train]
        group0 <- group[train]

        x1 <- x[test,,drop=FALSE]
        z1 <- x[test,,drop=FALSE]
        y1 <- y[test]
        group1 <- group[test]

        for (l in seq_len(npenalty)) {
            est <- hglm.sgd.fit(x0, z0, y0, group0, family, penalty[l],
                                control)
            iz <- match(as.character(group1), rownames(est$ranef))
            eta1 <- drop(x1 %*% est$fixef + rowSums(z1 * est$ranef[iz,]))
            mu1 <- family$linkinv(eta1)
            if (family$family == "gaussian" && family$link == "identity") {
                cv[k,l] <- mean((y1 - mu1)^2)
            } else if (family$family == "binomial" && family$link == "logit") {
                cv[k,l] <- mean(ifelse(y1, -log(mu1), -log(1-mu1)))
            } else {
                stop("unrecognized 'family'")
            }
        }
    }

    cv.mean <- colMeans(cv)
    cv.sd <- apply(cv, 2, sd)
    cv.se <- cv.sd / sqrt(nfold)

    list(optimal.penalty=penalty[which.min(cv.mean)],
         penalty=penalty, err=cv.mean, err.se=cv.se, nfold=nfold)
}

