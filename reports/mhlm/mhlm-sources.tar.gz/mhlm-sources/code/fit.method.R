# fit.method.R
#
# Requires:
#   library(lme4) 
#   library(MASS)
#   library(optimx) 
#   library(mbest)
#   library(nlme)
#   library(RSQLite)
#   lmer.split.fit.R
#   sgd.fit.R
#


get.fit.method <- function(id)
{
    res <- dbGetPreparedQuery(conn,
               paste('SELECT "name" FROM "FitMethod"'
                   , 'WHERE "id" = $id'
                   , sep='\n'), bind.data=data.frame(id))
    if (nrow(res) == 0)
        stop(sprintf('unrecognized fit method id "%d"', id))
    name <- res[1, "name"]

    if (name == "lme") {
        fit <- fit.lme
    } else if (name == "lmer") {
        fit <- fit.lmer
    } else if (name == "lmer0") {
        fit <- fit.lmer0
    } else if (name == "lmer.split") {
        fit <- fit.lmer.split
    } else if (name == "mhglm") {
        fit <- fit.mhglm
    } else if (name == "sgd") {
        fit <- hglm.sgd.fit
    } else {
        stop(sprintf('unrecognized fit method name "%s"', name))
    }
    attr(fit, "name") <- name

    return(fit)
}


fit.mhglm <- function(x, z, y, group, family=gaussian())
{
    converged <- TRUE
    model <- mhglm(y ~ x - 1 + (z - 1 | group), family=family)
    stop.time <- proc.time()

    fixef <- fixef(model)
    fixef.vcov <- vcov(model)

    ranef <- as.matrix(ranef(model)[["group"]])
    ranef.cov <- VarCorr(model)[["group"]]
    attr(ranef.cov, "stddev") <- NULL
    attr(ranef.cov, "correlation") <- NULL

    dispersion <- (sigma(model))^2
    yhat <- fitted.values(model)

    iter <- 2

    list(fixef=fixef,
         fixef.vcov=fixef.vcov,
         ranef=ranef,
         ranef.cov=ranef.cov,
         dispersion=dispersion,
         fitted.values=yhat,
         converged=converged,
         iter=iter,
         stop.time=stop.time)
}


fit.lmer <- function(x, z, y, group, family=gaussian(), nAGQ=1)
{
    if (family$family == "gaussian") {
        control <- lmerControl(calc.derivs = FALSE,
                               check.nobs.vs.nlev = "ignore",
                               check.nlev.gtr.1 = "ignore",
                               check.nobs.vs.nRE = "ignore",
                               check.rankX = "stop.deficient",
                               check.scaleX = "warning")
    } else {
        #control <- glmerControl(optimizer="optimx",
        #                        optCtrl=list(method="L-BFGS-B"),
        #                        calc.derivs = FALSE,
        #                        check.nobs.vs.nlev = "ignore",
        #                        check.nlev.gtr.1 = "ignore",
        #                        check.nobs.vs.nRE = "ignore",
        #                        check.rankX = "stop.deficient",
        #                        check.scaleX = "warning")
        control <- glmerControl(calc.derivs = FALSE,
                                check.nobs.vs.nlev = "ignore",
                                check.nlev.gtr.1 = "ignore",
                                check.nobs.vs.nRE = "ignore",
                                check.rankX = "stop.deficient",
                                check.scaleX = "warning")
    }

    if (family$family == "gaussian") {
        model <- lmer(y ~ x - 1 + (z - 1 | group), control=control)
    } else {
        model <- glmer(y ~ x - 1 + (z - 1 | group), family=family,
                       control=control, nAGQ=nAGQ)
    }
    stop.time <- proc.time()

    fixef <- fixef(model)
    fixef.vcov <- as.matrix(vcov(model))

    ranef <- as.matrix(ranef(model)[["group"]])

    ranef.cov <- VarCorr(model)[["group"]]
    attr(ranef.cov, "stddev") <- NULL
    attr(ranef.cov, "correlation") <- NULL

    dispersion <- (sigma(model))^2
    yhat <- fitted.values(model)

    converged <- is.null(model@optinfo$conv$lme4)
    iter <- model@optinfo$feval

    list(fixef=fixef,
         fixef.vcov=fixef.vcov,
         ranef=ranef,
         ranef.cov=ranef.cov,
         dispersion=dispersion,
         fitted.values=yhat,
         converged=converged,
         iter=iter,
         stop.time=stop.time)
}


fit.lmer0 <- function(x, z, y, group, family=gaussian())
{
    fit.lmer(x, z, y, group, family, nAGQ=0)
}


fit.lme <- function(x, z, y, group, family=gaussian())
{
    control <- lmeControl(gradHess=FALSE, msMaxIter=1000, msMaxEval=4000)
    if (family$family != "gaussian") {
        model <- glmmPQL(y ~ x - 1, random = ~ z - 1 | group, control=control,
                         family=family)
    } else {
        model <- lme(y ~ x - 1, random = ~ z - 1 | group, control=control)
    }
    stop.time <- proc.time()

    if (family$family %in% c("binomial", "poisson")) {
        dispersion <- 1
    } else {
        dispersion <- model$sigma^2
    }

    fixef <- fixef(model)
    suppressWarnings({
        fixef.vcov <- vcov(model)
    })
    if (!is.null(fixef.vcov) && any(is.na(fixef.vcov))) {
        fixef.vcov <- NULL
    }

    ranef <- as.matrix(ranef(model))
    ranef.cov <- as.matrix(model$modelStruct$reStruct$group) * dispersion
    if (family$family != "gaussian") {
        yhat <- family$linkinv(fitted.values(model))
    } else {
        yhat <- fitted.values(model)
    }

    iter <- model$numIter
    if (is.null(iter))
        iter <- NA

    list(fixef=fixef,
         fixef.vcov=fixef.vcov,
         ranef=ranef,
         ranef.cov=ranef.cov,
         dispersion=dispersion,
         fitted.values=yhat,
         converged=TRUE,
         iter=iter,
         stop.time=stop.time)
}

