#!/usr/bin/Rscript --vanilla

library("methods", quietly=TRUE)
library("RSQLite", quietly=TRUE)
library("rzmq", quietly=TRUE)


get.jobs <- function(conn)
{
    # get all unfinished jobs
    jobs <- dbGetQuery(conn,
        paste('SELECT R."id"  "replicate",'
            , '       FM."id" "method"'
            , 'FROM "Replicate" R'
            , 'CROSS JOIN "FitMethod" FM'
            , 'WHERE "method"'
            , 'NOT IN ('
            , '    SELECT "method" FROM "Fit"'
            , '    WHERE "replicate" = R."id"'
            , ')'
            , 'ORDER BY "replicate", "method"'
            , sep='\n'))
    n <- nrow(jobs)

    # choose random order for replicates
    r <- factor(jobs$replicate)
    r.o <- sample.int(nlevels(r))
    m.o <- sample.int(n)

    # within each replicate, choose random order for methods
    i <- order(r.o[r], m.o)
    jobs <- jobs[i,]
    rownames(jobs) <- NULL

    jobs
}


producer <- function(jobs)
{
    context <- init.context()
    broker <- init.socket(context, "ZMQ_ROUTER")
    bind.socket(broker, "tcp://*:5557")

    for (i in seq_len(NROW(jobs))) {
        job <- as.list(jobs[i,])

        id <- receive.socket(broker, unserialize=FALSE)
        send.socket(broker, id, send.more=TRUE, serialize=FALSE)
        receive.socket(broker, unserialize=FALSE) # envelope delimiter
        receive.socket(broker)                    # response from worker
        send.null.msg(broker, send.more=TRUE)

        cat(sprintf("sending replicate %d method %d\n",
                    job$replicate, job$method))
        send.socket(broker, job)
    }

    cat("done\n")
}


drv <- dbDriver("SQLite")
conn <- dbConnect(drv, dbname="logistic.db")

tryCatch({
    jobs <- get.jobs(conn)
}, finally = {
    invisible(dbDisconnect(conn))
})

producer(jobs)
