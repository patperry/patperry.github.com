#!/usr/bin/Rscript --vanilla

library("digest", quietly=TRUE)
library("methods", quietly=TRUE)
library("RSQLite", quietly=TRUE)

source("../../code/rng.R")
source("../../code/replicate.R")


set.seed(31337) # ensure consistent runs


# dimensions
ngroup <- 1000
#ngroup <- round(10^(seq(from=1, to=4, by=1)))
nobs <- round(10^(seq(from=2, to=5, by=0.25)))
nobs.dispersion <- 1

# fixed effects
nfixef <- 5
fixef.mean.df <- 4
fixef.scale <- 0.1

# random effects
nranef <- 5
ranef.cov.df <- 2 * nranef
ranef.scale <- 1

# noise
dispersion <- 1

# family
family <- binomial()

nrep <- 100

nrep.total <- nrep * length(ngroup) * length(nobs)

drv <- dbDriver("SQLite")
conn <- dbConnect(drv, dbname="logistic.db")

tryCatch({
    nrep.existing <- dbGetQuery(conn, 'SELECT count(*) FROM "Replicate"')[[1]]

    if (nrep.existing != nrep.total) {
        pb <- txtProgressBar(min=0, max=nrep.total, style=3, file=stderr())

        dbBegin(conn)

        i <- 0
        for (r in seq_len(nrep)) {
            for (no in nobs) {
                for (ng in ngroup) {
                    add.replicate(conn=conn,
                                  ngroup=ng, nobs=no,
                                  nobs.dispersion=nobs.dispersion,
                                  nfixef=nfixef, fixef.mean.df=fixef.mean.df,
                                  fixef.scale=fixef.scale,
                                  nranef=nranef,
                                  ranef.cov.df=ranef.cov.df,
                                  ranef.scale=ranef.scale,
                                  dispersion=dispersion,
                                  family=family)
                    i <- i + 1
                    setTxtProgressBar(pb, i)
                }
            }
        }

        dbCommit(conn)

        close(pb)
    }
}, finally = {
    invisible(dbDisconnect(conn))
})

