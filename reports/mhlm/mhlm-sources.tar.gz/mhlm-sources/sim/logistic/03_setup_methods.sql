#!/usr/bin/env bash -e

cat <<EOF | sqlite3 "logistic.db"
--------------------------------------------------------------------------------

INSERT OR IGNORE INTO "FitMethod"("name") VALUES
    ('lme'),
    ('lmer0'),
    ('lmer'),
    ('lmer.split'),
    ('mhglm'),
    ('sgd');

--------------------------------------------------------------------------------
EOF
