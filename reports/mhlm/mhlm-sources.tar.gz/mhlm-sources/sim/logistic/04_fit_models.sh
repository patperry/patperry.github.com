#!/usr/bin/env bash -e

if [ "$#" -ne 1 ]; then
    echo "Must specify number of workers as first argument"
    exit 1
fi

NWORK=$1

RESULTCOLLECTOR="./fit-resultcollector.R"
CONSUMER="./fit-consumer.R"
PRODUCER="./fit-producer.R"
LOGDIR="log"


mkdir -p "$LOGDIR"


function interrupt {
    kill ${resultcollector_pid}
    for i in $(seq 1 $NWORK)
    do
        kill ${consumer_pid[$i]}
    done
    kill ${producer_pid}
    exit 1
}

trap interrupt INT


CMD="$RESULTCOLLECTOR > $LOGDIR/resultcollector.$$.out 2> $LOGDIR/resultcollector.$$.err < /dev/null &"
echo $CMD
eval $CMD
resultcollector_pid=$!

for i in $(seq 1 $NWORK);
do
    CMD="$CONSUMER > $LOGDIR/consumer$i.$$.out 2> $LOGDIR/consumer$i.$$.err < /dev/null &"
    echo $CMD
    eval $CMD
    consumer_pid[i]=$!
done

CMD="$PRODUCER > $LOGDIR/producer.$$.out 2> $LOGDIR/producer.$$.err < /dev/null &"
echo $CMD
eval $CMD
producer_pid=$!

wait
