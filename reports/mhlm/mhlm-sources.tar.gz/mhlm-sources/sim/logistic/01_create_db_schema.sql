#!/usr/bin/env bash -e

cat <<EOF | sqlite3 "logistic.db"
--------------------------------------------------------------------------------

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=1;


-- Random Number Generator
CREATE TABLE "Rng" (
    "id"            INTEGER NOT NULL,
    "kind"          TEXT,
    "normal_kind"   TEXT,
    "seed"          BLOB,

    PRIMARY KEY("id")
);


-- Replicate
CREATE TABLE "Replicate" (
    "id"    INTEGER NOT NULL,
    "rng"   INTEGER NOT NULL,

    "group_count"       INTEGER,
    "sample_count"      INTEGER,
    "sample_dispersion" REAL,

    "fixef_count"   INTEGER,
    "fixef_mean_df" REAL,
    "fixef_scale"   REAL,

    "ranef_count"   INTEGER,
    "ranef_scale"   REAL,
    "ranef_cov_df"  REAL,
        
    "dispersion"    REAL,
    "family"        TEXT,

    "md5_digest"    TEXT,

    PRIMARY KEY("id"),
    FOREIGN KEY("rng") REFERENCES "Rng"("id")
        ON DELETE NO ACTION
        ON UPDATE CASCADE
);

CREATE INDEX "FK_Replicate_rng"
    ON "Replicate"("rng");


-- FitMethod
CREATE TABLE "FitMethod" (
    "id" INTEGER NOT NULL,
    "name" TEXT,

    PRIMARY KEY("id")
);

CREATE UNIQUE INDEX "UQ_FitMethod_name"
    ON "FitMethod"("name");


-- Fit
CREATE TABLE "Fit" (
    "replicate" INTEGER NOT NULL,
    "method" INTEGER NOT NULL,

    "fixef_loss" REAL,
    "ranef_loss" REAL,
    "ranef_cov_loss" REAL,
    "dispersion_loss" REAL,
    "predict_loss" REAL,

    "t_stat" REAL,
    "tsq_stat" REAL,

    "converged" INTEGER,
    "iter" INTEGER,
    "real_time" REAL,
    "user_time" REAL,
    "sys_time" REAL,

    PRIMARY KEY("replicate", "method"),
    FOREIGN KEY("replicate") REFERENCES "Replicate"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY("method") REFERENCES "FitMethod"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE INDEX "FK_Fit_replicate"
    ON "Fit"("replicate");
CREATE INDEX "FK_Fit_method"
    ON "Fit"("method");


-- ConditionType
CREATE TABLE "ConditionType" (
    "id" INTEGER NOT NULL,
    "name" TEXT,

    PRIMARY KEY("id")
);

CREATE UNIQUE INDEX "UQ_ConditionType_name"
    ON "ConditionType"("name");


-- Condition
CREATE TABLE "Condition" (
    "id" INTEGER NOT NULL,
    "type" INTEGER NOT NULL,
    "message" TEXT,

    PRIMARY KEY("id"),
    FOREIGN KEY("type") REFERENCES "ConditionType"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE INDEX "FK_Condition_type"
    ON "Condition"("type");
CREATE UNIQUE INDEX "UQ_Condition_type_message"
    ON "Condition"("type", "message");


-- FitCondition
CREATE TABLE "FitCondition" (
    "id" INTEGER NOT NULL,
    "replicate" INTEGER NOT NULL,
    "method" INTEGER NOT NULL,
    "condition" INTEGER NOT NULL,
    "diagnostic" TEXT,

    PRIMARY KEY("id"),
    FOREIGN KEY("replicate", "method")
        REFERENCES "Fit"("replicate", "method")
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY("replicate") REFERENCES "Replicate"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY("method") REFERENCES "FitMethod"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY("condition") REFERENCES "Condition"("id")
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE INDEX "FK_FitCondition_replicate_method"
    ON "FitCondition"("replicate", "method");
CREATE INDEX "FK_FitCondition_replicate"
    ON "FitCondition"("replicate");
CREATE INDEX "FK_FitCondition_method"
    ON "FitCondition"("method");
CREATE INDEX "FK_FitCondition_condition"
    ON "FitCondition"("condition");

--------------------------------------------------------------------------------
EOF
