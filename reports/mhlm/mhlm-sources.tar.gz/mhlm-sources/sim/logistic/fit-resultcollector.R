#!/usr/bin/Rscript --vanilla

library("methods", quietly=TRUE)
library("RSQLite", quietly=TRUE)
library("rzmq", quietly=TRUE)

source("../../code/condition.R")

get.num.jobs <- function(conn)
{
    nrep <- dbGetQuery(conn, 'SELECT count(*) FROM "Replicate"')[[1]]
    nmeth <- dbGetQuery(conn, 'SELECT count(*) FROM "FitMethod"')[[1]]
    nfit <- dbGetQuery(conn, 'SELECT count(*) FROM "Fit"')[[1]]
    return (nrep * nmeth - nfit)
}

put.fit <- function(conn, replicate.id, method.id, result, conditions)
{
    dbBegin(conn)

    newfit <- TRUE
    tryCatch({
        dbSendPreparedQuery(conn,
            paste('INSERT OR ROLLBACK INTO "Fit" ('
                , '    "replicate", "method",'
                , '    "fixef_loss", "ranef_loss", "ranef_cov_loss",'
                , '    "dispersion_loss", "predict_loss",'
                , '    "t_stat", "tsq_stat",'
                , '    "converged", "iter",'
                , '    "real_time", "user_time", "sys_time"'
                , ') VALUES ('
                , '    $replicate, $method,'
                , '    $fixef_loss, $ranef_loss, $ranef_cov_loss,'
                , '    $dispersion_loss, $predict_loss,'
                , '    $t_stat, $tsq_stat,'
                , '    $converged, $iter,'
                , '    $real_time, $user_time, $sys_time'
                , ')'
                , sep='\n'),
            bind.data=cbind(replicate=replicate.id,
                            method=method.id,
                            result))
    }, error = function(e) {
        newfit <- FALSE
    })
    if (!newfit)
        return(dbRollback(conn))

    if (!is.null(conditions)) {
        for (i in seq_len(nrow(conditions))) {
            cond <- conditions[i,]
            cid <- get.condition.id(conn, cond$class, cond$message)
            dbSendPreparedQuery(conn,
                paste('INSERT INTO "FitCondition" ('
                    , '    "replicate", "method",'
                    , '    "condition", "diagnostic"'
                    , ') VALUES ('
                    , '    $replicate, $method,'
                    , '    $condition, $diagnostic'
                    , ')'
                    , sep='\n'),
                bind.data=data.frame(replicate=replicate.id,
                                     method=method.id,
                                     condition=cid,
                                     diagnostic=cond$frames))
        }
    }

    dbCommit(conn)
}


result.collector <- function(conn)
{
    context <- init.context()
    recv <- init.socket(context, "ZMQ_PULL")
    bind.socket(recv, "tcp://*:5558")

    ctrl <- init.socket(context, "ZMQ_PUB");
    bind.socket(ctrl, "tcp://*:5559")

    n <- get.num.jobs(conn)
    for (i in seq_len(n)) {
        msg <- receive.socket(recv)
        job <- msg$job
        fit <- msg$fit
        conditions <- msg$conditions
        cat(sprintf("writing results for replicate %d method %d\n",
                    job$replicate, job$method))
        put.fit(conn, job$replicate, job$method, fit, conditions)
    }

    Sys.sleep(5)
    cat("sending KILL signal to workers\n")
    send.socket(ctrl, "KILL")
}


drv <- dbDriver("SQLite")
conn <- dbConnect(drv, dbname="logistic.db")
tryCatch({
    result.collector(conn)
}, finally = {
    invisible(dbDisconnect(conn))
})
