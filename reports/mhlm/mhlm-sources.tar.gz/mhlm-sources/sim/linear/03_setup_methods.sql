#!/usr/bin/env bash -e

cat <<EOF | sqlite3 "linear.db"
--------------------------------------------------------------------------------

INSERT OR IGNORE INTO "FitMethod"("name") VALUES
    ('lme'),
    ('lmer'),
    ('lmer.split'),
    ('mhglm'),
    ('sgd');

--------------------------------------------------------------------------------
EOF
