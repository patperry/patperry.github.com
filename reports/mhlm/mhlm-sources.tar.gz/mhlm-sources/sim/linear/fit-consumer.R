#!/usr/bin/Rscript --vanilla

library("inline", quietly=TRUE)
library("devtools", quietly=TRUE)
library("digest", quietly=TRUE)
library("methods", quietly=TRUE)
library("Rcpp", quietly=TRUE, warn.conflicts=FALSE)
library("lme4", quietly=TRUE, warn.conflicts=FALSE)
library("nlme", quietly=TRUE, warn.conflicts=FALSE)
library("optimx", quietly=TRUE, warn.conflicts=FALSE)
library("RSQLite", quietly=TRUE)
library("rzmq")
library("utils")

load_all("../../lib/mbest", export_all=FALSE, quiet=TRUE)

source("../../code/linalg.R")
source("../../code/lmer.split.fit.R")
source("../../code/sgd.fit.R")

source("../../code/condition.R")
source("../../code/rng.R")
source("../../code/replicate.R")
source("../../code/fit.method.R")
source("../../code/loss.R")


compute.fit <- function(conn, replicate.id, method.id)
{
    fit <- get.fit.method(method.id)
    r <- load.replicate(conn, replicate.id)
    est <- NULL

    if (attr(fit, "name") == "sgd") {
        cv <- hglm.sgd.cv(r$x, r$z, r$y, r$group)
        penalty <- cv$optimal.penalty
        gc(FALSE)
        start.time <- proc.time()
        cond <- collect.conditions(
            est <- fit(x=r$x, z=r$z, y=r$y, group=r$group, family=r$family,
                       penalty=penalty)
        )
    } else {
        gc(FALSE)
        start.time <- proc.time()
        cond <- collect.conditions(
            est <- fit(x=r$x, z=r$z, y=r$y, group=r$group, family=r$family)
        )
    }
    if (!is.null(est) && !is.null(est$stop.time)) {
        stop.time <- est$stop.time
        time <- structure(stop.time - start.time, class = "proc_time")
        summary.time <- summary(time)
    } else {
        summary.time <- list(elapsed = NA, user = NA, system = NA)
    }

    l <- loss(fixef.est=est$fixef, ranef.est=est$ranef,
              ranef.cov.est=est$ranef.cov, dispersion.est=est$dispersion,
              fitted.values=est$fitted.values,
              fixef=r$fixef, ranef=r$ranef, ranef.cov.sqrt=r$ranef.cov.sqrt,
              dispersion=r$dispersion, means=r$y.mean,
              family=r$family)

    stat <- test.stats(est$fixef, est$fixef.vcov, r$fixef)

    conv <- if (!is.null(est)) est$converged else FALSE
    iter <- if (!is.null(est)) est$iter else NA

    data <- data.frame(fixef_loss = l$fixef,
                       ranef_loss = l$ranef,
                       ranef_cov_loss = l$ranef.cov,
                       dispersion_loss = l$dispersion,
                       predict_loss = l$predict,
                       t_stat = stat$t[1], # just use first variable
                       tsq_stat = stat$tsq,
                       real_time = summary.time[["elapsed"]],
                       user_time = summary.time[["user"]],
                       sys_time = summary.time[["system"]],
                       converged = conv,
                       iter = iter)

    list(fit=data, conditions=cond)
}


consumer <- function(conn)
{
    context <- init.context()

    worker <- init.socket(context, "ZMQ_REQ")
    connect.socket(worker, "tcp://localhost:5557")

    send <- init.socket(context, "ZMQ_PUSH")
    connect.socket(send, "tcp://localhost:5558")

    ctrl <- init.socket(context, "ZMQ_SUB");
    connect.socket(ctrl, "tcp://localhost:5559")
    subscribe(ctrl, "")

    repeat {
        send.socket(worker, "READY")

        revents <- poll.socket(list(worker, ctrl), list("read", "read"), -1L)

        if (revents[[1]]$read) {
            job <- receive.socket(worker)
            if (is.null(job))
                break

            cat(sprintf("fitting replicate %d method %d\n",
                        job$replicate, job$method))

            set.seed(0)
            fit <- compute.fit(conn, job$replicate, job$method)

            msg <- list(job=job, fit=fit$fit, conditions=fit$conditions)
            send.socket(send, msg)
        }

        # Any waiting controller command acts as 'KILL'
        if (revents[[2]]$read) {
            cat("received KILL signal\n")
            set.linger(worker, 0L)
            break   # exit loop
        }
    }
}


drv <- dbDriver("SQLite")
conn <- dbConnect(drv, dbname="linear.db")

tryCatch({
    consumer(conn)
}, finally = {
    invisible(dbDisconnect(conn))
})
