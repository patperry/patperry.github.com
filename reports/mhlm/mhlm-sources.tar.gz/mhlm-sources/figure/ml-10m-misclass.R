

library("RColorBrewer")


# read in test data
test <- readRDS("../data/ml-10m/test.rds")


# read in fitted models
method <- list(mhglm = readRDS("../data/ml-10m/mhglm-train.rds"),
               glmer = readRDS("../data/ml-10m/lme4-train.rds"),
               sgd = readRDS("../data/ml-10m/sgd-train.rds"),
               lglm = readRDS("../data/ml-10m/lglm-train.rds"),
               glm = readRDS("../data/ml-10m/glm-train.rds"))
legend <- c("mhglm", "glmer", "sgd",
            "local glm", "global glm")
col <- c(1:5)
lty <- c(1:5)


# compute  test error
pred.err <- function(method, data)
{
    if (!is.null(method$fixef) && !is.null(method$ranef)) {
        eta.fix <- with(data, x %*% method$fixef)
        eta.ran <- numeric(nrow(data))
        group.ix <- match(as.character(data$group), rownames(method$ranef))
        ok <- !is.na(group.ix)
        eta.ran[ok] <- rowSums(data$z[ok,,drop=FALSE]
                               * method$ranef[group.ix[ok],,drop=FALSE])
        eta <- eta.fix + eta.ran
    } else if (is.matrix(method$coef)) {
        eta <- numeric(nrow(data))
        group.ix <- match(as.character(data$group), rownames(method$coef))
        ok <- !is.na(group.ix)
        eta[ok] <- rowSums(data$x[ok,,drop=FALSE]
                           * method$coef[group.ix[ok],,drop=FALSE])
        eta[!ok] <- NA
    } else if (is.vector(method$coef)) {
        eta <- data$x %*% method$coef
    } else {
        stop("invalid 'method'")
    }

    mu <- binomial()$linkinv(eta)
    log.loss <- -(ifelse(data$y == 1, log(mu), log(1 - mu)))
    sq.loss <- ifelse(data$y == 1, (1 - mu)^2, (mu)^2)
    miss.loss <- as.numeric(ifelse(data$y == 1, mu <= 0.5, mu > 0.5))

    # aggregate by group
    list(log  = unlist(by(log.loss,  data$group, mean, simplify=FALSE)),
         sq   = unlist(by(sq.loss,   data$group, mean, simplify=FALSE)),
         miss = unlist(by(miss.loss, data$group, mean, simplify=FALSE)))
}

loss <- lapply(method, pred.err, data=test) 


# aggregate loss by group
ncut <- 20
ng <- unlist(by(rep(1, length(test$group)), test$group, length, simplify=FALSE))
bin <- cut(rank(ng), ncut)

aggregate <- function(x, bin)
{
    mean <- as.vector(by(x, bin, mean))
    se  <- as.vector(by(x, bin, function(y) sd(y) / sqrt(length(y))))
    list(mean=mean, se=se)
}

n.bin <- aggregate(ng, bin)
miss.bin <- lapply(loss, function(l) aggregate(100 * l$miss, bin))


# make the plot
xlim <- range(log10(n.bin$mean))
ylim <- range(sapply(miss.bin, function(m) m$mean))


csi <- par("csi")

w <- 3
wtot <- w + csi * (3.1 + 8.6)

h <- 3
htot <- h + csi * (3.1 + 1.1)

pdf("ml-10m-misclass.pdf", width=wtot, height=htot)
par(ps=10, las=1, mgp=c(2, 0.75, 0))

palette(brewer.pal(6, "Set1"))

par(mar=c(3, 3, 1, 8.5) + .1)

plot(xlim, ylim, t="n",
     xlab=expression(Log[10]~'Group Size'),
     ylab="Misclassification Rate (%)", axes=FALSE)

# guide lines
usr <- par("usr")
abline(h=seq(usr[3], usr[4], length.out=4)[-c(1,4)], col="gray")
abline(v=seq(usr[1], usr[2], length.out=4)[-c(1,4)], col="gray")


# axes
axis(1, lwd=0, lwd.ticks=1)
axis(2, lwd=0, lwd.ticks=1)
axis(3, labels=FALSE, lwd=0, lwd.ticks=1)
axis(4, labels=FALSE, lwd=0, lwd.ticks=1)
box()


fin <- par("fin")
mai <- par("mai")
plt <- par("plt")
usr <- par("usr")
rscale <- (((usr[2] - usr[1])/(usr[4] - usr[3]))
           * ((fin[2] - mai[1] - mai[3]) / (fin[1] - mai[2] - mai[4])))

lwd <- 2

for (i in seq_along(miss.bin)) {
    lines(log10(n.bin$mean), miss.bin[[i]]$mean, lwd=lwd, col=col[i], lty=lty[i])
    symbols(log10(n.bin$mean), miss.bin[[i]]$mean,
            circles=miss.bin[[i]]$se * rscale, inches=FALSE, fg=col[i], add=TRUE,
            col=col[i])
}


# legend
usr <- par("usr")
cxy <- par("cxy")
legend.x <- usr[2] + 2.5 * cxy[1]
legend.y <- usr[3] # + 0.5 * cxy[1]
legend(legend.x, legend.y, xjust=0, yjust=0, xpd=TRUE, bty="n",
           legend=legend, lty=lty, col=col, lwd=lwd, title="Method")

dev.off()
