# figure/ml-10m-coef-pairs.R
# --


library("MASS", quietly=TRUE) # for kde2d

mhglm <- readRDS("../data/ml-10m/mhglm.rds")
fit <- mhglm$fit


ny <- by(rep(1, length(fit$y)), fit$group, sum)
ix <- ny >= 100

fixef <- mhglm$fixef
ranef <- mhglm$ranef

mean <- fixef[match(colnames(ranef), names(fixef))]
coef <- ranef + matrix(1, nrow(ranef), 1) %*% matrix(mean, 1, ncol(ranef))

genreaction <- -rowSums(coef[,c("genrechildren", "genrecomedy", "genredrama")])
coef <- cbind(coef[,1,drop=FALSE], genreaction, coef[,-1])


panel.hist <- function(x, col, ...)
{
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(usr[1:2], 0, 1.5) )
    h <- hist(x, breaks="Scott", plot = FALSE)
    d <- density(x)
    breaks <- h$breaks; nB <- length(breaks)
    y <- h$counts; y <- y/max(y)
    #rect(breaks[-nB], 0, breaks[-1], y, col=rgb(55, 126, 184, max=255), ...)
    polygon(d$x, d$y / max(d$y), col=rgb(55, 126, 184, max=255), border="black", ...)
}

panel.contour <- function(x, y, ...)
{
    d <- kde2d(x, y, n=50)
    z <- sort(d$z, dec=TRUE)
    cz <- cumsum(z)
    z0 <- z[min(which(cz > sum(z) * (1 - 2 * pnorm(-0.5))))]
    z1 <- z[min(which(cz > sum(z) * (1 - 2 * pnorm(-1.0))))]
    z2 <- z[min(which(cz > sum(z) * (1 - 2 * pnorm(-1.5))))]
    z3 <- z[min(which(cz > sum(z) * (1 - 2 * pnorm(-2.0))))]
    z4 <- z[min(which(cz > sum(z) * (1 - 2 * pnorm(-2.5))))]
    #z5 <- z[min(which(cz > sum(z) * (1 - 2 * pnorm(-3.0))))]
    points(x, y, ...)
    contour(d, add=TRUE, nlevels=5, drawlabels=FALSE, levels=c(z0,z1,z2,z3,z4))
}


#pdf("ml-10m-coef-pairs.pdf")
png("ml-10m-coef-pairs.png", width=7, height=7, units="in", res=150)
par(ps=10, las=1)
pairs(coef[ix,],
      labels = c("Intercept", "Action", "Children", "Comedy", "Drama",
                 "Popularity", "Previous"),
      #col=rgb(55, 126, 184, 100, max=255), pch=1,
      col=rgb(55, 126, 184, max=255),
      cex=.10, pch=20,
      diag.panel = panel.hist,
      panel.contour,
      gap=.25)
dev.off()


#i <- which(ix)[which.max(coef[ix,"user.liked.lastTRUE"])]
#xsub <- subset(ratings, user == i)
#plot(seq_along(xsub$time), as.numeric(xsub$rating)[order(xsub$time)] / 2, t="p",
#     pch=20)
