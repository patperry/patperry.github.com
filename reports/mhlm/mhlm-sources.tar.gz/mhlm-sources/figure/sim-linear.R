library("grid")
library("methods", quietly=TRUE)
library("RSQLite", quietly=TRUE)
library("plyr")
library("RColorBrewer")

#palette(brewer.pal(8, "Blues"))



drv <- dbDriver("SQLite")
conn <- dbConnect(drv, dbname="../sim/linear/linear.db")


raw <- dbGetQuery(conn,
            paste('SELECT'
                , '    F."replicate" AS "id",'
                , '    R."group_count" AS "ngroup",'
                , '    R."sample_count" AS "nobs",'
                , '    FM."name" AS "method",'
                , '    F."user_time" + F."sys_time" AS "time",'
                , '    F."iter" AS "iter",'
                , '    F."converged" AS "converged",'
                , '    F."fixef_loss" AS "fixef.loss",'
                , '    F."ranef_loss" AS "ranef.loss",'
                , '    F."ranef_cov_loss" AS "ranef.cov.loss",'
                , '    F."dispersion_loss" AS "dispersion.loss",'
                , '    F."predict_loss" AS "predict.loss",'
                , '    count(*) AS "ncond"'
                , 'FROM "Fit" F'
                , 'INNER JOIN "Replicate" R'
                , '   ON  F."replicate" = R."id"'
                , 'INNER JOIN "FitMethod" FM'
                , '   ON F."method" = FM."id"'
                , 'LEFT OUTER JOIN "FitCondition" FC'
                , '   ON F."replicate" = FC."replicate"'
                , 'GROUP BY F."replicate", F."method"'
                , 'ORDER BY F."replicate", F."method"'
                ))
dbDisconnect(conn)

raw$time <- as.numeric(raw$time)
raw$method <- factor(raw$method)
raw$converged <- as.logical(raw$converged)

raw <- subset(raw, method %in% c("lme", "lmer", "lmer.split", "mhglm", "sgd"))
raw$method <- droplevels(raw$method)
raw$method <- as.character(raw$method)
raw$method[raw$method == "lmer.split"] <- "lmer split"
raw$method <- factor(raw$method,
                     levels=c("mhglm", "lmer", "sgd", "lmer split", "lme"))



raw <- subset(raw, ngroup == 1000)

est <- function(x) if (all(is.na(x))) NA else mean(x, na.rm=TRUE)
se <- function(x) sd(x, na.rm=TRUE) / sqrt(sum(!is.na(x)))

data <- ddply(raw, .(method, nobs, ngroup), function(x)
              c(iter=est(x$iter), iter.se=se(x$iter),
                time=est(x$time), time.se=se(x$time),
                fixef.loss=est(x$fixef.loss), fixef.loss.se=se(x$fixef.loss),
                ranef.loss=est(x$ranef.loss), ranef.loss.se=se(x$ranef.loss),
                ranef.cov.loss=est(x$ranef.cov.loss),
                    ranef.cov.loss.se=se(x$ranef.cov.loss),
                predict.loss=est(x$predict.loss),
                    predict.loss.se=se(x$predict.loss),
                dispersion=est(x$dispersion), dispersion.se=se(x$dispersion)))




plot.comparison <- function(x, y, y.se, group, main = NULL,
                            xaxis=FALSE,
                            xaxis.top = FALSE, xaxis.bottom = FALSE,
                            yaxis.left = TRUE, yaxis.right = TRUE)
{
    xlim <- range(x)
    ylim <- c(min(y, y - y.se, na.rm=TRUE), max(y, y + y.se, na.rm=TRUE))

    vplay <- grid.layout(2, 1, heights=unit(c(1, 1), c("line", "null")))
    pushViewport(viewport(layout=vplay))

    #pushViewport(viewport(layout.pos.row=2))
    #grid.segments(c(1/3,2/3), c(0, 0),
    #              c(1/3,2/3), c(1, 1), gp=gpar(col="gray"))
    #popViewport()

    vp <- dataViewport(layout.pos.row=2, xlim, ylim, name="plotRegion")
    pushViewport(vp)
    pushViewport(viewport(xscale=vp$xscale, yscale=vp$yscale,
                          clip="on", name="dataRegin"))

    col <- brewer.pal(5, "Set1")[seq_len(nlevels(group))]


    r <- y.se
    lty <- 1:5

    for (ig in seq_along(levels(group))) {
        g <- levels(group)[ig]
        i <- group == g
        grid.lines(unit(x[i], "native"), unit(y[i], "native"),
                   gp=gpar(col=col[ig], lty=lty[ig]), name="dataLines")
        grid.circle(unit(x[i], "native"), unit(y[i], "native"),
                    convertHeight(unit(r[i], "native"), "in"),
                    gp=gpar(col=col[ig]), name="dataSymbols")
    }
    popViewport() # dataRegion
    grid.rect()
    if (xaxis.bottom)
        grid.xaxis(gp=gpar(fontsize=9))

    if (yaxis.left)
        grid.yaxis(gp=gpar(fontsize=9))
    if (yaxis.right)
        grid.yaxis(label=FALSE, main=FALSE)

    popViewport() # plotRegion

    pushViewport(viewport(xscale=vp$xscale, layout.pos.row=1, name="plotTitle"))
    grid.rect(gp=gpar(fill="lightgray"))
    grid.text(main)
    if (xaxis.top)
        grid.xaxis(label=FALSE, main=FALSE)
    popViewport(1) # plotTitle

    popViewport(1) # layout
}


h.in <- 2
w.in <- 2
vplay <- grid.layout(3, 3,
                     widths=(unit(c(2, 8, 0), "line")
                             + unit(c(0, 2 * w.in, 0), "in")),
                     heights=(unit(c(1, 3, 4), "line")
                              + unit(c(0, 3 * h.in, 0), "in")))

pdf("sim-linear.pdf",
    width=sum(as.numeric(convertUnit(vplay$widths, "in"))),
    height=sum(as.numeric(convertUnit(vplay$heights, "in"))))
grid.newpage()
pushViewport(viewport(layout=vplay))


pushViewport(viewport(layout.pos.row=2, layout.pos.col=1))
grid.text(expression(Log[10]~'Mean Loss'),
          x=unit(1, "line"), y=unit(2/3, "npc"), rot=90)
grid.text(expression(Log[10]~'Seconds'),
          x=unit(1, "line"), y=unit(1/6, "npc"), rot=90)
popViewport()

pushViewport(viewport(layout.pos.row=3, layout.pos.col=2))
grid.text(expression(Log[10]~'Samples'), y=unit(1, "line"))
popViewport()

pushViewport(viewport(layout.pos.row=2, layout.pos.col=2))

pushViewport(viewport(layout=grid.layout(3, 2)))
pushViewport(viewport(layout.pos.row=1, layout.pos.col=1))
pushViewport(plotViewport(c(0.25, 2, 0.25, 2)))
with(data, {
    plot.comparison(
          x = log10(nobs)
        , y = log10(fixef.loss)
        , y.se = fixef.loss.se / fixef.loss / log(10)
        , group = method
        , main = 'Fixed Effect'
        , xaxis.top = TRUE)
})
popViewport(2)


pushViewport(viewport(layout.pos.row=1, layout.pos.col=2))
pushViewport(plotViewport(c(0.25, 2, 0.25, 2)))
with(data, {
    plot.comparison(
          x = log10(nobs)
        , y = log10(ranef.cov.loss)
        , y.se = ranef.cov.loss.se / ranef.cov.loss / log(10)
        , group = method
        , main = 'Random Effect Cov.'
        , xaxis.top = TRUE)
})
popViewport(2)


pushViewport(viewport(layout.pos.row=2, layout.pos.col=1))
pushViewport(plotViewport(c(0.25, 2, 0.25, 2)))
with(data, {
    plot.comparison(
          x = log10(nobs)
        , y = log10(ranef.loss)
        , y.se = ranef.loss.se / ranef.loss / log(10)
        , group = method
        , main = 'Random Effect')
})
popViewport(2)


pushViewport(viewport(layout.pos.row=2, layout.pos.col=2))
pushViewport(plotViewport(c(0.25, 2, 0.25, 2)))
with(data, {
    plot.comparison(
          x = log10(nobs)
        , y = log10(predict.loss)
        , y.se = predict.loss.se / predict.loss / log(10)
        , group = method
        , main = 'Prediction'
        , xaxis.bottom = TRUE)
})
popViewport(2)


pushViewport(viewport(layout.pos.row=3, layout.pos.col=1))
pushViewport(plotViewport(c(0.25, 2, 0.25, 2)))
with(data, {
   plot.comparison(
          x = log10(nobs)
        , y = log10(time)
        , y.se = time.se / time / log(10)
        , group = method
        , main = 'Computation Time'
        , xaxis.bottom = TRUE)
})
popViewport(2)

pushViewport(viewport(layout.pos.row=3, layout.pos.col=2))
pushViewport(plotViewport(c(0.25, 2, 3, 2)))


# Legend > Method
levels <- levels(data$method)
nlevels <- length(levels)

pushViewport(viewport(
    layout = grid.layout(nlevels + 3, 2,
                         heights=unit(c(rep(1, nlevels + 2), 0.5),
                                      c("null",
                                        rep("line", nlevels + 1),
                                        "line")))))
# Legend > Method > Title
pushViewport(viewport(layout.pos.row = 2))
grid.text("Method")
popViewport()

# Legend > Method > Content
col <- brewer.pal(5, "Set1")[seq_len(nlevels)]
for (i in seq_len(nlevels)) {
    pushViewport(viewport(layout.pos.row = i + 2, layout.pos.col = 1))
    grid.lines(unit(c(1, 1), "npc") + unit(c(-30, -6), "pt"), y = 0.5,
               gp=gpar(lty=i, col=col[[i]]))
    popViewport()

    pushViewport(viewport(layout.pos.row = i + 2, layout.pos.col = 2))
    grid.text(levels[[i]], x=unit(6, "pt"), just="left", gp=gpar(fontsize=9))
    popViewport()
}
popViewport(2)
popViewport()


popViewport()


dev.off()
