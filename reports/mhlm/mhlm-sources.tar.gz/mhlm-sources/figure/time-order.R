
library("RColorBrewer")
palette(brewer.pal(6, "Set1"))

data <- readRDS("../data/ml-10m/data.rds")
set.seed(31337)
ptest <- 0.05
subset.test <- (runif(nrow(data)) < ptest)
test <- subset(data, subset.test)
rm("data", "ptest", "subset.test")


mhglm <- readRDS("../data/ml-10m/mhglm-subset.rds")
lme4 <- readRDS("../data/ml-10m/lme4-subset.rds")
sgd <- readRDS("../data/ml-10m/sgd-subset.rds")


if (all(is.na(mhglm$nobs))) {
    mhglm$nobs <- lme4$nobs
}

if (all(is.na(mhglm$ngroup))) {
    mhglm$ngroup <- lme4$ngroup
}


log.loss <- function(ytest, mu) {
    l <- ifelse(ytest, -log(mu), -log(1-mu))
    mean <- mean(l)
    sd <- sd(l)
    se <- sd / sqrt(length(l))
    list(mean=mean, sd=sd, se.mean=se)
}

log.losses <- function(ytest, mu.list) {
    t(sapply(mu.list, log.loss, ytest = ytest))
}

mhglm$log.loss <- log.losses(test$y, mhglm$pred)
lme4$log.loss <- log.losses(test$y, lme4$pred)
sgd$log.loss <- log.losses(test$y, sgd$pred)


csi <- par("csi")

w <- 2
w1 <- w + csi * (3.1 + 0.6)
w2 <- w + csi * (0.6 + 7.1)
wtot <- w1 + w2

h <- 2
htot <- h + csi * (3.1 + 1.1)

pdf("time-order.pdf", wtot, htot)


par(ps=10, las=1, mgp=c(2, 0.75, 0))
layout(matrix(1:2, 1, 2), widths=c(w1, w2))

xlim.n <- range(log10(c(mhglm$nobs, lme4$nobs, sgd$nobs)))
xlim.m <- range(log10(c(mhglm$ngroup, lme4$ngroup, sgd$ngroup)))
ylim <- range(log10(c(mhglm$time.fit, lme4$time, sgd$time.fit, sgd$time.cv)),
              na.rm=TRUE)


par(mar=c(3, 3, 1, 0.5) + .1)
plot(xlim.n, ylim, t="n", xlab="", ylab="", axes=FALSE)

# guild lines
usr <- par("usr")
abline(h=seq(usr[3], usr[4], length.out=4)[-c(1,4)], col="gray")
abline(v=seq(usr[1], usr[2], length.out=4)[-c(1,4)], col="gray")

# data
lines(log10(mhglm$nobs), log10(mhglm$time.fit), col=1, lty=1)
points(log10(mhglm$nobs), log10(mhglm$time.fit), col=1, pch=20)

lines(log10(lme4$nobs), log10(lme4$time), col=2, lty=2)
points(log10(lme4$nobs), log10(lme4$time), col=2, pch=20)

lines(log10(sgd$nobs), log10(sgd$time.fit), col=3, lty=3)
points(log10(sgd$nobs), log10(sgd$time.fit), col=3, pch=17)
lines(log10(sgd$nobs), log10(sgd$time.fit + sgd$time.cv), col=3, lty=3)
points(log10(sgd$nobs), log10(sgd$time.fit + sgd$time.cv), col=3, pch=20)

# axes
axis(1, lwd=0, lwd.ticks=1)
mtext(expression(Log[10]~'Samples'), 1, par("mgp")[1])

axis(2, lwd=0, lwd.ticks=1,
     at=log10(3600) + seq(-6, 1), labels=seq(-6, 1))
mtext(expression(Log[10]~'Hours'), 2, par("mgp")[1], las=0)

axis(3, labels=FALSE, lwd=0, lwd.ticks=1)

box()

# Second plot

par(mar=c(3, 0.5, 1, 7) + .1)
plot(xlim.m, ylim, t="n", xlab="", ylab="", axes=FALSE)

# guild lines
usr <- par("usr")
abline(h=seq(usr[3], usr[4], length.out=4)[-c(1,4)], col="gray")
abline(v=seq(usr[1], usr[2], length.out=4)[-c(1,4)], col="gray")

# data
lines(log10(mhglm$ngroup), log10(mhglm$time.fit), col=1, lty=1)
points(log10(mhglm$ngroup), log10(mhglm$time.fit), col=1, pch=20)

lines(log10(lme4$ngroup), log10(lme4$time), col=2, lty=2)
points(log10(lme4$ngroup), log10(lme4$time), col=2, pch=20)

lines(log10(sgd$ngroup), log10(sgd$time.fit), col=3, lty=3)
points(log10(sgd$ngroup), log10(sgd$time.fit), col=3, pch=17, cex=0.8)
lines(log10(sgd$ngroup), log10(sgd$time.fit + sgd$time.cv), col=3, lty=3)
points(log10(sgd$ngroup), log10(sgd$time.fit + sgd$time.cv), col=3, pch=20)


# axes
axis(1, lwd=0, lwd.ticks=1)
mtext(expression(Log[10]~'Groups'), 1, par("mgp")[1])

axis(3, labels=FALSE, lwd=0, lwd.ticks=1)
axis(4, labels=FALSE, lwd=0, lwd.ticks=1)

box()

# legend
usr <- par("usr")
cxy <- par("cxy")
legend.x <- usr[2] + 1.5 * cxy[1]
legend.y <- usr[3] # + 0.5 * cxy[1]
legend(legend.x, legend.y, xjust=0, yjust=0, xpd=TRUE, bty="n",
           legend=c("mhglm", "glmer", "sgd", "sgd+cv"), title="Method",
           pch=c(20, 20, 20, 17), lty=c(1, 2, 3, 3), col=c(1, 2, 3, 3))

dev.off()
