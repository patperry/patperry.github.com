#!/usr/bin/Rscript --vanilla

# read in data
data <- readRDS("data/govtrack.rds")
x <- data$vote

n <- sum(!is.na(x))

# read in fitted models
models <- read.delim("analysis/govtrack-models.tsv")
#models <- subset(models, K <= 8 & L <= 8)
K <- models$K
L <- models$L
loglik <- models$loglik
dev <- -2 * loglik / n


# make scree plot
pdf("analysis/govtrack-scree.pdf", width=6, height=3.25)

par(mfrow=c(1,2), las=1, ps=10)

par(mar=c(4.1, 4.1, 1.1, 0.55))
plot(K, dev, pch=L, xlab="K", ylab="Deviance", cex=0.6)
for (l in seq_len(max(L))) {
    i <- L == l
    lines(K[i], dev[i], lty=l)
}

par(mar=c(4.1, 0.55, 1.1, 4.1))
plot(L, dev, pch=K, xlab="L", ylab="", axes=FALSE, cex=0.6)
axis(1)
axis(4)
box()
for (k in seq_len(max(K))) {
    i <- K == k
    lines(L[i], dev[i], lty=k)
}

invisible(dev.off())

# print ad-hoc AIC/BIC table

# ad-hoc choice of k
k <- (K - 1) * nrow(x) + (L - 1) * ncol(x) + K * L
#n <- prod(dim(x))

aic <- -2 * loglik + 2 * k
aicc <- aic + 2 * k * (k + 1) / (n - k - 1)
bic <- -2 * loglik + k * log(n)

# choose model:
crit <- data.frame(K, L, dev = dev,
                   aic = aic - min(aic),
                   aicc = aicc - min(aicc),
                   bic = bic - min(bic))
print(crit)


# par(mfrow=c(1,2))
# 
# plot(K * L, -2 * loglik, pch=L,
#      ylim=c(0, -2 * min(loglik)),
#      xlab=expression(K %*% L),
#      ylab="Deviance")
# legend("topright", title="L", legend=1:Lmax, pch=1:Lmax, inset=0.05)
# 
# for (l in seq_len(max(L))) {
#     i <- L == l
#     lines(K[i] * L[i], -2 * loglik[i], lty=l)
# }
# 
# 
# plot(K * L, -2 * loglik, pch=K,
#      ylim=c(0, -2 * min(loglik)),
#      xlab=expression(K %*% L),
#      ylab="Deviance")
# legend("topright", title="K", legend=1:Kmax, pch=1:Kmax, inset=0.05)
# 
# for (k in seq_len(max(K))) {
#     i <- K == k
#     lines(K[i] * L[i], -2 * loglik[i], lty=k)
# }
# 
# 
# arrows(8, .10 * -2 * loglik[K == 4 & L == 2],
#        8, .93 * -2 * loglik[K == 4 & L == 2],
#        length=0.075, code=2)
# text(8, 0, "Elbow at K = 4, L = 2", adj=0.25)
