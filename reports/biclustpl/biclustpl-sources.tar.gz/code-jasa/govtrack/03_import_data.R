#!/usr/bin/Rscript --vanilla

# read in vote matrix
votes <- read.delim("data/votes.tsv")

x <- matrix(NA, nlevels(votes$legislator_id), nlevels(votes$motion_id))
rownames(x) <- levels(votes$legislator_id)
colnames(x) <- levels(votes$motion_id)

yea <- votes$vote == "Yea"
x[as.matrix(votes[votes$vote == "Yea", c("legislator_id", "motion_id")])] <- 1
x[as.matrix(votes[votes$vote == "Nay", c("legislator_id", "motion_id")])] <- 0

# read in motion covariates
motions <- read.delim("data/motions.tsv")
ix <- match(colnames(x), as.character(motions$motion_id))
motions <- motions[ix,]
rownames(motions) <- motions$motion_id


# read in legislator covariates
legs <- read.delim("data/legislators.tsv")

ix <- match(rownames(x), as.character(legs$legislator_id))
legs <- legs[ix,]
rownames(legs) <- legs$legislator_id


# restrict to just the house of representatives
j <- motions$chamber == "h"
x <- x[,j]
i <- !apply(is.na(x), 1, all)

x <- x[i,]
legs <- legs[i,]
motions <- motions[j,]

saveRDS(list(motions=motions, legs=legs, vote=x), file="data/govtrack.rds")
