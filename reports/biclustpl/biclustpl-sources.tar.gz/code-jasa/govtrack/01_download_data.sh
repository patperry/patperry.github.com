#!/bin/sh

# Download data from govtrack.us

# Bulk raw data documentation: https://www.govtrack.us/developers/data


# Download the vote data in JSON format for the 113th congress
mkdir -p govtrackdata/congress/113

rsync -avz --delete --delete-excluded --exclude *.xml \
		govtrack.us::govtrackdata/congress/113/votes govtrackdata/congress/113


# Download the members data
mkdir -p govtrackdata
rsync -avz --delete --delete-excluded \
		govtrack.us::govtrackdata/congress-legislators govtrackdata
