#!/usr/bin/Rscript --vanilla

data <- readRDS("data/govtrack.rds")
legs <- data$legs
motions <- data$motions

fit <- readRDS("analysis/govtrack-fit.rds")

x <- data$vote

x[is.na(x)] <- 0

K <- 2
L <- 4

set.seed(0)
kmeans_row <- kmeans(x, centers = K, nstart = 1000, iter.max = 50)
kmeans_col <- kmeans(t(x), centers = L, nstart = 1000, iter.max = 50)



norm_disim <- function(mat)
{
    nr <- NROW(mat)
    nc <- NCOL(mat)

    d1 <- rowSums(mat)
    d2 <- colSums(mat)
    mat_norm <- matrix(0, nr, nc)

    for(r in 1:nr){
        for(s in 1:nc){
            if(mat[r, s] != 0){
                dr <- sqrt(abs(d1[r]))
                dc <- sqrt(abs(d2[s]))
				
                mat_norm[r, s] <- mat[r, s] / (dr * dc)
            }
        }
    }

    return(mat_norm)
}


x_norm <- norm_disim(x)
x_svd <- svd(x_norm, nu = NROW(x), nv = NCOL(x))
ns <- min(K, L)
U <- x_svd$u[, 1:ns]
V <- x_svd$v[, 1:ns]
set.seed(0)
disim_row <- kmeans(U, centers = K, nstart = 1000, iter.max = 50)
disim_col <- kmeans(V, centers = L, nstart = 1000, iter.max = 50)


cat("Profile Likelihood:\n")
print(table(legs$party, fit$row_cluster))
             
cat("DI-SIM:\n")
print(table(legs$party, disim_row$cluster))

cat("K-Means:\n")
print(table(legs$party, kmeans_row$cluster))


r <- fit$col_clusters
r <- c(2,3,1,4)[r]

r1 <- c(1,4,3,2)[disim_col$cluster]

cat("Confunsion between PL and DI-SIM:\n")
print(table(pl=r, disim=r1))

cat("Confusion between PL and K-Means:\n")
print(table(pl=r, kmeans=c(4,1,3,2)[kmeans_col$cluster]))
