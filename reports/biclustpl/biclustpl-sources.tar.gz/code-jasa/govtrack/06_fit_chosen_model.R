#!/usr/bin/Rscript --vanilla

library("biclustpl")

data <- readRDS("data/govtrack.rds")
x <- data$vote

K <- 2
L <- 4

set.seed(0)
fit <- biclust_dense(x, K, L, family="binomial", nstart=1000,
                     loglik_seq = TRUE)


cat("log-likelihoods found after", length(fit$loglik_seq),
    "random starts:\n")
print(table(factor(fit$loglik_seq)))

saveRDS(fit, "analysis/govtrack-fit.rds")
