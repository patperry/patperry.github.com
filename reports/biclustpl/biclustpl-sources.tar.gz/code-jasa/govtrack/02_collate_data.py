#!/usr/bin/env python3

import csv
import json
import os
import sys


def write_votes(file=sys.stdout):
    print('motion_id', '\t', 'legislator_id', '\t', 'vote', sep='', file=file)
    motions = set()
    legs = set()
    path = os.path.join('govtrackdata', 'congress', '113', 'votes')
    years = os.listdir(path)
    for y in years:
        year_path = os.path.join(path, y)
        votes = os.listdir(year_path)
        for v in votes:
            datafile = os.path.join(year_path, v, "data.json")
            with open(datafile, 'r') as fp:
                data = json.load(fp)

            if 'Nay' in data['votes'] and 'Yea' in data['votes']:
                vote_id = data['vote_id']
                motions.add(vote_id)
                for k in ['Nay', 'Yea']:
                    for l in data['votes'][k]:
                        legs.add(l['id'])
                        print(vote_id, '\t', l['id'], '\t', k, sep='',
                              file=file)
    return motions, legs


def amendment_info(data):
    if 'amendment' in data:
        return ['Yes',
                data['amendment'].get('author', None),
                data['amendment'].get('number', None),
                data['amendment'].get('type', None)]
    else:
        return ['No', None, None, None]

def bill_info(data):
    if 'bill' in data:
        return ['Yes',
                data['bill'].get('congress', None),
                data['bill'].get('number', None),
                data['bill'].get('type', None)]
    else:
        return ['No', None, None, None]


def write_motions(motions, file=sys.stdout):
    writer = csv.writer(file, delimiter='\t', quoting=csv.QUOTE_NONE)
    writer.writerow(['motion_id', 'has_amendment', 'amendment_author',
        'amendment_number', 'amendment_type', 'has_bill',
        'bill_congress', 'bill_number', 'bill_type',
        'category', 'chamber', 'congress', 'date', 'number', 'question',
        'requires', 'result', 'result_text', 'session', 'source_url',
        'type', 'updated_at'])

    path = os.path.join('govtrackdata', 'congress', '113', 'votes')
    years = os.listdir(path)
    for y in years:
        year_path = os.path.join(path, y)
        votes = os.listdir(year_path)
        for v in votes:
            datafile = os.path.join(year_path, v, "data.json")
            with open(datafile, 'r') as fp:
                data = json.load(fp)
            if data['vote_id'] in motions:
                writer.writerow([
                    data['vote_id']] +
                    amendment_info(data) +
                    bill_info(data) + [
                    data['category'],
                    data['chamber'],
                    data['congress'],
                    data['date'],
                    data['number'],
                    data['question'],
                    data['requires'],
                    data['result'],
                    data['result_text'],
                    data['session'],
                    data['source_url'],
                    data['type'],
                    data['updated_at']])



def write_legs(legs, file=sys.stdout):
    writer = csv.writer(file, delimiter='\t', quoting=csv.QUOTE_NONE)
    path = os.path.join('govtrackdata', 'congress-legislators')

    cpath = os.path.join(path, 'legislators-current.csv')
    hpath = os.path.join(path, 'legislators-historic.csv')

    with open(cpath, newline='') as cf, open(hpath, newline='') as hf:
        creader = csv.reader(cf)
        hreader = csv.reader(hf)

        header = next(creader)
        bioguide_id = header.index('bioguide_id')
        lis_id = header.index('lis_id')

        writer.writerow(["legislator_id"] + header)

        for row in creader:
            # we need two if statements (not elif) because there can
            # be duplicate ids (e.g. Ed Markey switch from House to Senate;
            # he has one id for Senate, and one id for House)
            if row[bioguide_id] in legs:
                legs.remove(row[bioguide_id])
                writer.writerow([row[bioguide_id]] + row)
            if row[lis_id] in legs:
                legs.remove(row[lis_id])
                writer.writerow([row[lis_id]] + row)

        next(hreader) # skip header
        for row in hreader:
            if row[bioguide_id] in legs:
                legs.remove(row[bioguide_id])
                writer.writerow([row[bioguide_id]] + row)
            if row[lis_id] in legs:
                legs.remove(row[lis_id])
                writer.writerow([row[lis_id]] + row)


def main():
    path = 'data'
    if not os.path.exists(path):
        os.makedirs(path)

    with open(os.path.join(path, 'votes.tsv'), 'w') as f:
        motions, legs = write_votes(f)

    with open(os.path.join(path, 'motions.tsv'), 'w', newline='') as f:
        write_motions(motions, f)

    with open(os.path.join(path, 'legislators.tsv'), 'w', newline='') as f:
        write_legs(legs, f)


if __name__ == '__main__':
    main()
