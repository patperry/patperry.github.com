#!/usr/bin/Rscript --vanilla


library("biclustpl")
library("RColorBrewer")
source("../code/heatmap-function.R")


data <- readRDS("data/govtrack.rds")
legs <- data$legs
motions <- data$motions

fit <- readRDS("analysis/govtrack-fit.rds")


# expected and observed row counts
row_exp <- (fit$row_sizes) * (fit$means[fit$row_cl,])
row_obs <- fit$row_sums

# expected and observed column counts
row_exp <- (fit$row_sizes) * (fit$means[fit$row_cl,])
row_obs <- fit$row_sums
row_resid <- (row_obs - row_exp) / sqrt(row_exp + 0.5)

col_exp <- (fit$col_sizes) * (t(fit$means)[fit$col_cl,])
col_obs <- fit$col_sums
col_resid <- (col_obs - col_exp) / sqrt(col_exp + 0.5)


q <- fit$row_clusters
r <- fit$col_clusters

r <- c(2,3,1,4)[r]
r <- r - 1
q <- q - 1


K <- max(fit$row_clusters)
L <- max(fit$col_clusters)

x <- data$vote
x <- x[order(q, rowSums(row_resid)),
       order(r, rowSums(col_resid))]

x[x == 0] <- -1
x[is.na(x)] <- 0

set1_pal <- brewer.pal(5, "Accent")
mypalette <- c(set1_pal[4], "#FFFFFF", set1_pal[5])

# Create Heatmap
csep<-matrix(0, 1, (L - 1))
for(i in 1:(L-1)){
  if((i-1) == 0 ){
	csep[i] <- sum((r == (i-1)))
  } else{
	csep[i] <- csep[(i-1)] + sum((r == (i-1)))
  }
}

rsep <- matrix(0, 1, (K - 1))
for(i in 1:(K - 1)){
  if((i - 1) == 0){
    rsep[i] <- sum((q == (i - 1)))
  } else{
    rsep[i] <- rsep[(i - 1)] + sum((q == (i - 1)))
  }
}

png("analysis/govtrack-heatmap.png", width=350, height=300)
heatmap.3(x,
          Rowv = NA, 
          Colv = NA, 
          scale = "none",
          main = "",
          labCol = "",
          labRow = "",
	      ylab = "Legislators", 
	      xlab= "Motions",
	      dendrogram = "none",
 	      density.info = "none",
	      trace = "none",
	      col = mypalette,
	      key = FALSE,
          colsep = csep,
          rowsep = rsep,
          sepcolor = "black",
	      sepwidth = c(.5, .5),
	      margins = c(2.5, 2.5),
	      lmat = rbind(c(0, 4, 0), c(3, 1, 0), c(0, 2, 0)), 
	      lhei = c(.2, 2.5, .5),
		  lwid = c(.5, 3, .2))

mtext("1", line=3, side=3, at=0.20, las=1, cex=.75)
mtext("2", line=3, side=3, at=0.4, las=1, cex=.75)
mtext("3", line=3, side=3, at=0.65, las=1, cex=.75)
mtext("4", line=3, side=3, at=0.9, las=1, cex=.75)
mtext("1", line=1.2, side=2, at=0.9, las=1, cex=.75)
mtext("2", line=1.2, side=2, at=0.3, las=1, cex=.75)
invisible(dev.off())


cat("Agreement between row clusters and political party:\n")
print(table(legs$party, fit$row_cl))
#                1   2
#  Democrat      0 202
#  Independent   0   0
#  Republican  234   0

#print(round(fit$means * 100, 1))
#      [,1] [,2]
# [1,] 97.7  1.4 # strong democratic support, mostly failed
# [2,] 62.1 73.5 # some bilateral support, mostly passed
# [3,] 99.3 97.7 # strong bilateral support, all passed
# [4,]  3.9 99.2 # strong republican support, mostly passed
# 

