#!/usr/bin/Rscript --vanilla

library("biclustpl")

data <- readRDS("data/govtrack.rds")

x <- data$vote

Kmax <- 10
Lmax <- 10

bc <- vector("list", Kmax)
for (K in seq_len(Kmax)) {
     bc[[K]] <- vector("list", Lmax)
     for (L in seq_len(Lmax)) {
         set.seed(0)
         bc[[K]][[L]] <- biclust_dense(x, K, L, family="binomial",
                                       nstart=10)
     }
}

loglik <- matrix(NA, Kmax, Lmax)
for (K in seq_len(Kmax)) {
    for (L in seq_len(Lmax)) {
        loglik[K,L] <- bc[[K]][[L]]$loglik
    }
}

K <- as.vector(row(loglik))
L <- as.vector(col(loglik))
loglik <- as.vector(loglik)

dir.create("analysis", showWarnings=FALSE)
write.table(data.frame(K, L, loglik), file="analysis/govtrack-models.tsv",
            quote=FALSE, sep="\t", row.names=FALSE)
