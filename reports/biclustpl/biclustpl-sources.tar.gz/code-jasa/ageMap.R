rm(list = ls())
gc()

path <- "/Users/cherylbrooks/biclustering/"

# load packages
#library("devtools")
#install_github("cjflynn/biclustpl")
library(biclustpl)

# Read in the data
data1 <- read.table(paste0(path, "code/data/cerebellum.csv.gz"), sep=",", header=TRUE, row.names=1)
X1 <- data1[, -match(c("sex", "age"), colnames(data1))]
data2 <- read.table(paste0(path, "code/data/cerebrum.csv.gz"), sep=",", header=TRUE, row.names=1)
X2 <- data2[, -match(c("sex", "age"), colnames(data2))]
X2 <- X2[-36, ]
X <- cbind(X1, X2)
X <- data.matrix(X)

p1 <- data1[, 1]
p2 <- data1[, 2]

m <- NROW(X)
n <- NCOL(X)
X.res <- matrix(0, m, n)
for(j in 1:n){
	y <- X[, j]
	X.res[, j] <- lm(y ~ p1 + p2)$residuals
}
X <- X.res
saveRDS(X, paste0(path, "/code/data/agemap-res-mat.rds"))


K.seq <- seq(1, 15)		# Row clusters
L.seq <- seq(1, 15)		# Column clusters
nstart <- 100

set.seed(100)
seed.seq <- sample(0:10000, size = length(K.seq) * length(L.seq), replace = FALSE)
seed.seq <- matrix(seed.seq, length(K.seq), length(L.seq))

start.time <- Sys.time()
for(i in 1:length(K.seq)){
  for(j in 1:length(L.seq)){
  	set.seed(seed.seq[i, j])
  	
  	# pl
  	# bc <- biclust_dense(X, K.seq[i], L.seq[j], family = "gaussian", nstart = nstart)
    
    # saveRDS(bc, paste0(path, "ageMap-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds"))  	
    bc <- readRDS(paste0(path, "ageMap-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds"))  
    
    # kmeans
    bc$kmeans_row <- kmeans(X, centers = K.seq[i], nstart = nstart, iter.max = 1000)
    bc$kmeans_col <- kmeans(t(X), centers = L.seq[j], nstart = nstart, iter.max = 1000)
    
    # di-sim
    X_svd <- svd(X, nu = n, nv = m)
    ns <- min(K.seq[i], L.seq[j])
    U <- X_svd$u[, 1:ns]
    V <- X_svd$v[, 1:ns]
    bc$disim_row <- kmeans(U, centers = K.seq[i], nstart = nstart, iter.max = 1000)$cluster
    bc$disim_col <- kmeans(V, centers = L.seq[j], nstart = nstart, iter.max = 1000)$cluster
    
    print(paste("sim", i, j))
  }
}
end.time <- Sys.time()
end.time - start.time


pl.mat <- matrix(NA, length(K.seq), length(L.seq))
for(i in 1:length(K.seq)){
  for(j in 1:length(L.seq)){
    tmp <- readRDS(paste0(path, "ageMap-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds"))
    pl.mat[i, j] <- tmp$loglik		
  }
}

color.seq <- rainbow(15)
plot(K.seq, pl.mat[, 2], col = color.seq[2], ylab = "loglik", xlab = "K", ylim = c(min(pl.mat), max(pl.mat) + 1000), xlim = c(0, 15),
     main = "Agemap Log-likelihood")
for(i in 3:15){
  points(K.seq, pl.mat[, i], col = color.seq[i])
}  
legend(0, 11000, paste0("L = ", seq(2, 15)), fill = color.seq[2:15], cex = .6)


color.seq <- rainbow(15)
plot(K.seq, pl.mat[2, ], col = color.seq[2], ylab = "loglik", xlab = "L", ylim = c(min(pl.mat), max(pl.mat) + 1000), xlim = c(0, 15),
     main = "Agemap Log-likelihood")
for(i in 3:15){
  points(L.seq, pl.mat[i, ], col = color.seq[i])
}  
legend(0, 11000, paste0("K = ", seq(2, 15)), fill = color.seq[2:15], cex = .6)

#########################################################################################
# Choose model
#########################################################################################
n <- sum(!is.na(X))
K <- rep(seq(1, 15), times = 15)
L <- rep(seq(1, 15), each = 15)

pl.mat <- matrix(NA, length(K.seq), length(L.seq))
for(i in 1:length(K.seq)){
  for(j in 1:length(L.seq)){
    tmp <- readRDS(paste0(path, "ageMap-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds"))
    pl.mat[i, j] <- tmp$loglik		
  }
}
loglik <- as.vector(pl.mat)

dev <- -2 * loglik / n


# make scree plot
pdf(paste0(path, "code/data/ageMap-scree.pdf"), width=6, height=3.25)

par(mfrow=c(1,2), las=1, ps=10)

par(mar=c(4.1, 4.1, 1.1, 0.55))
plot(K, dev, pch=L, xlab="K", ylab="Deviance", cex=0.6)
for (l in seq_len(max(L))) {
    i <- L == l
    lines(K[i], dev[i], lty=l)
}

par(mar=c(4.1, 0.55, 1.1, 4.1))
plot(L, dev, pch=K, xlab="L", ylab="", axes=FALSE, cex=0.6)
axis(1)
axis(4)
box()
for (k in seq_len(max(K))) {
    i <- K == k
    lines(L[i], dev[i], lty=k)
}

invisible(dev.off())

# print ad-hoc AIC/BIC table

# ad-hoc choice of k
k <- (K - 1) * nrow(X) + (L - 1) * ncol(X) + K * L
#k <- K * L
#n <- prod(dim(x))

aic <- -2 * loglik + 2 * k
aicc <- aic + 2 * k * (k + 1) / (n - k - 1)
bic <- -2 * loglik + k * log(n)

# choose model:
crit <- data.frame(K, L, dev = dev,
                   aic = aic - min(aic),
                   aicc = aicc - min(aicc),
                   bic = bic - min(bic))
                   
del <- L == 1
crit <- crit[!del, ]


#########################################################################################
# Heatmap
#########################################################################################
rm(list = ls())
gc()

path <- "/Users/cherylbrooks/biclustering/"

source(paste0(path, "code/heatmap-function.R"))

K <- 3
L <- 5
nstart <- 100

bc <- readRDS(paste0(path, "ageMap-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds"))
q <- bc$row_clusters
r <- bc$col_clusters

r.new <- r
r.new[r == 1] <- 4
r.new[r == 2] <- 1
r.new[r == 4] <- 2
r <- r.new - 1
q <- q - 1


X <- readRDS(paste0(path, "code/data/agemap-res-mat.rds"))

# Create Heatmap
csep<-matrix(0, 1, (L - 1))
for(i in 1:(L-1)){
  if((i-1) == 0 ){
	csep[i] <- sum((r == (i-1)))
  } else{
	csep[i] <- csep[(i-1)] + sum((r == (i-1)))
  }
}

rsep <- matrix(0, 1, (K - 1))
for(i in 1:(K - 1)){
  if((i - 1) == 0){
    rsep[i] <- sum((q == (i - 1)))
  } else{
    rsep[i] <- rsep[(i - 1)] + sum((q == (i - 1)))
  }
}

X <- X[order(q), order(r)]

library(RColorBrewer)
mypalette <- brewer.pal(3,"Blues")
mypalette <- sort(mypalette)
Sys.sleep(2)

library(gplots)

png(paste0(path, "code/data/AgemapRes_K3L5_heatmap.png"), width=400, height=300)
heatmap.3(X,
          Rowv = NA, 
          Colv = NA, 
          scale="none",
          main = "", 
          labCol = "", 
          labRow= "",
	      xlab = "Genes", 
	      ylab= "Mice",
	      dendrogram = "none",
 	      density.info = "none",
	      trace = "none", 
	      breaks = c(min(X), quantile(X, .25), quantile(X, .75), max(X)),
	      col = mypalette,
	      key = TRUE,
          colsep = csep,
          rowsep = rsep,
          sepcolor = "black",
	      sepwidth = c(.5, .01),
	      margins = c(2.5, 2.5),
	      lmat=rbind(c(0,4,0), c(3,1,0), c(0,2,0)), 
	      lhei=c( .2, 2, 1),
		  lwid=c( .5, 4, .5 ),
		  cex.axis=.7)
mtext("1", line=3, side=3, at=0.13, las=1, cex=.75)
mtext("2", line=3, side=3, at=0.335, las=1, cex=.75)
mtext("3", line=3, side=3, at=0.55, las=1, cex=.75)
mtext("4", line=3, side=3, at=0.8, las=1, cex=.75)
mtext("5", line=3, side=3, at=0.87, las=1, cex=.75)
mtext("1", line=2, side=2, at=1.08, las=1, cex=.75)
mtext("2", line=2, side=2, at=0.75, las=1, cex=.75)
mtext("3", line=2, side=2, at=0.43, las=1, cex=.75)
dev.off()

#########################################################################################
# Number of initializations
#########################################################################################
t1 <- Sys.time()
bc <- biclust_dense(X, 3, 5, family = "gaussian", nstart = 2000)
t2 <- Sys.time()
t2 - t1
saveRDS(bc, paste0(path, "code/data/ageMap-conv-check.rds"))
bc <- readRDS(paste0(path, "code/data/ageMap-conv-check.rds"))

table(bc$loglik.seq)

#7408.87208188119 7408.88082942328 7408.88082942329 7408.88285893846 
#             171             1299              528                2 

#########################################################################################
# Cluster agreement
#########################################################################################


library(combinat)

# this was designed to compute the misclassification rate for the simulations,
# but it can also be used more generally to compute cluster disagreement 
comp_err <- function(est_row, est_col, true_row, true_col){ 
  K <- max(true_row)
  L <- max(true_col)
 
  n <- length(true_row)
  m <- length(true_col)
 
  # determine the best permutation for the row clusters
  perm <- permn(seq(1, K))
  err_perm <- matrix(0, fact(K), 1)
  row_perm <- matrix(0, n, fact(K))
  for(i in 1:(fact(K))){
    for(j in 1:K){
      row_perm[(est_row == j), i] <- perm[[i]][j]
    }
      err_perm[i] <- sum((row_perm[, i] != true_row))
  }
  opt <- which.min(err_perm)[1]
  row_final <- row_perm[, opt]
 
  # determine the best permutation for the column clusters 
  perm <- permn(seq(1, L))
  err_perm <- matrix(0, fact(L), 1)
  col_perm <- matrix(0, m, fact(L))
  for(i in 1:(fact(L))){
    for(j in 1:L){
      col_perm[(est_col == j), i] <- perm[[i]][j]
    }
    err_perm[i] <- sum((col_perm[, i] != true_col))
  }
  opt <- which.min(err_perm)[1]
  col_final <- col_perm[, opt]
               
  # compute overall error
  err <- 0
  for(i in 1:n){
    for(j in 1:m){
      err <- err + ((row_final[i] != true_row[i]) || (col_final[j] != true_col[j]))
    }
  }
  err <- err / (n * m)
  return(err)
}

K <- 3
L <- 5
bc <- readRDS(paste0(path, "ageMap-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds"))

pl_disim <- comp_err(bc$row_clusters, bc$col_clusters, bc$disim_row, bc$disim_col)
#[1] 0.3757837
pl_km <- comp_err(bc$row_clusters, bc$col_clusters, bc$kmeans_row, bc$kmeans_col)
#[1] 0.1045119
km_disim <- comp_err(bc$disim_row, bc$disim_col, bc$kmeans_row, bc$kmeans_col)
#[1] 0.3215405


