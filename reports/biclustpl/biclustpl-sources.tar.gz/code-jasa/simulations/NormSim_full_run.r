# movie lens data example
# last updated: 10/18/2015

rm(list = ls())
gc()

.libPaths("/home/cflynn/R/library")

# change path to code and data as necessary
path <- "/home/cflynn/biclust/"

library(biclustpl)

# set parameters
b <- 2
nstart <- 100

alpha <- c(.2, .3, .5)
K <- length(alpha)

beta <- c(.3, .7)
L <- length(beta)

block.mat <- matrix(c(.47, .15, -.60, -.26, .82, .80), 3, 2)
block.mat <- b * block.mat

start.time <- Sys.time()
for(r in 1:500){
  n <- 400
  tau <- 2
  m <- tau * n
  
  sim <- r * 10
  set.seed(sim)

  # latent variable identifying the individual block
  c <- rmultinom(10000, size = 1, prob = alpha)               
  temp <- matrix(seq(1, K), K, 1)
  c <- t(c) %*% temp
  c <- c[1:n]

  # latent variable identifying object block
  d <- rmultinom(10000, size = 1, prob = beta)                
  temp <- matrix(seq(1, L), L, 1)
  d <- t(d) %*% temp
  d <- d[1:m]

  A <- matrix(NA, n, m)
  for(i in 1:n){
    for(j in 1:m){
      mu <- block.mat[c[i], d[j]]
      A[i, j] <- rnorm(1, mean = mu, sd = 1)
    }
  }
  
  #t1 <- Sys.time()
  #bc <- biclust_dense(A, K, L, family="gaussian", nstart=100)
  #t2 <- Sys.time()
  
  #bc$true_row <- c 
  #bc$true_col <- d
  
  #bc$kmeans_row <- kmeans(A, centers = K, nstart = nstart)$cluster
  #bc$kmeans_col <- kmeans(A, centers = L, nstart = nstart)$cluster
  
  #saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  bc <- readRDS(paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  bc$kmeans_col <- kmeans(t(A), centers = L, nstart = nstart)$cluster
  
  # Di-sim
  D1 <- rowSums(A)
	D2 <- colSums(A)
	An <- matrix(0, NROW(A), NCOL(A))
	for(i in 1:NROW(A)){
		for(j in 1:NCOL(A)){
			if(A[i, j] != 0){
				dr <- sqrt(abs(D1[i]))
				dc <- sqrt(abs(D2[j]))
				An[i, j] <- A[i, j] / (dr * dc)
			}
		}
	}
	A.svd <- svd(An, nu = n, nv = m)
	k <- min(K, L)
	U <- A.svd$u[,1:k]
	V <- A.svd$v[,1:k]
	bc$disim_row <- kmeans(U, centers = K, nstart = nstart)$cluster
	bc$disim_col <- kmeans(V, centers = L, nstart = nstart)$cluster
  
  saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  print(paste("sim ", r, n))
  
  n <- 300
  m <- tau * n
  A <- A[1:n, 1:m]
  
  # t1 <- Sys.time()
  # bc <- biclust_dense(A, K, L, family="gaussian", nstart=100)
  # t2 <- Sys.time()
  
  # bc$true_row <- c 
  # bc$true_col <- d
  
  # bc$kmeans_row <- kmeans(A, centers = K, nstart = nstart)$cluster
  # bc$kmeans_col <- kmeans(A, centers = L, nstart = nstart)$cluster
  
  # saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  # print(paste("sim ", r, n))
  
  bc <- readRDS(paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  bc$kmeans_col <- kmeans(t(A), centers = L, nstart = nstart)$cluster 
  
  # Di-sim
  D1 <- rowSums(A)
	D2 <- colSums(A)
	An <- matrix(0, NROW(A), NCOL(A))
	for(i in 1:NROW(A)){
		for(j in 1:NCOL(A)){
			if(A[i, j] != 0){
				dr <- sqrt(abs(D1[i]))
				dc <- sqrt(abs(D2[j]))
				An[i, j] <- A[i, j] / (dr * dc)
			}
		}
	}
	A.svd <- svd(An, nu = n, nv = m)
	k <- min(K, L)
	U <- A.svd$u[,1:k]
	V <- A.svd$v[,1:k]
	bc$disim_row <- kmeans(U, centers = K, nstart = nstart)$cluster
	bc$disim_col <- kmeans(V, centers = L, nstart = nstart)$cluster
  
  saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  print(paste("sim ", r, n))
  
  n <- 200
  m <- tau * n
  A <- A[1:n, 1:m]
  
  # t1 <- Sys.time()
  # bc <- biclust_dense(A, K, L, family="gaussian", nstart=100)
  # t2 <- Sys.time()
  
  # bc$true_row <- c 
  # bc$true_col <- d
  
  # bc$kmeans_row <- kmeans(A, centers = K, nstart = nstart)$cluster
  # bc$kmeans_col <- kmeans(A, centers = L, nstart = nstart)$cluster
  
  # saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  # print(paste("sim ", r, n))
  
  bc <- readRDS(paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  bc$kmeans_col <- kmeans(t(A), centers = L, nstart = nstart)$cluster
  
  # Di-sim
  D1 <- rowSums(A)
	D2 <- colSums(A)
	An <- matrix(0, NROW(A), NCOL(A))
	for(i in 1:NROW(A)){
		for(j in 1:NCOL(A)){
			if(A[i, j] != 0){
				dr <- sqrt(abs(D1[i]))
				dc <- sqrt(abs(D2[j]))
				An[i, j] <- A[i, j] / (dr * dc)
			}
		}
	}
	A.svd <- svd(An, nu = n, nv = m)
	k <- min(K, L)
	U <- A.svd$u[,1:k]
	V <- A.svd$v[,1:k]
	bc$disim_row <- kmeans(U, centers = K, nstart = nstart)$cluster
	bc$disim_col <- kmeans(V, centers = L, nstart = nstart)$cluster
  
  saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  print(paste("sim ", r, n))
  
  n <- 100
  m <- tau * n
  A <- A[1:n, 1:m]
  
  # t1 <- Sys.time()
  # bc <- biclust_dense(A, K, L, family="gaussian", nstart=100)
  # t2 <- Sys.time()
  
  # bc$true_row <- c 
  # bc$true_col <- d
  
  # bc$kmeans_row <- kmeans(A, centers = K, nstart = nstart)$cluster
  # bc$kmeans_col <- kmeans(A, centers = L, nstart = nstart)$cluster
  
  # saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  # print(paste("sim ", r, n))
  
  bc <- readRDS(paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))  
  bc$kmeans_col <- kmeans(t(A), centers = L, nstart = nstart)$cluster
  
  # Di-sim
  D1 <- rowSums(A)
	D2 <- colSums(A)
	An <- matrix(0, NROW(A), NCOL(A))
	for(i in 1:NROW(A)){
		for(j in 1:NCOL(A)){
			if(A[i, j] != 0){
				dr <- sqrt(abs(D1[i]))
				dc <- sqrt(abs(D2[j]))
				An[i, j] <- A[i, j] / (dr * dc)
			}
		}
	}
	A.svd <- svd(An, nu = n, nv = m)
	k <- min(K, L)
	U <- A.svd$u[,1:k]
	V <- A.svd$v[,1:k]
	bc$disim_row <- kmeans(U, centers = K, nstart = nstart)$cluster
	bc$disim_col <- kmeans(V, centers = L, nstart = nstart)$cluster

  saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  print(paste("sim ", r, n))
  
  n <- 50
  m <- tau * n
  A <- A[1:n, 1:m]
  
  # t1 <- Sys.time()
  # bc <- biclust_dense(A, K, L, family="gaussian", nstart=100)
  # t2 <- Sys.time()
  
  # bc$true_row <- c 
  # bc$true_col <- d
  
  # bc$kmeans_row <- kmeans(A, centers = K, nstart = nstart)$cluster
  # bc$kmeans_col <- kmeans(A, centers = L, nstart = nstart)$cluster
  
  # saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  # print(paste("sim ", r, n))
  
  bc <- readRDS(paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  bc$kmeans_col <- kmeans(t(A), centers = L, nstart = nstart)$cluster
  
  # Di-sim
  D1 <- rowSums(A)
	D2 <- colSums(A)
	An <- matrix(0, NROW(A), NCOL(A))
	for(i in 1:NROW(A)){
		for(j in 1:NCOL(A)){
			if(A[i, j] != 0){
				dr <- sqrt(abs(D1[i]))
				dc <- sqrt(abs(D2[j]))
				An[i, j] <- A[i, j] / (dr * dc)
			}
		}
	}
	A.svd <- svd(An, nu = n, nv = m)
	k <- min(K, L)
	U <- A.svd$u[,1:k]
	V <- A.svd$v[,1:k]
	bc$disim_row <- kmeans(U, centers = K, nstart = nstart)$cluster
	bc$disim_col <- kmeans(V, centers = L, nstart = nstart)$cluster
  
  saveRDS(bc, paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
  print(paste("sim ", r, n))
}
end.time <- Sys.time()
end.time - start.time




