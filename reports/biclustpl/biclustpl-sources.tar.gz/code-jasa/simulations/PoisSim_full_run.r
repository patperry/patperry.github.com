# movie lens data example
# last updated: 10/18/2015

rm(list = ls())
gc()

.libPaths("/home/cflynn/R/library")

# change path to code and data as necessary
path <- "/home/cflynn/biclust/"

library(biclustpl)

# set parameters
b <- 20
nstart <- 250

alpha <- c(.2, .3, .5)
K <- length(alpha)

beta <- c(.3, .7)
L <- length(beta)

n.seq <- c(200, 400, 600, 800, 1000, 1200, 1400, 1500)

start.time <- Sys.time()
for(j in 1:length(n.seq)){
  n <- n.seq[j]
  tau <- 2
  m <- tau * n
  
  block.mat <- matrix(c(.92, .77, 1.66, .17, 1.41, 1.45), 3, 2)
  block.mat <- (b * block.mat) / sqrt(n)
   
  for(r in 1:100){
    sim <- r * 10
    set.seed(sim)
    
    # latent variable identifying the individual block
    c <- rmultinom(10000, size = 1, prob = alpha)               
    temp <- matrix(seq(1, K), K, 1)
    c <- t(c) %*% temp
    c <- c[1:n]

    # latent variable identifying object block
    d <- rmultinom(10000, size = 1, prob = beta)                
    temp <- matrix(seq(1, L), L, 1)
    d <- t(d) %*% temp
    d <- d[1:m]

    A <- matrix(NA, n, m)
    for(i in 1:n){
      for(j in 1:m){
        lam <- block.mat[c[i], d[j]]
        A[i, j] <- rpois(1, lambda = lam)
      }
    }

    # t1 <- Sys.time()
    # bc <- biclust_dense(A, K, L, family="poisson", nstart=nstart)
    # t2 <- Sys.time()
    
    # bc$true_row <- c 
    # bc$true_col <- d
    
    # bc$kmeans_row <- kmeans(A, centers = K, nstart = nstart)$cluster
    # bc$kmeans_col <- kmeans(A, centers = L, nstart = nstart)$cluster
    
    # saveRDS(bc, paste0(path, "pois-sim/kl_sim", r, "_nstart", nstart, "_b", b, "_tau", tau, "_n", n, ".rds"))
    # print(paste("sim ", r, n))
    
    bc <- readRDS(paste0(path, "pois-sim/kl_sim", r, "_nstart", nstart, "_b", b, "_tau", tau, "_n", n, ".rds"))
    bc$kmeans_col <- kmeans(t(A), centers = L, nstart = nstart)$cluster
    
    # Di-sim
    D1 <- rowSums(A)
    D2 <- colSums(A)
    An <- matrix(0, NROW(A), NCOL(A))
    for(i in 1:NROW(A)){
      for(j in 1:NCOL(A)){
        if(A[i, j] != 0){
          dr <- sqrt(abs(D1[i]))
          dc <- sqrt(abs(D2[j]))
          An[i, j] <- A[i, j] / (dr * dc)
        }
      }
    }
    A.svd <- svd(An, nu = n, nv = m)
    k <- min(K, L)
    U <- A.svd$u[,1:k]
    V <- A.svd$v[,1:k]
    bc$disim_row <- kmeans(U, centers = K, nstart = nstart)$cluster
    bc$disim_col <- kmeans(V, centers = L, nstart = nstart)$cluster
    
    saveRDS(bc, paste0(path, "pois-sim/kl_sim", r, "_nstart", nstart, "_b", b, "_tau", tau, "_n", n, ".rds"))
    print(paste("sim ", r, n))  
  }
}
end.time <- Sys.time()
end.time - start.time




