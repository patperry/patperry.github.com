# simulation results
rm(list = ls())
.libPaths("/home/cflynn/R/library")
library(combinat)

comp_err <- function(est_row, est_col, true_row, true_col){  
  K <- max(true_row)
  L <- max(true_col)
  
  n <- length(true_row)
  m <- length(true_col)
  
  # determine the best permutation for the row clusters
  perm <- permn(seq(1, K))
	err_perm <- matrix(0, fact(K), 1)
	row_perm <- matrix(0, n, fact(K))
	for(i in 1:(fact(K))){
		for(j in 1:K){
			row_perm[(est_row == j), i] <- perm[[i]][j]
		}
		err_perm[i] <- sum((row_perm[, i] != true_row))
	}
	opt <- which.min(err_perm)[1]
	row_final <- row_perm[, opt]

  # determine the best permutation for the column clusters  
  perm <- permn(seq(1, L))
	err_perm <- matrix(0, fact(L), 1)
	col_perm <- matrix(0, m, fact(L))
	for(i in 1:(fact(L))){
		for(j in 1:L){
			col_perm[(est_col == j), i] <- perm[[i]][j]
		}
		err_perm[i] <- sum((col_perm[, i] != true_col))
	}
	opt <- which.min(err_perm)[1]
	col_final <- col_perm[, opt]
	
  # compute overall error
	err <- 0
	for(i in 1:n){
		for(j in 1:m){
			err <- err + ((row_final[i] != true_row[i]) || (col_final[j] != true_col[j]))
		}
	}
	err <- err / (n * m)
  return(err)
}

# change path to code and data as necessary
path <- "/home/cflynn/biclust/"

# set parameters
b.seq <- c(0.5, 1, 2)
tau.seq <- c(0.5, 1, 2)
n.seq <- c(50, 100, 200, 300, 400)
nstart <- 100
nsims <- 500

std.dev.norm <- matrix(NA, 1, 5)
colnames(std.dev.norm) <- c("b", "tau", "n", "method", "stddev")


pdf(paste0(path, "norm-sim-plots.pdf"), height = 3.5, width = 4.5)
par(mfrow = c(4, 3))
par(mgp = c(.8, .4, 0))
par(xpd = TRUE)
par(mar = c(2, 2.5, 1, 2))
for(i in 1:3){
  for(j in 1:3){
    b <- b.seq[j]
    tau <- tau.seq[i]    
    
    err.bc <- matrix(NA, nsims, length(n.seq))
    err.kmeans <- matrix(NA, nsims, length(n.seq))
    err.disim <- matrix(NA, nsims, length(n.seq))

    for(r in 1:nsims){
      for(h in 1:length(n.seq)){
        n <- n.seq[h]
      
        m <- tau * n
        bc <- readRDS(paste0(path, "norm-sim/kl_sim", r,"_tau", tau, "_n", n, "_b", b,".rds"))
      
        err.bc[r, h] <- comp_err(est_row = bc$row_clusters, est_col = bc$col_clusters, true_row = bc$true_row[1:n], true_col = bc$true_col[1:m])
        err.kmeans[r, h] <- comp_err(est_row = bc$kmeans_row, est_col = bc$kmeans_col, true_row = bc$true_row[1:n], true_col = bc$true_col[1:m])
        err.disim[r, h] <-  comp_err(est_row = bc$disim_row, est_col = bc$disim_col, true_row = bc$true_row[1:n], true_col = bc$true_col[1:m])
      }
    }
    mean.err.bc <- apply(err.bc, 2, mean)
    mean.err.kmeans <- apply(err.kmeans, 2, mean)
    mean.err.disim <- apply(err.disim, 2, mean)
    
    std.dev.norm <- rbind(std.dev.norm,
                           cbind(rep(b, length(n.seq)), rep(tau, length(n.seq)), rep("PL", length(n.seq)), n.seq, sqrt(apply(err.bc, 2, var))),
                           cbind(rep(b, length(n.seq)), rep(tau, length(n.seq)), rep("KM", length(n.seq)), n.seq, sqrt(apply(err.kmeans, 2, var))),
                           cbind(rep(b, length(n.seq)), rep(tau, length(n.seq)), rep("DS", length(n.seq)), n.seq, sqrt(apply(err.disim, 2, var))))
    
    plot(n.seq, mean.err.bc, main = paste0("m = ", tau, "n, b = ", b), ylab = "Avg Misclassification Rate", xlab = "n", type = "o",
         ylim = c(0, 0.7), cex.axis = .45, cex.lab = .5, cex = .4, cex.main = .7)
    lines(n.seq, mean.err.kmeans, type = "o", pch = 22, lty = 2, cex = .4)
    lines(n.seq, mean.err.disim, type = "o", pch = 23, lty = 3, cex = .4) 
  }
  print(paste0("i ", i))
}
par(mar=c(0,0,0.1,0))
plot(1, type = "n", axes = FALSE, xlab = "", ylab = "")
plot(1, type = "n", axes = FALSE, xlab = "", ylab = "")
legend(x = "top", inset = 0,
        legend = c("PL", "KM", "DI-SIM"), 
        pch=21:23, lty=1:3, horiz=TRUE, cex=.6)
plot(1, type = "n", axes = FALSE, xlab = "", ylab = "")
dev.off()

write.csv(std.dev.norm, paste0(path, "stddev-norm-sim.csv"), row.names = FALSE, quote = FALSE)


  
  
  
  
  
  
  
  
  
  
  