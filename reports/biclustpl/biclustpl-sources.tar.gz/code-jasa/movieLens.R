# movie lens data example
# last updated: 11/4/2015

rm(list = ls())
gc()

# change path to code and data as necessary
path <- "/Users/cherylbrooks/biclustering/"

# load packages
#library("devtools")
#install_github("cjflynn/biclustpl")
library(biclustpl)

norm_disim <- function(mat){
  nr <- NROW(mat)
  nc <- NCOL(mat)
	
  d1 <- rowSums(mat)
  d2 <- colSums(mat)
  mat_norm <- matrix(0, nr, nc)
	
  for(r in 1:nr){
	for(s in 1:nc){
	  if(mat[r, s] != 0){
	    dr <- sqrt(abs(d1[r]))
		dc <- sqrt(abs(d2[s]))
				
        mat_norm[r, s] <- mat[r, s] / (dr * dc)
      }
    }
  }
	
  return(mat_norm)
}


# load data
data <- as.matrix(read.table(paste0(path, "code/data/u.data"), header = FALSE))
X <- matrix(0, 943, 1682)
for(i in 1:NROW(data)){
  r <- data[i, 1]
  c <- data[i, 2]
  X[r, c] <- 1
}
#saveRDS(X, paste0(path, "code/data/movieLens-mat.rds"))
#X <- readRDS(paste0(path, "code/data/movieLens-mat.rds"))

K.seq <- seq(1, 10)		# Row clusters
L.seq <- seq(1, 10)		# Column clusters
nstart <- 250

set.seed(100)
seed.seq <- sample(0:10000, size = length(K.seq) * length(L.seq), replace = FALSE)
seed.seq <- matrix(seed.seq, length(K.seq), length(L.seq))

start.time <- Sys.time()
for(i in 1:length(K.seq)){
  for(j in 1:length(L.seq)){
  	set.seed(seed.seq[i, j])
  	
  	# pl
  	bc <- biclust_dense(X, K.seq[i], L.seq[j], family = "binomial", nstart = nstart)
    
    # kmeans
    bc$kmeans_row <- kmeans(X, centers = K.seq[i], nstart = nstart, iter.max = 50)$cluster
    bc$kmeans_col <- kmeans(t(X), centers = L.seq[j], nstart = nstart, iter.max = 50)$cluster
    
    # di-sim
    X_norm <- norm_disim(X)
    X_svd <- svd(X_norm, nu = NROW(X), nv = NCOL(X))
    ns <- min(K.seq[i], L.seq[j])
    U <- X_svd$u[, 1:ns]
    V <- X_svd$v[, 1:ns]
    bc$disim_row <- kmeans(U, centers = K.seq[i], nstart = nstart, iter.max = 50)$cluster
    bc$disim_col <- kmeans(V, centers = L.seq[j], nstart = nstart, iter.max = 50)$cluster
    
    saveRDS(bc, paste0(path, "movieLens-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds")) 
    
    print(paste("sim", i, j))
  }
}
end.time <- Sys.time()
end.time - start.time

pl.mat <- matrix(NA, length(K.seq), length(L.seq))
for(i in 1:length(K.seq)){
  for(j in 1:length(L.seq)){
    tmp <- readRDS(paste0(path, "movieLens-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds"))
    pl.mat[i, j] <- tmp$loglik		
  }
}

pdf(paste0(path, "code/data/MovieLens_chooseK.pdf"), height = 5, width = 5)
color.seq <- rainbow(10)
plot(K.seq, pl.mat[, 2], col = color.seq[2], ylab = "loglik", xlab = "K", ylim = c(min(pl.mat), max(pl.mat) + 10000), xlim = c(0, 10),
     main = "Movie Lens Log-likelihood")
for(i in 3:10){
  points(K.seq, pl.mat[, i], col = color.seq[i])
}  
legend(0, max(pl.mat) + 10000, paste0("L = ", seq(2, 10)), fill = color.seq[2:15], cex = .6)
dev.off()

pdf(paste0(path, "code/data/MovieLens_chooseL.pdf"), height = 5, width = 5)
color.seq <- rainbow(10)
plot(L.seq, pl.mat[2, ], col = color.seq[2], ylab = "loglik", xlab = "L", ylim = c(min(pl.mat), max(pl.mat) + 1000), xlim = c(0, 10),
     main = "Agemap Log-likelihood")
for(i in 3:10){
  points(L.seq, pl.mat[i, ], col = color.seq[i])
}  
legend(0, max(pl.mat) + 1000, paste0("K = ", seq(2, 10)), fill = color.seq[2:15], cex = .6)
dev.off()

#########################################################################################
# Choose model
#########################################################################################
n <- sum(!is.na(X))
K <- rep(seq(1, 10), times = 10)
L <- rep(seq(1, 10), each = 10)

pl.mat <- matrix(NA, length(K.seq), length(L.seq))
for(i in 1:length(K.seq)){
  for(j in 1:length(L.seq)){
    tmp <- readRDS(paste0(path, "movieLens-results/kl_K", K.seq[i], "_L", L.seq[j], "_nstart", nstart, ".rds"))
    pl.mat[i, j] <- tmp$loglik		
  }
}
loglik <- as.vector(pl.mat)

dev <- -2 * loglik / n

# make scree plot
pdf(paste0(path, "code/data/movieLens-scree.pdf"), width=6, height=3.25)

par(mfrow=c(1,2), las=1, ps=10)

par(mar=c(4.1, 4.1, 1.1, 0.55))
plot(K, dev, pch=L, xlab="K", ylab="Deviance", cex=0.6)
for (l in seq_len(max(L))) {
    i <- L == l
    lines(K[i], dev[i], lty=l)
}

par(mar=c(4.1, 0.55, 1.1, 4.1))
plot(L, dev, pch=K, xlab="L", ylab="", axes=FALSE, cex=0.6)
axis(1)
axis(4)
box()
for (k in seq_len(max(K))) {
    i <- K == k
    lines(L[i], dev[i], lty=k)
}

invisible(dev.off())

# print ad-hoc AIC/BIC table

# ad-hoc choice of k
k <- (K - 1) * nrow(X) + (L - 1) * ncol(X) + K * L
#n <- prod(dim(x))

aic <- -2 * loglik + 2 * k
aicc <- aic + 2 * k * (k + 1) / (n - k - 1)
bic <- -2 * loglik + k * log(n)

# choose model:
crit <- data.frame(K, L, dev = dev,
                   aic = aic - min(aic),
                   aicc = aicc - min(aicc),
                   bic = bic - min(bic))
print(crit)


#########################################################################################
# Heatmap
#########################################################################################
rm(list = ls())
gc()

path <- "/Users/cherylbrooks/biclustering/"

source(paste0(path, "code/heatmap-function.R"))

K <- 3
L <- 4
nstart <- 250

X <- readRDS(paste0(path, "code/data/movieLens-mat.rds"))

bc <- readRDS(paste0(path, "movieLens-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds")) 
q <- bc$row_clusters - 1
r <- bc$col_clusters - 1 

# Reorder based on degree
nrev <- colSums(X)
pop <- matrix(0, L, 1)
for(i in 1:L){
  pop[i] <- sum(nrev[r == (i - 1)]) / sum((r == (i - 1)))
}
pop <- order(pop, decreasing = FALSE)
pop <- pop - 1
r.new <- matrix(0, 1, length(r))
for(i in 1:length(r)){
  for(j in 1:L){
	if(r[i] == pop[j]){
	  r.new[i] <- (j - 1)
	}
  }
}
r <- r.new

# Reorder based on degree
nact <- rowSums(X)
act <- matrix(0, K, 1)
for(i in 1:K){
  act[i] <- sum(nact[q == (i - 1)]) / sum((q == (i - 1)))
}
act <- order(act, decreasing = FALSE)
act <- act - 1
q.new <- matrix(0, 1, length(q))
for(i in 1:length(q)){
  for(j in 1:K){
    if(q[i] == act[j]){
      q.new[i] <- (j - 1)
    }
  }
}
q <- q.new


# Create Heatmap
csep <- matrix(0, 1, (L - 1))
for(i in 1:(L - 1)){
  if((i - 1) == 0){
    csep[i] <- sum((r == (i - 1)))
  } else{
    csep[i] <- csep[(i - 1)] + sum((r == (i - 1)))
  }
}

rsep <- matrix(0, 1, (K - 1))
for(i in 1:(K - 1)){
  if((i-1) == 0){
    rsep[i] <- sum((q == (i - 1)))
  } else{
    rsep[i] <- rsep[(i - 1)] + sum((q == (i - 1)))
  }
}



# For review/non-review heatmap
library(RColorBrewer)
mypalette<-brewer.pal(3,"Blues")
mypalette<-sort(mypalette)
Sys.sleep(2)

library(gplots)
X <- X[order(q), order(r)]

png(paste0(path, "code/data/MovieLens_K3L4_heatmap.png"),width=350, height=300)
heatmap.3(X,
          Rowv = NA, 
          Colv = NA, 
          scale = "none",
          main = "",
          labCol = "",
          labRow = "",
	      ylab = "Individuals",
	      xlab = "Movies",
	      dendrogram = "none",
 	      density.info = "none",
	      trace = "none",
	      col = c(mypalette[1], "white"),
	      key = FALSE,
          colsep = csep,
          rowsep = rsep,
          sepcolor = "black",
	      sepwidth = c(.5, .5),
	      margins = c(2.5, 2.5),
	      lmat = rbind(c(0, 4, 0), c(3, 1, 0), c(0, 2, 0)), 
	      lhei = c(.2, 2.5, .5),
		  lwid = c(.5, 3, .2))
#mtext("1", line=3, side=3, at=0.17, las=1, cex=.75)
#mtext("2", line=3, side=3, at=0.5, las=1, cex=.75)
#mtext("3", line=3, side=3, at=0.7, las=1, cex=.75)
#mtext("4", line=3, side=3, at=0.82, las=1, cex=.75)
#mtext("5", line=3, side=3, at=0.9, las=1, cex=.75)
#mtext("6", line=3, side=3, at=0.95, las=1, cex=.75)
mtext("1", line=3, side=3, at=0.18, las=1, cex=.75)
mtext("2", line=3, side=3, at=0.56, las=1, cex=.75)
mtext("3", line=3, side=3, at=0.8, las=1, cex=.75)
mtext("4", line=3, side=3, at=0.92, las=1, cex=.75)
mtext("1", line=1.2, side=2, at=0.85, las=1, cex=.75)
mtext("2", line=1.2, side=2, at=0.32, las=1, cex=.75)
mtext("3", line=1.2, side=2, at=0.05, las=1, cex=.75)
dev.off()


#########################################################################################
# Number of initializations
#########################################################################################
set.seed(100)
t1 <- Sys.time()
bc <- biclust_dense(X, 3, 4, family = "binomial", nstart = 2000)
t2 <- Sys.time()
t2 - t1 # takes about 18 mins
saveRDS(bc, paste0(path, "code/data/movieLens-conv-check.rds"))
bc <- readRDS(paste0(path, "code/data/movieLens-conv-check.rds"))

table(bc$loglik.seq)

#-265185.322853951  -265185.32285395 -265184.155817133 -265183.189132433 
#                2                 3                 2                 3 
#-265183.055234856 -264085.243664126  -264070.07252269 -263891.880883557 
#                8                 2                 1                 1 
#-263891.843598788 -263891.842801237 -262923.928654098 -262919.237694841 
#                3                 8              1453                70 
#-262916.305201167  -262915.02467007 -262910.035593487 
#               11               123               310 
               
table(bc$loglik.seq[1:1000])

#-265185.322853951  -265185.32285395 -265184.155817133 -265183.055234856 
#                1                 2                 1                 6 
#-264085.243664126  -264070.07252269 -263891.843598788 -263891.842801237 
#                2                 1                 1                 3 
#-262923.928654098 -262919.237694841 -262916.305201167  -262915.02467007 
#              722                33                 8                67 
#-262910.035593487 
#              153 

#########################################################################################
# Cluster agreement
#########################################################################################


library(combinat)

# this was designed to compute the misclassification rate for the simulations,
# but it can also be used more generally to compute cluster disagreement 
comp_err <- function(est_row, est_col, true_row, true_col){ 
  K <- max(true_row)
  L <- max(true_col)
 
  n <- length(true_row)
  m <- length(true_col)
 
  # determine the best permutation for the row clusters
  perm <- permn(seq(1, K))
  err_perm <- matrix(0, fact(K), 1)
  row_perm <- matrix(0, n, fact(K))
  for(i in 1:(fact(K))){
    for(j in 1:K){
      row_perm[(est_row == j), i] <- perm[[i]][j]
    }
      err_perm[i] <- sum((row_perm[, i] != true_row))
  }
  opt <- which.min(err_perm)[1]
  row_final <- row_perm[, opt]
 
  # determine the best permutation for the column clusters 
  perm <- permn(seq(1, L))
  err_perm <- matrix(0, fact(L), 1)
  col_perm <- matrix(0, m, fact(L))
  for(i in 1:(fact(L))){
    for(j in 1:L){
      col_perm[(est_col == j), i] <- perm[[i]][j]
    }
    err_perm[i] <- sum((col_perm[, i] != true_col))
  }
  opt <- which.min(err_perm)[1]
  col_final <- col_perm[, opt]
               
  # compute overall error
  err <- 0
  for(i in 1:n){
    for(j in 1:m){
      err <- err + ((row_final[i] != true_row[i]) || (col_final[j] != true_col[j]))
    }
  }
  err <- err / (n * m)
  return(err)
}

K <- 3
L <- 4
bc <- readRDS(paste0(path, "movieLens-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds"))

pl_disim <- comp_err(bc$row_clusters, bc$col_clusters, bc$disim_row, bc$disim_col)
#[1] 0.7579574
pl_km <- comp_err(bc$row_clusters, bc$col_clusters, bc$kmeans_row, bc$kmeans_col)
#[1] 0.448337
km_disim <- comp_err(bc$disim_row, bc$disim_col, bc$kmeans_row, bc$kmeans_col)
#[1] 0.6881231

#########################################################################################
# Boxplot by year
#########################################################################################
K <- 3
L <- 4
nstart <- 250
bc <- readRDS(paste0(path, "movieLens-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds"))
r <- bc$col_clusters - 1

# Reorder based on degree
nrev <- colSums(X)
pop <- matrix(0, L, 1)
for(i in 1:L){
  pop[i] <- sum(nrev[r == (i - 1)]) / sum((r == (i - 1)))
}
pop <- order(pop, decreasing = FALSE)
pop <- pop - 1
r.new <- matrix(0, 1, length(r))
for(i in 1:length(r)){
  for(j in 1:L){
	if(r[i] == pop[j]){
	  r.new[i] <- (j - 1)
	}
  }
}
r <- r.new

year <- read.table(paste0(path, "code/data/year.txt"), header = FALSE)
yr1 <- year[r == 0, ]
yr2 <- year[r == 1, ]
yr3 <- year[r == 2, ]
yr4 <- year[r == 3, ]

pdf(paste0(path, "code/data/MovieLens_K3L4_bpYearAll.pdf"), width=5, height=4)
par(mar=c(5.1,4.1,2.1,2.1))
boxplot(list("Group 1" = yr1, "Group 2" = yr2, "Group 3" = yr3, "Group 4" = yr4),
	ylab = "Movie Year", main = "Release Years by Movie Group", cex.axis = .5, cex.main = .5, cex.lab = .5)
dev.off()

#########################################################################################
# Demographics
#########################################################################################
bc <- readRDS(paste0(path, "movieLens-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds"))
q <- bc$row_clusters
K <- length(unique(q))

# Reorder based on degree
nact <- rowSums(X)
act <- matrix(0, K, 1)
for(i in 1:K){
  act[i] <- sum(nact[q == i]) / sum((q == i))
}
act <- order(act, decreasing = FALSE)
act <- act
q.new <- matrix(0, 1, length(q))
for(i in 1:length(q)){
  for(j in 1:K){
    if(q[i] == act[j]){
      q.new[i] <- j
    }
  }
}
q <- q.new

user<-read.table(paste0(path, "code/data/u.user.txt"), header=FALSE, sep="|")
age.gr1 <- user[(q == 1), 2]
median(age.gr1)
#[1] 33

age.gr2 <- user[(q == 2) ,2]
median(age.gr2)
#[1] 30

age.gr3 <- user[(q == 3), 2]
median(age.gr3)
#[1] 29

gender.gr1 <- user[(q == 1), 3]
sum((gender.gr1 == "M")) / length(gender.gr1)
#[1] 0.6869245

gender.gr2 <- user[(q == 2), 3]
sum((gender.gr2 == "M")) / length(gender.gr2)
#[1] 0.7282609

gender.gr3 <- user[(q == 3), 3]
sum((gender.gr3 == "M")) / length(gender.gr3)
#[1] 0.7741935

sum((user[, 3] == "M")) / NROW(user)
#[1] 0.7104984

# Find top 10 (based on number of reviews) in each cluster 

#########################################################################################
# Find top 10 (based on number of reviews) in each cluster
#########################################################################################
K <- 3
L <- 4

bc <- readRDS(paste0(path, "movieLens-results/kl_K", K, "_L", L, "_nstart", nstart, ".rds"))
q <- bc$row_clusters - 1
r <- bc$col_clusters - 1

# Reorder based on degree
nrev <- colSums(X)
pop <- matrix(0, L, 1)
for(i in 1:L){
  pop[i] <- sum(nrev[r == (i - 1)]) / sum((r == (i - 1)))
}
pop <- order(pop, decreasing = FALSE)
pop <- pop - 1
r.new <- matrix(0, 1, length(r))
for(i in 1:length(r)){
  for(j in 1:L){
	if(r[i] == pop[j]){
	  r.new[i] <- (j - 1)
	}
  }
}
r <- r.new

r <- r + 1
bcsel <- matrix(0, 10, L)
nrev <- colSums(X)
for(i in 1:L){
	temp <- cbind(which(r == i), nrev[which(r == i)])
	temp <- temp[order(temp[, 2], decreasing = TRUE), ]
	bcsel[, i] <- temp[1:10, 1]
}

Sys.setlocale(category = "LC_ALL", locale = "C")

movies <- readLines(paste0(path, "code/data/u.item"))
movies <- strsplit(movies, split = "|", fixed = TRUE)
movies <- sapply(movies, function(x) x[2])

movies[bcsel[,1]]
movies[bcsel[,2]]
movies[bcsel[,3]]
movies[bcsel[,4]]


