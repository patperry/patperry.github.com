To install this package in R, run the commands:

    library("devtools")
    install("path/to/biclustpl") # replace by path on your hard drive

Once the package is installed, load it in R with `library("biclustpl")`.
