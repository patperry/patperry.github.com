# biclustering code
# last updated: 9/17/2015

# profile likelihood function for binomial distribution
prof_lik_bin <- function(sX, mk, nl){
	K <- length(mk)
	L <- length(nl)
	pl <- 0
	for(k in 1:K){
		for(l in 1:L){
			if((mk[k] == 0) || (nl[l] == 0) || (sX[k, l] == 0)){
				pl <- -10000000000
			} else{
				Xkl <- sX[k, l] / (mk[k] * nl[l])
				if( (Xkl == 1) ){ 
					pl <- -10000000000
				} else{
					f1 <- Xkl * log(Xkl) + (1 - Xkl) * log(1 - Xkl)
					pl <- pl + mk[k] * nl[l] * f1	
				}
			}
		}
	}
	return(pl)
}

# profile likelihood function for Poisson distribution
prof_lik_pois <- function(sX, mk, nl){
	K <- length(mk)
	L <- length(nl)
	pl <- 0
	for(k in 1:K){
		for(l in 1:L){
			if((mk[k] == 0) || (nl[l] == 0) || (sX[k, l] == 0)){
				pl <- -10000000000
			} else{
				Xkl <- sX[k, l] / (mk[k] * nl[l])
				if( (Xkl == 1) ){ 
					pl <- -10000000000
				} else{
					f1 <- sX[k, l] * log(Xkl)
					pl <- pl + f1
				}
			}
		}
	}
	return(0.5 * pl)
}

# profile likelihood function for normal distribution
prof_lik_norm <- function(sX, mk, nl){
	K <- length(mk)
	L <- length(nl)
	pl <- 0
	for(k in 1:K){
		for(l in 1:L){
			if((mk[k] == 0) || (nl[l] == 0)){
				pl <- -10000000000
			} else{
        f1 <- (sX[k, l])^2 / (mk[k] * nl[l])
        pl <- pl + f1
      }
		}
	}
	return(0.5 * pl)
}

prof_lik <- function(sX, mk, nl, method){
  out <- switch(method, "bin" = prof_lik_bin(sX, mk, nl),
                        "norm" = prof_lik_norm(sX, mk, nl),
                        "pois" = prof_lik_norm(sX, mk, nl))
  return(out)
}

# Compute row updates
rowImp <- function(sX, mk, nl, sX.r, g, F0, i, method){
	K <- length(mk)
	L <- length(nl)
	imp <- matrix(0,K,1)
	for(k in 1:K){
		sX.temp <- sX
		mk.temp <- mk
		if(g[i] != k){
			sX.temp[g[i], ] <- sX.temp[g[i], ] - sX.r[i, ]
			sX.temp[k, ] <- sX.temp[k, ] + sX.r[i, ]
			mk.temp[g[i]] <- mk.temp[g[i]] - 1
			mk.temp[k] <- mk.temp[k] + 1
      imp[k] <- prof_lik(sX.temp, mk.temp, nl, method) - F0
		}
		imp[g[i]] <- -10000000000
	}
	return(c(which.max(imp), max(imp)))
}

# Compute column updates
colImp <- function(sX, mk, nl, sX.c, h, F0, j, method){
  L <- length(nl)
  K <- length(mk)
  imp <- matrix(0, L, 1)
  for(l in 1:L){
    sX.temp <- sX
    nl.temp <- nl
    if(h[j] != l){
      sX.temp[, h[j]] <- sX.temp[, h[j]] - sX.c[j, ]
      sX.temp[, l] <- sX.temp[, l] + sX.c[j, ]
      nl.temp[h[j]] <- nl.temp[h[j]] - 1
      nl.temp[l] <- nl.temp[l] + 1
      imp[l] <- prof_lik(sX.temp, mk, nl.temp, method) - F0
    }
    imp[h[j]] <- -10000000000
  }
  return(c(which.max(imp), max(imp)))
}

# library(foreach)
# library(doMC)
# n.cores <- detectCores()
# registerDoMC(cores = 5)

# Determines the optimal biclusters using tabu search
biclust_tabu <- function(sX, sX.r, sX.c, g, h, mk, nl, method, n.tabu = 5, tol = 10^-6, max.iter = 10000){
  # sX: K x L matrix of block sums
  # sX.r: vector of row sums
  # sX.c: vector of column sums
  # g: initial clustering for the rows
  # h: initial clustering for the columns
  # mk: number in each row cluster
  # nl: number in each column cluster
  # method: c("bin", "pois", "norm")
  # n.tabu: number of iterations a node is considered "tabu"
  # tol: convergence criteria
  # max.iter: maximum number of iterations
  
  # Store the "tabu" entries
  tabu <- rep("0|0", n.tabu)
  
  # Initialize the prof-lik
  F0 <- prof_lik(sX, mk, nl, method)
  pl.seq <- F0
  
  # Iterate until convergence
  for(t in 1:max.iter){  	
    # Step 1: Compute the local updates
    r.Imp <- matrix(0, m, 2)
    for(i in 1:m){
      r.Imp[i, ] <- rowImp(sX, mk, nl, sX.r, g, F0, i, method)
    }
    
    # r.Imp <- foreach(s=1:m, .combine = 'rbind') %dopar%
               # rowImp(sX, mk, nl, sX.r, g, F0, s, method)
    r.Imp <- cbind(r.Imp, matrix(1, m, 1), matrix(seq(1, m), m, 1))
        
    c.Imp <- matrix(0, n, 2)
    for(j in 1:n){
      c.Imp[j, ] <- colImp(sX, mk, nl, sX.c, h, F0, j, method)
    }	
    # c.Imp <- foreach(s=1:n, .combine = 'rbind') %dopar%
               # colImp(sX, mk, nl, sX.c, h, F0, s, method)
    c.Imp <- cbind(c.Imp, matrix(2, n, 1), matrix(seq(1, n), n, 1))
    
    # Step 2: Make the label switch that optimizes the local improvement
    Imp <- rbind(r.Imp, c.Imp)
    Imp <- Imp[order(Imp[, 2], decreasing=TRUE), ]
    
    ## check to see if "tabu"
    sel <- 1
    while(paste0(Imp[sel, 3], "|", Imp[sel, 4]) %in% tabu){
      sel <- sel + 1
    }

    ## stop if no improvement
    if(Imp[sel, 2] <= tol){
      break;
    }	
    
    if(Imp[sel, 3] == 1){
      r.ind <- Imp[sel, 4]	#row index
      k1 <- g[r.ind]		#prev class
      k2 <- Imp[sel, 1]		#new class
      g[r.ind] <- k2
        
      # Update the profile likelihood
      sX[k1, ] <- sX[k1, ] - sX.r[r.ind, ]
      sX[k2, ] <- sX[k2, ] + sX.r[r.ind, ]
      mk[k1] <- mk[k1] - 1
      mk[k2] <- mk[k2] + 1
      F0 <- prof_lik(sX, mk, nl, method)			

      # Update column sums
      c.ind <- Xt@i[(Xt@p[r.ind] + 1):Xt@p[r.ind + 1]] + 1
      sX.c[c.ind, k1] <- sX.c[c.ind, k1] - X[r.ind, c.ind]
      sX.c[c.ind, k2] <- sX.c[c.ind, k2] + X[r.ind, c.ind]
    
    } else{
      c.ind <- Imp[sel, 4]	#column index
      L1 <- h[c.ind]		#prev class
      L2 <- Imp[sel, 1]		#new class
      h[c.ind] <- L2
        
      # Update the profile likelihood
      sX[, L1] <- sX[, L1] - sX.c[c.ind, ]
      sX[, L2] <- sX[, L2] + sX.c[c.ind, ]
      nl[L1] <- nl[L1] - 1
      nl[L2] <- nl[L2] + 1
      F0 <- prof_lik(sX, mk, nl, method)	

      # Update row sums
      r.ind <- X@i[(X@p[c.ind] + 1):X@p[c.ind + 1]] + 1
      sX.r[r.ind, L1] <- sX.r[r.ind, L1] - X[r.ind, c.ind]
      sX.r[r.ind, L2] <- sX.r[r.ind, L2] + X[r.ind, c.ind]
    }
      
    tabu <- c(paste0(Imp[sel, 3], "|", Imp[sel, 4]), tabu[1:(n.tabu - 1)])
    
    pl.seq <- c(pl.seq, F0)
    print(t)	
  }	
  return(list(prof.lik = F0,
              g = g,
              h = h,
              sX = sX,
              mk = mk,
              nl = nl,
              pl.seq = pl.seq))
}

biclust_kl <- function(sX, sX.r, sX.c, g, h, mk, nl, method, max.iter = 10000){
  # Determines the optimal biclusters using an algorithm based on the kernighan-lin heuristic
  #
  # sX: K x L matrix of block sums
  # sX.r: vector of row sums
  # sX.c: vector of column sums
  # g: initial clustering for the rows
  # h: initial clustering for the columns
  # mk: number in each row cluster
  # nl: number in each column cluster
  # method: c("bin", "pois", "norm")
  # max.iter: maximum number of iterations
  
  # Initialize the prof-lik
  F0 <- prof_lik(sX, mk, nl, method)
  pl.seq <- F0
  F1 <- F0
    
  # Iterate until convergence
  for(t in 1:max.iter){
  	F0 <- F1
    
    # Step 1: Compute the local updates
  	r.Imp <- matrix(0, m, 2)
	  for(i in 1:m){
		  r.Imp[i, ] <- rowImp(sX, mk, nl, sX.r, g, F0, i, method)
	  }
    # r.Imp <- foreach(s=1:m, .combine = 'rbind') %dopar%
	           # rowImp(sX, mk, nl, sX.r, g, F0, s, method)
    r.Imp <- cbind(r.Imp, matrix(1, m, 1), matrix(seq(1, m), m, 1))
	  	
    c.Imp <- matrix(0, n, 2)
    for(j in 1:n){
      c.Imp[j, ] <- colImp(sX, mk, nl, sX.c, h, F0, j, method)
    }		
    # c.Imp <- foreach(s=1:n, .combine = 'rbind') %dopar%
	           # colImp(sX, mk, nl, sX.c, h, F0, s, method)
    c.Imp <- cbind(c.Imp, matrix(2, n, 1), matrix(seq(1, n), n, 1))
	
    # Step 2: Update in order of local improvement
    Imp <- rbind(r.Imp, c.Imp)
    Imp <- Imp[order(Imp[, 2], decreasing=TRUE), ]
	
    g.new <- g
    h.new <- h
    sX2 <- sX
    sX.r2 <- sX.r
    sX.c2 <- sX.c
    mk2 <- mk
    nl2 <- nl
	
    for(i in 1:(m + n)){
      if(Imp[i, 3] == 1){
        r.ind <- Imp[i, 4]		
        k1 <- g[r.ind]		
        k2 <- Imp[i, 1]		
        g.new[r.ind] <- k2
        
        # Update the profile likelihood
        sX2[k1, ] <- sX2[k1, ] - sX.r2[r.ind, ]
        sX2[k2, ] <- sX2[k2, ] + sX.r2[r.ind, ]
        mk2[k1] <- mk2[k1] - 1
        mk2[k2] <- mk2[k2] + 1
        F2 <- prof_lik(sX2, mk2, nl2, method)
        
        if(F2 > F1){
          g <- g.new
          h <- h.new
          F1 <- F2
          sX <- sX2
          sX.r <- sX.r2
          sX.c <- sX.c2
          mk <- mk2
          nl <- nl2
        }

        # Update column sums
        c.ind <- Xt@i[(Xt@p[r.ind] + 1):Xt@p[r.ind + 1]] + 1
        sX.c2[c.ind, k1] <- sX.c2[c.ind, k1] - X[r.ind, c.ind]
        sX.c2[c.ind, k2] <- sX.c2[c.ind, k2] + X[r.ind, c.ind]
    
      } else{
        c.ind <- Imp[i, 4]		
        L1 <- h[c.ind]		
        L2 <- Imp[i, 1]		
        h.new[c.ind] <- L2
        
        # Update the profile likelihood
        sX2[, L1] <- sX2[, L1] - sX.c2[c.ind, ]
        sX2[, L2] <- sX2[, L2] + sX.c2[c.ind, ]
        nl2[L1] <- nl2[L1] - 1
        nl2[L2] <- nl2[L2] + 1
        F2 <- prof_lik(sX2, mk2, nl2, method)
        if(F2 > F1){
          g <- g.new
          h <- h.new
          F1 <- F2
          sX <- sX2
          sX.r <- sX.r2
          sX.c <- sX.c2
          mk <- mk2
          nl <- nl2
        }			

        # Update row sums
        r.ind <- X@i[(X@p[c.ind] + 1):X@p[c.ind + 1]] + 1
        sX.r2[r.ind, L1] <- sX.r2[r.ind, L1] - X[r.ind, c.ind]
        sX.r2[r.ind, L2] <- sX.r2[r.ind, L2] + X[r.ind, c.ind]
      }      
    }		
	  if(F1 == F0){break} 
	  print(t)	
  }	
  return(list(prof.lik = F1,
              g = g,
              h = h,
              sX = sX,
              mk = mk,
              nl = nl,
              pl.seq = pl.seq))
}

















