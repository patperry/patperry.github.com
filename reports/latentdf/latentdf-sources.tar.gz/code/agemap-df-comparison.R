# code/agemap-tstat.R

source("code/fit.R")
source("code/agemap.R")
source("code/palette.R")



agemap.df.comparison <- function(df.factor, df.gollob, df.mandel, filename, w = 3, h = w) {
    mar <- c(4,4,1,1) + .1
    mai <- mar * par("csi")

    pdf(filename, width=sum(w, mai[c(2,4)]), height=sum(h, mai[c(1,3)]))

    par(ps=10)
    par(mar=mar)
    par(las=1)

    lim <- c(1, max(df.factor, df.gollob, df.mandel))
    plot(df.factor[,1], df.factor[,2], col=2, cex=0.5,
         xlim=lim, ylim=lim,
         xlab="Factor 1 Degrees of Freedom",
         ylab="Factor 2 Degrees of Freedom")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)
    abline(v=df.gollob[1], col="black", lty=2)
    abline(h=df.gollob[2], col="black", lty=2)

    abline(v=df.mandel[1], col="black", lty=3)
    abline(h=df.mandel[2], col="black", lty=3)

    legend("topleft", inset=0.05, legend=c("Proposed Method", "Gollob", "Mandel"),
           lty=c(NA, 2, 3), col=c(2, "black", "black"), pch=c(1, NA, NA),
           bg="white")
}



# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# problem dimensions
m <- ncol(y)
n <- nrow(y)
p <- ncol(x)
q <- ncol(z)


# fit the model
K <- 2
model <- fit.model(y, x, z, nfactor = K)
df.factor <- model$df.factor

k <- seq_len(K)
df.gollob <- ((n - p - k + 1) + (m - q - k + 1) - 1) / (m-q)
df.mandel <- rep((sqrt(m-q) + sqrt(n-p))^2 / (m-q), K)

# generate the figure
agemap.df.comparison(df.factor, df.gollob, df.mandel, "figs/agemap-df-comparison.pdf")

