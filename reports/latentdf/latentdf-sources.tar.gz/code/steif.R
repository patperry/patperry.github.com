# code/steif.R


rsteif <- function(nrow, ncol = nrow) {
    n <- nrow
    p <- ncol

    z <- matrix(rnorm(n * p), n, p)
    q <- qr.Q(qr(z))
    s <- sample(c(-1, 1), p, replace=TRUE)

    u <- q %*% diag(s, p)
    u
}


