# code/agemap-cluster.R


require("RColorBrewer")
source("code/fit.R")
source("code/agemap.R")



agemap.cluster <- function() {
    old.seed.exists <- exists(".Random.seed", envir = .GlobalEnv)
    if (old.seed.exists) {
        old.seed <- get(".Random.seed", envir = .GlobalEnv)
    }
    set.seed(0, "Mersenne-Twister")

    # read in the data
    data <- read.agemap()

    # extract predictors and response
    x <- model.matrix(~ age + sex, data$rows)
    z <- model.matrix(~ tissue, data$cols)
    y <- data$log.activation

    # fit the model
    model <- fit.model(y, x, z, nfactor = 2)

    # extract the factor scores
    u1 <- model$factor.scores[,1]
    u2 <- model$factor.scores[,2]

    # cluster the scores
    km <- kmeans(cbind(u1, u2), 3, nstart=100)
    class <- km$cluster

    # reorder by u1
    o1 <- order(km$centers[,1])
    cluster <- km$cluster
    centers <- km$centers[o1,]
    dimnames(centers) <- NULL

    cluster[cluster == o1[1]] <- 4
    cluster[cluster == o1[2]] <- 5
    cluster[cluster == o1[3]] <- 6
    cluster <- cluster - 3

    pch <- 2 + 1:3
    col <- brewer.pal(3, "Set2")

    if (old.seed.exists) {
        assign(".Random.seed", old.seed, envir = .GlobalEnv)
    } else {
        remove(".Random.seed", envir = .GlobalEnv)
    }
    list(cluster = cluster, centers = centers, pch = pch, col = col)
}
