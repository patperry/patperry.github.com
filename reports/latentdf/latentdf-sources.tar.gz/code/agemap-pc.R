# code/agemap-pc.R

source("code/fit.R")
source("code/agemap.R")
source("code/agemap-cluster.R")
source("code/palette.R")
source("code/agemap-scatter.R")



# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# fit the model
model <- fit.model(y, x, z, nfactor = 2)

# extract the factor scores
u1 <- model$factor.scores[,1]
u2 <- model$factor.scores[,2]
sex <- data$rows$sex
age <- data$rows$age

# get the clusters
km <- agemap.cluster()

# generate the figure
agemap.scatter2(sex, age, u1, u2, "figs/agemap-pc.pdf",
    xlab = "First Factor Score",
    ylab = "Second Factor Score",
    annotate = function() {
        points(km$centers[,1], km$centers[,2], pch=km$pch, col=km$col)
    }
    )


