# code/sim-signal.R

source("code/palette.R")


set.seed(0, "Mersenne-Twister")
ns <- c(5, 10, 50, 100)
ms <- c(5, 10, 50, 100, 500, 1000, 5000, 10000)
ds <- c(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000)
nrep <- 1000
nfactor.max <- 5


if (!file.exists("data/sim-signal")) {
    dir.create("data/sim-signal")
}

for (m in ms) {
    for (n in ns) {
        for (d in ds) {
            cat("m = ", m,
                "; n = ", n,
                "; d = ", d,
                "\n", sep="")

            filename <- paste("data/sim-signal/sim",
                              "_n", n,
                              "_m", m,
                              "_d", d,
                              ".rds", sep="")

            sim <- run.sim(nrow=n, ncol=m, signals=d, nfactor.max=5, nrep=nrep)

            saveRDS(sim, file = filename)
        }
    }
}





nrow <- c()
ncol <- c()
signal <- c()
df <- c()
dfapprox <- c()
dfhat <- c()
dfhat.se <- c()
dferr <- c()
dferr.se <- c()
sigma.est0.mean <- c()
sigma.est0.sd <- c()
sigma.est.mean <- c()
sigma.est.sd <- c()

for (m in ms) {
    for (n in ns) {
        for (d in ds) {
            filename <- paste("data/sim-signal/sim",
                              "_n", n,
                              "_m", m,
                              "_d", d,
                              ".rds", sep="")

            if (!file.exists(filename))
                next

            sim <- readRDS(file = filename)
            nrow <- c(nrow, sim$nrow)
            ncol <- c(ncol, sim$ncol)
            signal <- c(signal, sim$signals[1])

            n <- sim$nrow
            m <- sim$ncol
            mu <- (sim$signal[1])^2
            if (mu > sqrt(m/n)) {
                #dftrue <- (n + m * (1 + 1/mu)
                #           + (2 * sqrt(m * n * (mu + 1))
                #              * (1 + 1/mu) * sqrt(1 - (m/n)/mu^2)))
                dftrue <- (n + m * (1 + 1/mu)) / m
            } else {
                dftrue <- NA
            }

            sigma.est0 <- sqrt(apply(sim$dhat[,-1]^2, 1, sum) / m)
            dfemp <- (n - sim$rss[,1]) #/ (sim$v1[,1])^2 # empirical df (scaled)
            #dfest <- ((n + m + 2 * sqrt(m * n * (1 + (sim$dhat[,1]/sigma.est0)^2)))
            #          * sim$vhat1[,1]^2)
            dfest <- ((n + m * (1 + sigma.est0^2 / (sim$dhat[,1]^2
                                                    - sigma.est0^2)))
                      * sim$vhat1[,1]^2)
            dfest <- pmin(dfest, n - 1)
            sigma.est <- sqrt(sim$rss[,1] / (n - dfest))

            err <- dftrue * sim$v1[,1]^2 - dfest

            df <- c(df, dftrue)
            dfapprox <- c(dfapprox, n + m + 2 * sqrt(m * n * (mu + 1)))
            dfhat <- c(dfhat, mean(dfemp))
            dfhat.se <- c(dfhat.se, sd(dfemp) / sqrt(length(dfemp)))
            dferr <- c(dferr, mean(err))
            dferr.se <- c(dferr.se, sd(err) / sqrt(length(err)))
            sigma.est0.mean <- c(sigma.est0.mean, mean(sigma.est0))
            sigma.est0.sd <- c(sigma.est0.sd, sd(sigma.est0))
            sigma.est.mean <- c(sigma.est.mean, mean(sigma.est))
            sigma.est.sd <- c(sigma.est.sd, sd(sigma.est))
        }
    }
}

data <- data.frame(nrow, ncol, signal, df, dfapprox, dfhat, dfhat.se, dferr,
                   dferr.se, sigma.est0.mean, sigma.est0.sd, sigma.est.mean,
                   sigma.est.sd)





with(subset(data, nrow * ncol >= 2500 & signal > sqrt(ncol / nrow)), {
    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 1.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    #pdf("figs/sim-signal-dfcurve.pdf",
    #    width = sum(w, mai[c(2,4)]),
    #    height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    x <- sqrt(nrow / ncol)
    y.est <- dfhat
    y.true <- df
    xx <- c(x,x)
    yy <- c(y.est, y.true)
    plot(1/xx, yy, t="n", xlab="Square Root (Rows/Columns)",
         ylab="Degrees of Freedom")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)
    xgrid <- seq(0, 35, len=100) #, seq(.2, 2, len=50))

    signal.unique <- sort(unique(signal))
    col.curve <- brewer.pal(length(signal.unique) + 1, "Reds")[-1]
    col.point <- brewer.pal(length(signal.unique) + 1, "Blues")[-1]
    for (k in seq_along(signal.unique)) {
        mu <- signal.unique[k]
        lines(xgrid,
              (1/xgrid)^2 + 1 + 1/mu,
              #log10((1 + 2 * xgrid * sqrt(mu + 1)) + xgrid^2),
              #log10((1 + 2 * xgrid * sqrt(mu + 1)) * (1 + 1/mu) + xgrid^2),
              col=col.curve[k])
        points(1/x[signal == mu], dfhat[signal == mu], col=col.point[k])
    }


    #dev.off()
})





with(subset(data, nrow >= 10 & ncol >= 50 & !is.na(df) & signal <= 10), {
#                  & (signal == 2 | signal == 5 | signal == 10)), {

    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 1.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    pdf("figs/sim-signal-zstat.pdf",
        width = sum(w, mai[c(2,4)]),
        height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    zstat <- (dfhat - df) / dfhat.se

    x <- (seq_along(zstat) - 0.5) / length(zstat)
    y <- sort(zstat)
    plot(x, y, col=2,
         xlab="Relative Rank",
         ylab="Z Statistic for Signal Simulation")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)

    dev.off()

    })


with(subset(data, nrow >= 10 & ncol >= 50 & !is.na(df)), {
     plot(df / ncol, dferr / ncol)
    })


