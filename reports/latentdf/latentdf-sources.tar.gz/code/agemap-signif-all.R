
library("dplyr")
source("code/fit.R")



dir <- "data/agemap"
data <- list()
for (f in list.files(dir)) {
    tis <- substr(f, 1, nchar(f) - 4)
    data[[tis]] <- read.table(paste0(dir, "/", f), sep = ",", header = TRUE,
                              row.names = 1)
}

# strip off tissue prefix from row names
for (i in seq_along(data)) {
    d <- data[[i]]
    rn <- rownames(d)
    rownames(d) <- substr(rn, nchar(rn) - 3, nchar(rn))
    data[[i]] <- d
}


for (i in seq_along(data)) {
    d <- data[[i]]
    cols0 <- match(c("sex", "age"), colnames(d))
    dr <- d[, cols0]
    dr$sex <- factor(ifelse(dr$sex == 1, "F", "M"), levels=c("F", "M"))
    
    dc <- matrix(0, ncol(d) - 2, 0)
    rownames(dc) <- colnames(d)[-cols0]
    dc <- as.data.frame(dc)

    y <- as.matrix(d[, -cols0])
    rownames(y) <- rownames(dr)
    colnames(y) <- rownames(dc)

    data[[i]] <- list(rows = dr, cols = dc, log.activation = y)
}

res <- list()
for (i in seq_along(data)) {
    d <- data[[i]]
    x <- model.matrix(~ age + sex, d$rows)
    z <- model.matrix(~ 1, d$cols)
    y <- d$log.activation

    # problem dimensions
    m <- ncol(y)
    n <- nrow(y)
    p <- ncol(x)
    q <- ncol(z)

    # fit the model
    K <- 2
    model <- fit.model(y, x, z, nfactor = K)

    # extract the t statistics for age
    t0 <- model$tstat0[, "age"]
    t1 <- model$tstat[, "age"]
    df0 <- model$df.resid0
    df1 <- model$df.resid

    z0 <- qnorm(pt(t0, df=df0))
    z1 <- qnorm(pt(t1, df=df1))

    alpha <- 0.001
    cutoff <- qnorm(alpha/2, lower.tail=FALSE)
    signif0 <- abs(z0) > max(cutoff)
    signif1 <- abs(z1) > max(cutoff)

    gene <- colnames(y)
    pval0 <- 2 * pnorm(-abs(z0))
    pval1 <- 2 * pnorm(-abs(z1))
    res[[i]] <- data.frame(tissue = names(data)[[i]], gene = gene,
                           pval0 = pval0, pval1 = pval1)
}

res <- do.call("rbind", res)



print(res %>% group_by(tissue)
      %>% summarize(signif0 = sum(pval0 < .001), signif1 = sum(pval1 < .001)))
