# code/sim.R
# ----------

set.seed(0)


m <- 100 # number of response variable
n <- 20  # number of samples (assumed even)

# design and response matrices
x <- cbind(rep(1, n))                   # design matrix (just an intercept)
u <- cbind(rep(c(-1, 1), each = n / 2)) # dense latent variable, euclidean norm sqrt(n)
u <- matrix(0, n, 1); u[1] <- -sqrt(n/2); u[n] <- +sqrt(n/2) # sparse latent variable
p <- ncol(x)
q <- ncol(u)

# coefficients
beta <- matrix(rnorm(p * m), p, m)

# gamma chosen uniformly over sphere
gamma <- matrix(rnorm(q * m), q, m)
gamma <- sqrt(m) %*% t(qr.Q(qr(t(gamma)))) 

# sparse gamma
# gamma <- matrix(0, q, m); diag(gamma) <- sqrt(m)

# error distribution
# mimic the agemap variances; inverse gamma with mean(sigma2) = 1, var(sigma2) = 1
shape.sigma2 <- 3             
scale.sigma2 <- 1/(shape.sigma2 - 1)
sigma2 <- 1/rgamma(m, shape = shape.sigma2, scale = scale.sigma2)


nlambda <- 50
nreps <- 200
lambda <- seq(0, 1, len = nlambda)

ucorr2 <- matrix(NA, nreps, nlambda)
lest <- matrix(NA, nreps, nlambda)
rss <- array(NA, c(nreps, nlambda, m))

for (r in seq_len(nreps)) {
    set.seed(r)
    eps <- matrix(rnorm(n * m, sd = sqrt(sigma2)), n, m, byrow = TRUE)
    for (i in seq_along(lambda)) {
        y <- x %*% beta + (sqrt(lambda[i]) * u) %*% gamma + eps
        resid <- qr.resid(qr(x), y)
        svd.resid <- svd(resid)
        u1 <- svd.resid$u[,1]
        d1 <- svd.resid$d[1]
        v1 <- svd.resid$v[,1]
        resid1 <- resid - (d1 * u1) %*% rbind(v1)

        lest[r,i] <- (d1 / sqrt(n * m))^2
        ucorr2[r,i] <- (t(u) %*% u1 / sqrt(n))^2
        rss[r,i,] <- apply(resid1^2, 2, sum)
    }
}

ucorr2.mean <- apply(ucorr2, 2, mean)
lest.mean <- apply(lest, 2, mean)
rss.mean <- apply(rss, c(2,3), mean)

df <- (n - p) - scale(rss.mean, center = FALSE, scale = sigma2)
df.summary <- t(apply(df, 1, summary))

par(mfrow=c(1,1))
plot(ucorr2.mean, df.summary[,"Median"],
     xlim = c(0.5, 1),
     ylim = range(df.summary),
     xlab = "ucorr", ylab="df")
segments(ucorr2.mean, df.summary[,"1st Qu."], ucorr2.mean, df.summary[,"3rd Qu."], col = 1)
points(ucorr2.mean, df.summary[,"Mean"], pch = 2, col = 1)
points(ucorr2.mean, df.summary[,"Min."], pch = 3, col = 1)
points(ucorr2.mean, df.summary[,"Max."], pch = 3, col = 1)
