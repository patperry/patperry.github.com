# code/sim.R
# ----------

set.seed(0)


m <- 100 # number of response variable
n <- 10  # number of samples

# design matrix
x <- matrix(NA, n, 0)
p <- ncol(x)

# coefficients
beta <- matrix(rnorm(p * m), p, m)

# inverse gamma with mean(sigma2) = 1
shape.sigma2 <- 1 + 1e+3 # 1e1 # 1e2 # 1e3
scale.sigma2 <- 1/(shape.sigma2 - 1)
sigma2 <- 1/rgamma(m, shape = shape.sigma2, scale = scale.sigma2)

nreps <- 10000

lambda <- array(NA, c(min(m, n), nreps))
v <- array(NA, c(m, nreps))
rss0 <- array(NA, c(m, nreps))
rss1 <- array(NA, dim(rss0))

for (r in seq_len(nreps)) {
    eps <- matrix(rnorm(n * m, sd = sqrt(sigma2)), n, m, byrow = TRUE)
    y <- x %*% beta + eps
    resid0 <- qr.resid(qr(x), y)
    udv <- svd(resid0)
    u1 <- udv$u[,1]
    d1 <- udv$d[1]
    v1 <- udv$v[,1]
    resid1 <- resid0 - (d1 * u1) %*% rbind(v1)

    lambda[,r] <- udv$d^2
    v[,r] <- v1
    rss0[,r] <- colSums(resid0^2)
    rss1[,r] <- colSums(resid1^2)
}

sim <- data.frame(sigma2 = sigma2,
                  rss0.mean = apply(rss0, 1, mean),
                  rss0.sd = apply(rss0, 1, sd),
                  rss1.mean = apply(rss1, 1, mean),
                  rss1.sd = apply(rss1, 1, sd),
                  v2 = apply(v^2, 1, mean))

par(mfrow=c(1,3))

plot(sort(sigma2),
     main=paste("cv =", format(sd(sigma2) / mean(sigma2), digits=3)))

plot(rowMeans(lambda) / sum(rowMeans(lambda)),
     xlab="Component", ylab="Variance Explained",
     main="Scree Plot")

# linear for small values of sigma2, but not for large?
df <- n - with(sim, median(rss1.mean / sigma2))
plot(rss1.mean ~ sigma2, sim,
     main=paste("df =", format(df, digits=3)))
abline(0, n - df, col=2)

#plot(v2 ~ sigma2, sim)
#plot(I(1 / v2) ~ I(1/sigma2), sim)
