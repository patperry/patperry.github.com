# code/sim-signal-dfcurve.R

source("code/palette.R")


data <- readRDS("data/cleaned/sim-signal.rds")

args <- commandArgs(trailingOnly = TRUE)

for (filename in args) {
    vector.type <- gsub("^sim-signal-dfcurve-([^.]*)\\.pdf$", "\\1", basename(filename), perl=TRUE)

with(subset(data, nrow * ncol >= 1000 & signal > 0 * sqrt(ncol / nrow) & vector == vector.type), {
    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 2.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    pdf(filename,
        width = sum(w, mai[c(2,4)]),
        height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    x <- log10(nrow / ncol)

    if (vector.type == "ones" || vector.type == "pones" || vector.type == "pbasis") {
        y <- dfhat
        r <- dfhat.se
        ylab <- "Degrees of Freedom"
    } else if (vector.type == "basis") {
        y <- dfhat / nrow
        r <- dfhat.se / nrow
        ylab <- "(Degrees of Freedom) / Rows"
    }

    main <- switch(vector.type,
                   basis = "Basis", ones = "Ones",
                   pbasis = "Perp. Basis", pones = "Perp. Ones")

    plot(range(x), range(y - r, y + r), t="n",
         xlab=expression(Log[10](Rows/Columns)),
         ylab=ylab)
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)
    title(main=paste("Signal:", main), line = 1.25, outer = FALSE)

    fin <- par("fin")
    plt <- par("plt")
    usr <- par("usr")
    rscale <- (((usr[2] - usr[1])/(usr[4] - usr[3]))
                * ((fin[2] - mai[1] - mai[3]) / (fin[1] - mai[2] - mai[4])))
    xgrid <- 10^seq(usr[1], usr[2], len=500)
    signal.unique <- sort(unique(signal))

    col.curve <- brewer.pal(length(signal.unique) + 1, "Reds")[-1]
    col.point <- brewer.pal(length(signal.unique) + 1, "Blues")[-1]

    for (k in seq_along(signal.unique)) {
        mu <- signal.unique[k]
        if (vector.type == "ones") {
            lines(log10(xgrid), ifelse(mu > sqrt(1/xgrid), (xgrid) + 1 + 1/mu,
                                            (1 + sqrt(xgrid))^2 - mu * xgrid),
                  col=col.curve[k])
        } else if (vector.type == "basis") {
            lines(log10(xgrid), ifelse(mu > sqrt(1/xgrid), 1 - 1 / xgrid / mu - 1 / xgrid / mu^2,
                                       -mu),
                  col=col.curve[k])
        } else if (vector.type == "pones" || vector.type == "pbasis") {
            lines(log10(xgrid), ifelse(mu > sqrt(1/xgrid), (1 + 1/mu)^2, 
                                       (1 + sqrt(xgrid))^2),
                  col=col.curve[k])
        }
    }
    for (k in seq_along(signal.unique)) {
        mu <- signal.unique[k]
        symbols(x[signal == mu], y[signal == mu],
                circles=r[signal == mu] * rscale, inches=FALSE, fg=col.point[k], add=TRUE)
        points(x[signal == mu], y[signal == mu], col=col.point[k], pch=1 + k, cex=.25)
    }

    dev.off()
    })

}
