# code/agemap-time-trend.R

source("code/fit.R")
source("code/agemap.R")


# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
x <- cbind(x, age2=x[,"age"]^2) # add quadratic time trend
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

model0 <- fit.model(y, x, z, nfactor = 0)



x1 <- cbind(x, age3=x[,"age"]^3) # add cubic time trend
model1 <- fit.model(y, x1, z, nfactor = 0)


model <- model0
df <- model$df.resid
tstat <- model$tstat[, "age2"]
pval <- pt(tstat, df=df)
zstat <- qnorm(pval)

print(mean(abs(zstat) > -qnorm(.05/2)))
# [1] 0.04590237

print(mean(abs(zstat) > -qnorm(.01/2)))
# [1] 0.009516346



model <- model1
df <- model$df.resid
tstat <- model$tstat[, "age3"]
pval <- pt(tstat, df=df)
zstat <- qnorm(pval)

print(mean(abs(zstat) > -qnorm(.05/2)))
# [1] 0.03313927

print(mean(abs(zstat) > -qnorm(.01/2)))
# [1] 0.004758173
