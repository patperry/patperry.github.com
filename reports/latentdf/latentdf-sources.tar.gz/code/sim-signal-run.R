# code/sim-signal-run.R


source("code/steif.R")


nrep <- 10000
nfactor.max <- 5


run.sim <- function(nrow, ncol, signal, nfactor.max = 5,
                    vector = c("basis", "ones", "pbasis", "pones", "random"),
                    nrep = 100, seed = 0) {
    set.seed(seed, "Mersenne-Twister")

    n <- nrow
    m <- ncol
    d <- sqrt(signal)
    vector <- match.arg(vector)

    v1 <- rep(NA, nrep)
    rss0 <- rep(NA, nrep)
    vhat1 <- matrix(NA, nrep, nfactor.max)
    dhat <- matrix(NA, nrep, min(n, m))
    rss <- matrix(NA, nrep, nfactor.max)

    v <- matrix(NA, nrep, m)

    if (vector == "basis") {
        v[,] <- 0
        v[,1] <- 1
    } else if (vector == "ones") {
        v[,] <- 1/sqrt(m)
    } else if (vector == "pbasis") {
        v[,] <- 0
        v[,2] <- 1
    } else if (vector == "pones") {
        v[,] <- 1/sqrt(m-1)
        v[,1] <- 0
    } else if (vector == "random") {
        for (r in seq_len(nrep)) {
            v[r,] <- rsteif(m, 1)
        }
    }

    for (r in seq_len(nrep)) {
        u <- rsteif(n, length(d))
        eps <- matrix(rnorm(n * m), n, m)
        resid0 <- u %*% (sqrt(n) * d * matrix(v[r,], nrow=1)) + eps

        rss0[r] <- sum(resid0[,1]^2)
        v1[r] <- v[r,1]

        svd <- svd(resid0)
        vhat1[r,] <- svd$v[1, 1:nfactor.max]
        dhat[r,] <- svd$d / sqrt(n)

        for (k in 1:nfactor.max) {
            u.est <- svd$u[, 1:k, drop=FALSE]
            v.est <- svd$v[, 1:k, drop=FALSE]
            d.est <- svd$d[1:k]
            yhat1 <- u.est %*% (d.est * t(v.est))
            resid1 <- resid0[,1] - yhat1[,1]
            rss[r,k] <- sum(resid1^2)
        }

    }

    list(nrow = n, ncol = m, signal = signal, vector = vector,
         v1 = v1, rss0 = rss0, vhat1 = vhat1, dhat = dhat,
         rss=rss)
}




args <- commandArgs(trailingOnly = TRUE)

for (filename in args) {
    d <- dirname(filename)
    if (!file.exists(d)) {
        dir.create(d)
    }

    b <- basename(filename)
    pattern <- "^sim_n(\\d+)_m(\\d+)_s(\\d+)_v(\\S+)[.]rds$"
    n <- as.integer(gsub(pattern, "\\1", b, perl=TRUE))
    m <- as.integer(gsub(pattern, "\\2", b, perl=TRUE))
    s <- as.integer(gsub(pattern, "\\3", b, perl=TRUE)) / 10
    v <- gsub(pattern, "\\4", b, perl=TRUE)


    sim <- run.sim(nrow=n, ncol=m, signal=s, vector=v, nfactor.max=5, nrep=nrep)
    saveRDS(sim, file = filename)
}

