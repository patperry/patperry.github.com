# code/agemap-scree.R"

source("code/fit.R")
source("code/agemap.R")
source("code/palette.R")



agemap.scree <- function(d, filename, w = 3, h = w) {
    mar <- c(4,4,1,4) + .1
    mai <- mar * par("csi")

    pdf(filename,
        width=sum(w, mai[c(2,4)]),
        height=sum(h, mai[c(1,3)]))

    par(ps=10)
    par(mar=mar)
    par(las=1)

    plot(100 * d^2 / sum(d^2),
         xlab="Factor",
         ylab="Variance Explained (%)",
         col=2, pch=16, t="o",
         xlim=c(0.5, length(d) + 0.5),
         ylim=c(0, 1.10 * max(100 * d^2 / sum(d^2))),
         xaxs="i", yaxs="i")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)

    dev.off()
}



agemap.scree.subtab <- function(d, rows=seq_along(d), nrow=length(rows),
                                resid=TRUE) {
    tab <- cbind(seq_along(d),
                 100 * d^2 / sum(d^2),
                 100 - 100 * cumsum(d^2) / sum(d^2))
    tab <- cbind(tab[,1], format(tab[,-1], digits=1))
    tab <- tab[rows,]

    if (resid) {
        cat("\\begin{tabular}{lrr}\n")
    } else {
        cat("\\begin{tabular}{lr}\n")
    }

    cat("\\toprule\n")
    if (resid) {
        cat("& & \\multicolumn{1}{l}{Resid.}\\\\\n")
        cat("\\multicolumn{1}{l}{Factor} & \\multicolumn{1}{c}{Var.~\\%} & \\multicolumn{1}{l}{Var.~\\%}\\\\\n")
    } else {
        cat("\\multicolumn{1}{l}{Factor} & \\multicolumn{1}{c}{Var.~\\%}\\\\\n")
    }
    cat("\\midrule\n")
    for (i in seq_len(nrow(tab))) {
        cat(tab[i,1], "&", tab[i,2], "\\phantom{x}")
        if (resid)
            cat("&", tab[i,3], "\\phantom{}")
        cat("\\\\\n")
    }
    while (i < nrow) {
        i <- i + 1
        cat("\\\\\n")
    }
    cat("\\bottomrule\n")
    cat("\\end{tabular}\n")
}


agemap.scree.tab <- function(d, filename, ncol=2, resid=TRUE) {
    sink(filename)

    nrow <- ceiling(length(d) / ncol)
    cat("\\hfill\n")
    for (j in seq_len(ncol)) {
        b <- 1 + nrow * (j - 1)
        e <- min(length(d), nrow * j)

        agemap.scree.subtab(d, b:e, resid=resid)

        if (j < ncol) {
            cat("\\hfill\\hfill\n")
        }
    }
    cat("\\hfill\n")

    sink()
}



# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# fit the model
model <- fit.model(y, x, z, nfactor = 0)

# extract the residuals
resid <- model$resid
df.resid <- model$df.resid

# compute the SVD of the residuals
svd.resid <- svd(resid)
d <- svd.resid$d[seq_len(df.resid)]


agemap.scree(d, "figs/agemap-scree.pdf")
agemap.scree.tab(d, "tables/agemap-scree.tex", ncol=3, resid=TRUE)

