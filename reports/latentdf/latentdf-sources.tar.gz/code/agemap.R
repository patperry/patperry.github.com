# code/agemap.R

require("tools")


read.agemap.raw <- function() {
    data.b <- read.table("data/agemap/cerebellum.csv",
                         sep = ",",
                         header = TRUE,
                         row.names = 1)
    rownames(data.b) <- substr(rownames(data.b), 2, 5)

    data.c <- read.table("data/agemap/cerebrum.csv",
                         sep = ",",
                         header = TRUE,
                         row.names = 1)
    rownames(data.c) <- substr(rownames(data.c), 2, 5)

    rows <- intersect(rownames(data.b), rownames(data.c))
    rows.b <- match(rows, rownames(data.b))
    rows.c <- match(rows, rownames(data.c))

    cols0 <- match(c("sex", "age"), colnames(data.b))
    data.rows <- data.b[rows.b, cols0]
    data.rows$sex <- as.factor(ifelse(data.rows$sex == 1, "F", "M"))

    data.cols <- data.frame(tissue=as.factor(rep(c("B", "C"), each=ncol(data.b) - 2)))
    rownames(data.cols) <- paste(data.cols$tissue, colnames(data.b)[-cols0], sep=":")

    y <- as.matrix(cbind(data.b[rows.b, -cols0], data.c[rows.c, -cols0]))
    rownames(y) <- rownames(data.rows)
    colnames(y) <- rownames(data.cols)

    list(rows=data.rows, cols=data.cols, log.activation=y)
}


read.agemap <- function() {
    filename <- "data/cleaned/agemap.rds"
    checksum <- "3670640961230ce13d03e5d77dc08f98"

    if (file.exists(filename)
        && md5sum(filename) == checksum) {
        data <- readRDS(filename)
    } else {
        data <- read.agemap.raw()

        if (!file.exists(dirname(filename)))
            dir.create(dirname(filename))
        saveRDS(data, file = filename)

        stopifnot(md5sum(filename) == checksum)
    }

    data
}


