# code/agemap-scatter-grid.R

source("code/fit.R")
source("code/agemap.R")
source("code/agemap-cluster.R")
source("code/palette.R")
source("code/agemap-scatter.R")




# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# Get the mouse clusters
km <- agemap.cluster()
class <- km$cluster

# fit the model
model <- fit.model(y, x, z, nfactor = 2)

# extract the factor scores
u1 <- model$factor.scores[,1]
u2 <- model$factor.scores[,2]
v1 <- model$factor.loadings[,1]
v2 <- model$factor.loadings[,2]
sex <- data$rows$sex
age <- data$rows$age


dims <- c(4, 5)



vb <- svd(qr.resid(qr(x), y[,1:(ncol(y)/2)]))$v[,1]
vc <- svd(qr.resid(qr(x), y[,(ncol(y)/2) + 1:(ncol(y)/2)]))$v[,1]
j0 <- match("B:Mm.71015", colnames(y))
js1 <- unique(c(j0, rev(order(abs(vb)))[1:10]))[1:10]
js2 <- rev(order(abs(vc)))[1:10] + (ncol(y)/2)
js  <- c(js1, js2)


mai <- rep(.125, 4)
wtot <- 5
# wtot = dims[2] * (mai[2] + mai[4] + w)
w <- wtot / dims[2] - mai[2] - mai[4]
h <- w
htot <- dims[1] * (mai[1] + mai[3] + h)


pdf("figs/agemap-scatter-grid.pdf", wtot, htot)


if (FALSE) { # this only looks good if you have lots of room
    par(las=1)
    par(mfrow=dims)
    l <- par("csi") * par("lheight") * par("cex")
    par(mai=l * c(7.125, 5.125, 2.125, 4.125))

    for (j in js) {
        plot(x[,"age"], y[,j], axes=FALSE, xlab="", ylab="", main=colnames(y)[j])
        axis(1, at=par("usr")[1:2], labels=FALSE, lwd.ticks=0)
        axis(2, at=par("usr")[3:4], labels=FALSE, lwd.ticks=0)
        axis(1, at=c(1, 6, 16, 24), labels=(j == js[1]))
        axis(2, labels=TRUE)

        if (j == js[1]) {
            mtext("Age (mo.)", 1, las=0, cex=0.6, line=2, adj=1)
            mtext("Activation Level", 2, las=0, cex=0.6, line=2, adj=1)
        }
    }
} else {
    pch <- km$pch[km$cluster]
    col <- km$col[km$cluster]

    par(mfrow=dims)
    par(mai=rep(.125, 4))
    rawnames <- colnames(y)
    tiss <- substr(rawnames, 1, 1)
    gene <- substr(rawnames, 3, nchar(rawnames))
    names <- paste(gene, tiss, sep="")

    for (j in js) {
        plot(x[,"age"], y[,j], axes=FALSE, xlab="", ylab="", pch=pch, col=col,
             lwd=1.0)
        abline(h = median(y[,j]), lty=2)
        #text(x[,"age"], y[,j], class, col=brewer.pal(3, "Set3")[class])
        usr <- par("usr")
        cxy <- par("cxy")
        #text(usr[2] - 0.25 * cxy[1], usr[3] + 0.25 * cxy[2], names[j], adj=c(1,0))
        mtext(names[j], 3, las=0, line=0, adj=0.5, cex=par("cex"))
        box()
    }

}


dev.off()
