# code/sim-noise-clean.R


nrow <- c()
ncol <- c()
dfhat <- c()
dfhat.se <- c()
ks.stat <- c()
ks.pval <- c()


for (filename in list.files("data/sim-noise", full.names=TRUE)) {
    sim <- readRDS(file = filename)
    nrow <- c(nrow, sim$nrow)
    ncol <- c(ncol, sim$ncol)
    dfhat <- c(dfhat, sim$nrow - mean(sim$rss[,1]))
    dfhat.se <- c(dfhat.se, sd(sim$rss[,1]) / sqrt(length(sim$rss[,1])))

    df.resid <- sim$nrow - (1 + sqrt(sim$nrow / sim$ncol))^2
    ks <- ks.test(sim$rss[,1], "pchisq", df=df.resid)
    ks.stat <- c(ks.stat, ks$statistic)
    ks.pval <- c(ks.pval, ks$p.value)
}


data <- data.frame(nrow, ncol, dfhat, dfhat.se, df = (1 + sqrt(nrow/ncol))^2,
                   ks.stat, ks.pval)



if (!file.exists("data/cleaned"))
    dir.create("data/cleaned")

saveRDS(data, file = "data/cleaned/sim-noise.rds")

