# code/agemap-1gene.R"

source("code/agemap.R")
source("code/palette.R")
source("code/agemap-scatter.R")


genename <- "B:Mm.71015"  # Cerebellum Mm.71015

# read in the data
data <- read.agemap()

# extract predictors and response
age <- data$rows$age
sex <- data$rows$sex
z <- model.matrix(~ tissue, data$cols, contrasts = list(tissue = "contr.sum"))
ymat <- data$log.activation

# set up the basis element for the gene
e <- rep(0, ncol(ymat))
names(e) <- colnames(ymat)
e[genename] <- 1

# find the direction for the contrast
s <- qr.resid(qr(z), e)

# find the component of the response along the contrast
y <- as.vector(ymat %*% s)



model <- lm(y ~ age + sex, contrasts = list(sex = "contr.sum"))

agemap.scatter(sex, age, y, "figs/agemap-1gene.pdf",
    ylab="Activation Level",
    annotate = function() {
        abline(coef(model)["(Intercept)"], coef(model)["age"],
               col=1, lwd=1.5)

        #abline(sum(coef(model)[c("(Intercept)", "sexM")]), coef(model)["age"],
        #       col=1, lwd=1.5)
    }
    )

print(summary(model))

