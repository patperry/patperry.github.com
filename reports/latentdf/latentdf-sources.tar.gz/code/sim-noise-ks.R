# code/sim-noise-ks.R

source("code/palette.R")



data <- readRDS("data/cleaned/sim-noise.rds")



with(subset(data, nrow * ncol >= 3000), {
    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 1.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    pdf("figs/sim-noise-ks.pdf",
        width = sum(w, mai[c(2,4)]),
        height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    x <- (seq_along(ks.pval) - 0.5) / length(ks.pval)
    y <- sort(ks.pval)
    plot(x, y, col=2,
         xlab="Relative Rank",
         ylab="Kolmogorov-Smirnov P-Value")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)

    dev.off()

    })


print.table <- function() {
    nrow <- sort(unique(data$nrow))
    ncol <- sort(unique(data$ncol))

    tab <- matrix("", length(nrow) + 1, length(ncol) + 1)
    for (i in seq_along(nrow)) {
        for (j in seq_along(ncol)) {
            ks.pval <- data[data$nrow == nrow[i] & data$ncol == ncol[j], "ks.pval"]
            tab[i+1,j+1] <- formatC(ks.pval, digits=2, format="f")
        }
    }
    tab[1,-1] <- ncol
    tab[-1,1] <- nrow
    tab[1,1] <- "Rows ($n$)"

    cat("\\begin{tabular}{", rep("c", ncol(tab)), "}\n", sep="")
    cat("\\toprule\n")
    cat("& \\multicolumn{", ncol(tab)-1, "}{c}{Columns ($m$)} \\\\\n", sep="")
    cat("\\cmidrule(l){2-", ncol(tab), "}\n", sep="")
    for (i in seq_len(nrow(tab))) {
        cat(do.call("paste", as.list(c(tab[i,], sep=" & "))), " \\\\\n")
        if (i == 1)
            cat("\\midrule\n")
    }
    cat("\\bottomrule\n")
    cat("\\end{tabular}\n")
    invisible()
}

sink("tables/noise-ks-pval.tex")
print.table()
sink()
