# code/sim-noise-qq.R

source("code/palette.R")

for (v in c("basis", "ones", "pbasis", "pones")) {
    for (s in c(1, 1.5, 3, 21)) {
        ## Edit the values of n and m, then re-run this script to generate
        # figs/sim-signal_n*_m*_s*_v*-qq.pdf
        n <- 50
        m <- 10000

        infile <- sprintf("data/sim-signal/sim_n%03d_m%05d_s%03d_v%s.rds",
                          n, m, 10 * s, v)
        outfile <- sprintf("figs/sim-signal_n%03d_m%05d_s%03d_v%s-qq.pdf",
                           n, m, 10 * s, v)

        par(mfrow=c(1,1))
        mar <- c(4.1, 4.1, 1.1, 4.1)
        mai <- mar * par("csi")
        w <- 3
        h <- 3

        pdf(outfile, width = sum(w, mai[c(2,4)]), height = sum(h, mai[c(1,3)]))
        
        par(ps=10)
        par(las=1)
        par(mar=mar)
        
        sim <- readRDS(file = infile)

        n <- sim$nrow
        m <- sim$ncol
        mu <- sim$signal[1]
        v1 <- sim$v1

        if (mu > sqrt(m/n)) {
            df <- (n * (1 - (m/n) / mu - (m/n) / mu^2) * v1^2
                   + (1 + 1/mu)^2 * (1 - v1^2))
        } else {
            df <- (1 + sqrt(n/m))^2 - n * mu * v1^2
        }

        df.resid <- n - df

        nrep <- nrow(sim$rss)
        f <- (1:nrep - 0.5) / nrep
        x <- qchisq(f, df = df.resid)
        y <- sort(sim$rss[,1])
        lim <- range(c(x, y))

        plot(x, y, xlim=lim, ylim=lim, t="n",
             xlab="Chi-Squared Quantile",
             ylab="Residual Sum of Squares ")
        abline(0, 1, col="gray", lwd=1)
        points(x, y, cex=0.4, col=2)
        axis(3, labels=FALSE)
        axis(4, labels=FALSE)

        dev.off()
    }
}
