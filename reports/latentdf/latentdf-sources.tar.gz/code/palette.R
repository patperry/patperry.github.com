# code/palette.R

require("RColorBrewer")
palette(brewer.pal(6, "Set1"))

