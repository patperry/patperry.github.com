# code/sim-signal-clean.R


nrow <- c()
ncol <- c()
signal <- c()
vector <- c()
dfhat <- c()
dfhat.se <- c()
noise.est0 <- c()
noise.est0.sd <- c()

df <- c()
df.se <- c()
dferr <- c()
dferr.se <- c()

ks.stat <- c()
ks.pval <- c()


for (filename in list.files("data/sim-signal", full.names=TRUE)) {
    sim <- readRDS(file = filename)

    # simulation parameters
    nrow <- c(nrow, sim$nrow)
    ncol <- c(ncol, sim$ncol)
    signal <- c(signal, sim$signal[1])
    vector <- c(vector, sim$vector)

    # true degrees of freedom
    dfhat <- c(dfhat, sim$nrow - mean(sim$rss[,1]))
    dfhat.se <- c(dfhat.se, sd(sim$rss[,1]) / sqrt(length(sim$rss[,1])))

    # naive global noise est
    sigma0 <- sqrt(apply(sim$dhat[,-1]^2, 1, sum) / sim$ncol)
    noise.est0 <- c(noise.est0, mean(sigma0))
    noise.est0.sd <- c(noise.est0.sd, sd(sigma0))


    n <- sim$nrow
    m <- sim$ncol
    mu <- sim$signal[1]
    v1 <- sim$v1
    rss <- sim$rss[,1]

    true <- (n - rss)
    if (mu > sqrt(m/n)) {
        est <- (n * (1 - (m/n) / mu - (m/n) / mu^2) * v1^2
                + (1 + 1/mu)^2 * (1 - v1^2))
    } else {
        est <- (1 + sqrt(n/m))^2 - n * mu * v1^2
    }

    df <- c(df, mean(est))
    df.se <- c(df.se, sd(est) / sqrt(length(est)))

    err <- true - est
    dferr <- c(dferr, mean(err))
    dferr.se <- c(dferr.se, sd(err) / sqrt(length(err)))

    stopifnot(all(est == mean(est)))
    df.resid <- n - mean(est)
    ks <- ks.test(sim$rss[,1], "pchisq", df=df.resid)

    ks.stat <- c(ks.stat, ks$statistic)
    ks.pval <- c(ks.pval, ks$p.value)
}


vector <- as.factor(vector)
data <- data.frame(nrow, ncol, signal, vector, dfhat, dfhat.se, df, df.se,
                   dferr, dferr.se, ks.stat, ks.pval)


if (!file.exists("data/cleaned"))
    dir.create("data/cleaned")

saveRDS(data, file = "data/cleaned/sim-signal.rds")

