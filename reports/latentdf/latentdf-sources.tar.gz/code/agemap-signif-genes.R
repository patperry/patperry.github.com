# code/agemap-signif-genes.R

library("dplyr")

source("code/fit.R")
source("code/agemap.R")



# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# problem dimensions
m <- ncol(y)
n <- nrow(y)
p <- ncol(x)
q <- ncol(z)


# fit the model
K <- 2
model <- fit.model(y, x, z, nfactor = K)

# extract the t statistics for age
t0 <- model$tstat0[, "age"]
t1 <- model$tstat[, "age"]
df0 <- model$df.resid0
df1 <- model$df.resid


z0 <- qnorm(pt(t0, df=df0))
z1 <- qnorm(pt(t1, df=df1))

alpha <- 0.001
cutoff <- qnorm(alpha/2, lower.tail=FALSE)
signif0 <- abs(z0) > max(cutoff)
signif1 <- abs(z1) > max(cutoff)

gene.full <- colnames(y)
tissue <- factor(substr(gene.full, 1, 1))
levels(tissue) <- c("Cerebellum", "Cerebrum")

gene <- substr(gene.full, 3, nchar(gene.full))
gene.levels <- paste0("Mm.", unique(sort(as.integer(substr(gene.full, 6, nchar(gene.full))))))

gene <- factor(gene, levels = gene.levels)


gdata <- data.frame(tissue, gene, pval0 = 2 * pnorm(-abs(z0)), pval1 = 2 * pnorm(-abs(z1)))
rownames(gdata) <- NULL


gdata.signif <- (gdata
                 %>% filter(pval1 < .001)
                 %>% arrange(pval1)
                 %>% select(tissue, gene, pval0, pval1))

colnames(gdata.signif) <- c("Tissue", "Gene", "Original P Value", "Adjusted P Value")

write.csv(gdata.signif, file="Significant Genes.csv", row.names=FALSE)

cat("Original (no adjustment):\n")
print(gdata %>% filter(pval0 < .001) %>% group_by(tissue) %>%
      summarize(count=n()))

cat("Adjusting for two factors:\n")
print(gdata %>% filter(pval1 < .001) %>% group_by(tissue) %>%
      summarize(count=n()))
