# code/agemap-1gene-3lines.R


source("code/fit.R")
source("code/agemap.R")
source("code/agemap-cluster.R")
source("code/palette.R")
source("code/agemap-scatter.R")


genename <- "B:Mm.71015"  # Cerebellum Mm.71015

# read in the data
data <- read.agemap()

age <- data$rows$age
sex <- data$rows$sex
y <- data$log.activation[,genename]

# get the clusters
km <- agemap.cluster()
cluster <- km$cluster


# get the factor scores
x.full <- model.matrix(~ age + sex, data$rows)
z.full <- model.matrix(~ tissue, data$cols)
y.full <- data$log.activation
model.full <- fit.model(y.full, x.full, z.full, nfactor = 2)
u1 <- model.full$factor.scores[,1]
u2 <- model.full$factor.scores[,2]



model <- lm(y ~ age + u1 + u2)
yhat <- predict(model)



#beta0 <- predict(model, newdata = data.frame(age = 0, cluster=1:3))
#beta1 <- coef(model)["age"]

agemap.scatter(sex, age, y, "figs/agemap-1gene-3lines.pdf",
    ylab="Activation Level",
    annotate = function() {
        for (i in 1:3) {
            xi <- age[cluster == i]
            yhati <- yhat[cluster == i]
            oi <- order(xi)
            abline(lm(yhati ~ xi), col=km$col[i], pch=km$pch[i], lwd=1.5)
            #points(xi[oi], yhati[oi], col=km$col[i], pch=km$pch[i])
        }
        #abline(coef(model)["(Intercept)"], coef(model)["age"], col=1, lwd=1.5)
    }
    )

print(summary(model))

