# code/agemap-normality.R

source("code/fit.R")
source("code/agemap.R")

library("e1071")
library("nortest")

# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# problem dimensions
m <- ncol(y)
n <- nrow(y)
p <- ncol(x)
q <- ncol(z)


# fit the model
K <- 2
model <- fit.model(y, x, z, nfactor = K)

pval <- apply(model$resid, 2, function(x) ad.test(x)$p.value)
kurt <- apply(model$resid, 2, kurtosis)

sum(pval < .05)
# [1] 3372

mean(pval < .05)
# [1] 0.1887595

sum(kurt[pval < .05] > 0)
# [1] 3034

median(kurt[pval < .05])
# [1] 2.451013

