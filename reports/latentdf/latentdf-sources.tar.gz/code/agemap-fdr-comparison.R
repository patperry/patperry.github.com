# code/agemap-fdr-comparison.R

source("code/fit.R")
source("code/agemap.R")
source("code/palette.R")


# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation


# problem dimensions
m <- ncol(y)
n <- nrow(y)
p <- ncol(x)
q <- ncol(z)


# fit the model
K <- 2
model <- fit.model(y, x, z, nfactor = K)

find.signif <- function(model,
                        type = c("rmt", "gollob", "mandel", "naive"),
                        level = 0.001)
{
    type <- match.arg(type)
    tstat <- model$tstat[, "age"]

    n <- nrow(model$x)
    p <- ncol(model$x)
    m <- nrow(model$z)
    q <- ncol(model$z)
    K <- model$nfactor

    if (type == "rmt") {
        df <- model$df.resid
    } else if (type == "gollob") {
        k <- seq_len(model$nfactor)
        df.gollob <- ((n - p - k + 1) + (m - q - k + 1) - 1) / (m-q)
        df <- rep(n - p - sum(df.gollob), m)
    } else if (type == "mandel") {
        df.mandel <- rep((sqrt(m-q) + sqrt(n-p))^2 / (m-q), K)
        df <- rep(n - p - sum(df.mandel), m)
    } else if (type == "naive") {
        df <- rep(n - p - K, m)
    } else {
        stop("unrecognized 'type'")
    }

    zstat <- qnorm(pt(tstat, df))
    signif <- abs(zstat) > qnorm(level/2, lower.tail=FALSE)
    signif
}

#
gen.rep <- function(model)
{
    n <- nrow(model$x)
    m <- nrow(model$z)
    mu <- with(model,
               x %*% t(coef.x) + coef.z %*% t(z)
               + factor.scores %*% t(factor.loadings))
    eps <- t(matrix(rnorm(m*n), m, n) * model$sigma)
    y <- mu + eps
    y
}

posneg <- function(signif.est, signif.true)
{
    est <- signif.est
    true <- signif.true
    tp <- sum(est & true)
    fp <- sum(est & !true)
    tn <- sum(!est & !true)
    fn <- sum(!est & true)
    fdr <- fp / max(1, fp + tp)
    level <- fp / max(1, fp + tn)
    power <- tp / max(1, fn + tp)
    c(true.pos = tp, false.pos = fp,
      true.neg = tn, false.neg = fn,
      fdr = fdr, level = level, power = power)
}


level <- 0.001
signif <- find.signif(model, type="rmt", level=level)
coef.x.boot <- model$coef.x
coef.x.boot[!signif,"age"] <- 0

model.boot <- list(x = x, z = z,
                   coef.x = coef.x.boot, coef.z = model$coef.z,
                   factor.scores = model$factor.scores,
                   factor.loadings = model$factor.loadings,
                   sigma = model$sigma)


nrep <- 1000
set.seed(0)
y.rep <- replicate(nrep, gen.rep(model.boot), simplify=FALSE)
model.rep <- lapply(y.rep, function(yr) fit.model(yr, x, z, nfactor = K))


posneg.rep <- list()
for (method in c("rmt", "gollob", "mandel", "naive")) {
    signif.rep <- lapply(model.rep, function(mr)
                         find.signif(mr, type=method, level=level))
    posneg.rep[[method]] <- t(sapply(signif.rep,
                                     function(sr) posneg(sr, signif)))
}

model0.rep <- lapply(y.rep, function(yr) fit.model(yr, x, z, nfactor = 0))
signif0.rep <- lapply(model0.rep, function(mr)
                         find.signif(mr, type="naive", level=level))
posneg.rep[["none"]] <-  t(sapply(signif0.rep,
                                     function(sr) posneg(sr, signif)))

 

print(lapply(posneg.rep, colMeans))


## level = .001:

# $rmt
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 3.817700e+02 1.698100e+01 1.733302e+04 1.322300e+02 4.249434e-02 9.787320e-04 7.427432e-01 
# 
# $gollob
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 3.820270e+02 1.707800e+01 1.733292e+04 1.319730e+02 4.269989e-02 9.843228e-04 7.432432e-01 
# 
# $mandel
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 3.817920e+02 1.698300e+01 1.733302e+04 1.322080e+02 4.249673e-02 9.788473e-04 7.427860e-01 
# 
# $naive
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 3.820280e+02 1.707900e+01 1.733292e+04 1.319720e+02 4.270216e-02 9.843804e-04 7.432451e-01 
# 
# $none
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 2.853500e+01 5.636000e+00 1.734436e+04 4.854650e+02 1.625152e-01 3.248415e-04 5.551556e-02 




## standard errors:
print(lapply(posneg.rep, function(x) apply(x, 2, sd) / sqrt(nrow(x))))

# $rmt
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 2.944585e-01 1.358422e-01 1.358422e-01 2.944585e-01 3.258737e-04 7.829519e-06 5.728765e-04 
# 
# $gollob
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 2.942564e-01 1.361192e-01 1.361192e-01 2.942564e-01 3.263234e-04 7.845489e-06 5.724834e-04 
# 
# $mandel
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 2.944817e-01 1.358203e-01 1.358203e-01 2.944817e-01 3.257928e-04 7.828260e-06 5.729215e-04 
# 
# $naive
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 2.943159e-01 1.361223e-01 1.361223e-01 2.943159e-01 3.263290e-04 7.845667e-06 5.725990e-04 
# 
# $none
#     true.pos    false.pos     true.neg    false.neg          fdr        level        power 
# 1.247732e-01 7.844525e-02 7.844525e-02 1.247732e-01 1.990404e-03 4.521340e-06 2.427494e-04 
# 

