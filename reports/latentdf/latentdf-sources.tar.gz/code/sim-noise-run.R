# code/sim-noise-run.R


nrep <- 10000
nfactor.max <- 5



run.sim <- function(nrow, ncol, nfactor.max = 5, nrep = 100, seed=0) {
    set.seed(seed, "Mersenne-Twister")

    n <- nrow
    m <- ncol
    rss0 <- rep(NA, nrep)
    rss <- matrix(NA, nrep, nfactor.max)
    vhat <- matrix(NA, nrep, nfactor.max)

    for (r in seq_len(nrep)) {
        resid0 <- matrix(rnorm(n * m), n, m)

        svd <- svd(resid0)

        rss0[r] <- sum(resid0[,1]^2)
        vhat[r,] <- svd$v[1,seq_len(ncol(vhat))]

        for (k in 1:nfactor.max) {
            u <- svd$u[, 1:k, drop=FALSE]
            v <- svd$v[, 1:k, drop=FALSE]
            d <- svd$d[1:k]
            yhat1 <- u %*% (d * t(v))
            resid1 <- resid0[,1] - yhat1[,1]
            rss[r,k] <- sum(resid1^2)
        }
    }

    list(nrow = n, ncol = m, rss0=rss0, rss=rss, vhat=vhat)
}



args <- commandArgs(trailingOnly = TRUE)

for (filename in args) {
    d <- dirname(filename)
    if (!file.exists(d)) {
        dir.create(d)
    }

    b <- basename(filename)
    pattern <- "^sim_n(\\d+)_m(\\d+)[.]rds$"
    n <- as.integer(gsub(pattern, "\\1", b, perl=TRUE))
    m <- as.integer(gsub(pattern, "\\2", b, perl=TRUE))


    sim <- run.sim(nrow=n, ncol=m, nfactor.max=5, nrep=nrep)
    saveRDS(sim, file = filename)
}

