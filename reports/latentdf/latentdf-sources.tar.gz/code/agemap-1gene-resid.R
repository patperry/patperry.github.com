# code/agemap-1gene-resid.R

source("code/agemap.R")
source("code/palette.R")
source("code/agemap-scatter.R")


genename <- "B:Mm.71015"  # Cerebellum Mm.71015

# read in the data
data <- read.agemap()

# extract predictors and response
age <- data$rows$age
sex <- data$rows$sex
z <- model.matrix(~ tissue, data$cols, contrasts = list(tissue = "contr.sum"))
ymat <- data$log.activation

# set up the basis element for the gene
e <- rep(0, ncol(ymat))
names(e) <- colnames(ymat)
e[genename] <- 1

# find the direction for the contrast
s <- qr.resid(qr(z), e)

# find the component of the response along the contrast
y <- as.vector(ymat %*% s)


model <- lm(y ~ age + sex, contrasts = list(sex = "contr.sum"))
r <- residuals(model)

o <- order(r)
n <- length(r)
i <- seq_along(r)

agemap.scatter2(sex[o], age[o], (i - 0.5) / n, r[o], "figs/agemap-1gene-resid.pdf",
                xlab="Relative Rank",
                ylab="Residual")
