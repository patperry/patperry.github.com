# code/agemap-tstat.R

source("code/fit.R")
source("code/agemap.R")
source("code/palette.R")



agemap.tstat <- function(t0, t1, df0, df1, filename, w = 3, h = w, legend=FALSE) {
    mar <- c(4,4,4,4) + .1
    mai <- mar * par("csi")

    pdf(filename,
        width=sum(w, mai[c(2,4)]),
        height=sum(h, mai[c(1,3)]))

    par(ps=10)
    par(mar=mar)
    par(las=1)

    z0 <- qnorm(pt(t0, df=df0))
    z1 <- qnorm(pt(t1, df=df1))

    alpha <- c(1, .05, .001)
    c0 <- qnorm(alpha/2, lower.tail=FALSE)
    c1 <- qnorm(alpha/2, lower.tail=FALSE)

    zmax0 <- max(abs(z0))
    zmax1 <- max(abs(z1))
    zmax <- max(zmax0, zmax1)
    plot(z0, z1, xlim=c(-zmax,zmax), ylim=c(-zmax, zmax), t="n",
         xlab="Test Statistic from Ordinary Model",
         ylab="Test Statistic from Latent Factor Model")

    axis(3, at=c(-c0, c0), labels=100*c(alpha, alpha))
    mtext("Significance Level (%)", 3, line=3)
    axis(4, at=c(-c1, c1), labels=100*c(alpha, alpha))
    mtext("Significance Level (%)", 4, line=3, las=0)
    abline(v=range(c(-c0, c0)), col="gray")
    abline(h=range(c(-c1, c1)), col="gray")

    signif0 <- abs(z0) > max(c0)
    signif1 <- abs(z1) > max(c1)
    change <- signif0 != signif1
    points(z0[!change], z1[!change], pch=1, col=2, cex=0.5)
    points(z0[change], z1[change], pch=2, col=1, cex=0.5)

    if (legend) {
        usr <- par("usr")
        l <- par("cxy")[2]
        legend(usr[2] + 2 * l, usr[3], xjust=0, yjust=0, xpd=TRUE, bty="n",
               title="Significant", title.adj=0,
               legend=c("Agree", "Differ"),
               pch=c(1,2),
               col=c(2,1))
    }
    dev.off()


    x <- matrix(NA, 3, 3)
    rownames(x) <- c("signif0.FALSE", "signif0.TRUE", "")
    colnames(x) <- c("signif1.FALSE", "signif1.TRUE", "")
    x[1,1] <- sum(!signif0 & !signif1)
    x[1,2] <- sum(!signif0 &  signif1)
    x[1,3] <- sum(!signif0)

    x[2,1] <- sum( signif0 & !signif1)
    x[2,2] <- sum( signif0 &  signif1)
    x[2,3] <- sum( signif0)

    x[3,1] <- sum(!signif1)
    x[3,2] <- sum( signif1)
    x[3,3] <- length(signif1)

    print(x)
}



# read in the data
data <- read.agemap()

# extract predictors and response
x <- model.matrix(~ age + sex, data$rows)
z <- model.matrix(~ tissue, data$cols)
y <- data$log.activation

# problem dimensions
m <- ncol(y)
n <- nrow(y)
p <- ncol(x)
q <- ncol(z)


# fit the model
K <- 2
model <- fit.model(y, x, z, nfactor = K)

# extract the t statistics for age
t0 <- model$tstat0[, "age"]
t1 <- model$tstat[, "age"]
df0 <- model$df.resid0
df1 <- model$df.resid


k <- seq_len(K)

golub <- sum(((n - p - k + 1) + (m - q - k + 1) - 1) / (m-q))
mandel <- K * (sqrt(m-q) + sqrt(n-p))^2 / (m-q)

df1.none <- n - p
df1.naive <- n - p - K
df1.golub <- n - p - golub
df1.mandel <- n - p - mandel

t1.none <- t1 * sqrt(df1.none / df1)
t1.naive <- t1 * sqrt(df1.naive / df1)
t1.golub <- t1 * sqrt(df1.golub / df1)
t1.mandel <- t1 * sqrt(df1.mandel / df1)

z1 <- qnorm(pt(t1, df1))
z1.none <- qnorm(pt(t1.none, df1.none))
z1.naive <- qnorm(pt(t1.naive, df1.naive))
z1.golub <- qnorm(pt(t1.golub, df1.golub))
z1.mandel <- qnorm(pt(t1.mandel, df1.mandel))


# generate the figure
agemap.tstat(t0, t1, df0, df1, "figs/agemap-tstat.pdf")

