# code/agemap-1gene.R"

source("code/agemap.R")
source("code/palette.R")
source("code/agemap-scatter.R")



gene.a <- "C:Mm.355327" # significant coef for age
gene.as <-  "B:Mm.218717" # significant after adjusting for sex
gene.latent <- "B:Mm.71015"  # Cerebellum Mm.71015; significant after adjusting for latent

# read in the data
data <- read.agemap()

# extract predictors and response
age <- data$rows$age
sex <- data$rows$sex
z <- model.matrix(~ tissue, data$cols, contrasts = list(tissue = "contr.sum"))
ymat <- data$log.activation

# adjust for gene type
ymat.adj <- t(qr.resid(qr(z), t(ymat)))

# compute coefficients without adjusting for gender
x.a <- model.matrix(~ age, data$rows)
beta.a <- qr.coef(qr(x.a), ymat.adj)
resid.a <- qr.resid(qr(x.a), ymat.adj)
sigma.a <- sqrt(colSums(resid.a^2) / (nrow(x.a) - ncol(x.a)))
se.a <- sqrt(diag(solve(t(x.a) %*% x.a)))
tstat.a <- scale(beta.a / se.a, center=FALSE, scale=sigma.a)

x.as <- model.matrix(~ age + sex, data$rows)
beta.as <- qr.coef(qr(x.as), ymat.adj)
resid.as <- qr.resid(qr(x.as), ymat.adj)
sigma.as <- sqrt(colSums(resid.as^2) / (nrow(x.as) - ncol(x.as)))
se.as <- sqrt(diag(solve(t(x.as) %*% x.as)))
tstat.as <- scale(beta.as / se.as, center=FALSE, scale=sigma.as)

# set up the basis element for the gene
genename <- gene.a 
e <- rep(0, ncol(ymat))
names(e) <- colnames(ymat)
e[genename] <- 1

# find the direction for the contrast
s <- qr.resid(qr(z), e)

# find the component of the response along the contrast
y <- as.vector(ymat %*% s)


model <- lm(y ~ age)

agemap.scatter(sex, age, y, "figs/agemap-motivation-age.pdf",
    ylab="Activation Level",
    annotate = function() {
        abline(coef(model)["(Intercept)"], coef(model)["age"],
               col=1, lwd=1.5)

        #abline(sum(coef(model)[c("(Intercept)", "sexM")]), coef(model)["age"],
        #       col=1, lwd=1.5)
    }
    )

print(summary(model))





# set up the basis element for the gene
genename <- gene.as 
e <- rep(0, ncol(ymat))
names(e) <- colnames(ymat)
e[genename] <- 1

# find the direction for the contrast
s <- qr.resid(qr(z), e)

# find the component of the response along the contrast
y <- as.vector(ymat %*% s)


model0 <- lm(y ~ age)
model <- lm(y ~ age + sex)

agemap.scatter(sex, age, y, "figs/agemap-motivation-age-sex.pdf",
    ylab="Activation Level",
    annotate = function() {
        abline(coef(model)["(Intercept)"], coef(model)["age"],
               col=1, lwd=1.5, lty=2)

        abline(sum(coef(model)[c("(Intercept)", "sexM")]), coef(model)["age"],
               col=1, lwd=1.5, lty=1)
    }
    )

print(summary(model0))
print(summary(model))

