# code/sim-signal-ks.R



data <- readRDS("data/cleaned/sim-signal.rds")


print.table <- function(data) {
    nrow <- sort(unique(data$nrow))
    ncol <- sort(unique(data$ncol))

    tab <- matrix("", length(nrow) + 1, length(ncol) + 1)
    for (i in seq_along(nrow)) {
        for (j in seq_along(ncol)) {
            ks.pval <- data[data$nrow == nrow[i] & data$ncol == ncol[j], "ks.pval"]
            tab[i+1,j+1] <- formatC(ks.pval, digits=2, format="f")
        }
    }
    tab[1,-1] <- ncol
    tab[-1,1] <- nrow
    tab[1,1] <- "Rows ($m$)"

    cat("\\begin{tabular}{", rep("c", ncol(tab)), "}\n", sep="")
    cat("\\toprule\n")
    cat("& \\multicolumn{", ncol(tab)-1, "}{c}{Columns ($n$)} \\\\\n", sep="")
    cat("\\cmidrule(l){2-", ncol(tab), "}\n", sep="")
    for (i in seq_len(nrow(tab))) {
        cat(do.call("paste", as.list(c(tab[i,], sep=" & "))), " \\\\\n")
        if (i == 1)
            cat("\\midrule\n")
    }
    cat("\\bottomrule\n")
    cat("\\end{tabular}\n")
    invisible()
}

for (v in unique(data$vector)) {
    for (s in unique(data$signal)) {
        filename <- paste0("tables/signal",
                           "-s", sprintf("%03d", 10 * s),
                           "-v", v,
                           "-ks-pval.tex")
        sink(filename)
        print.table(subset(data, signal == s & vector == v))
        sink()
    }
}
