# code/sim-noise-zstat.R

source("code/palette.R")


data <- readRDS("data/cleaned/sim-noise.rds")


with(subset(data, nrow * ncol >= 3000), {
    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 1.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    pdf("figs/sim-noise-zstat.pdf",
        width = sum(w, mai[c(2,4)]),
        height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    zstat <- (dfhat - df) / dfhat.se

    x <- (seq_along(zstat) - 0.5) / length(zstat)
    y <- sort(zstat)
    plot(x, y, col=2,
         xlab="Relative Rank",
         ylab="Z Statistic for Null Simulation")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)

    dev.off()

    })



