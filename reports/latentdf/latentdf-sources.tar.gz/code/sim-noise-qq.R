# code/sim-noise-qq.R

source("code/palette.R")


(function() {
    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 1.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    ## Edit the values of n and m, then re-run this script to generate
    # figs/sim-noise_n*_m*-qq.pdf
    n <- 50
    m <- 10000

    infile <- sprintf("data/sim-noise/sim_n%03d_m%05d.rds", n, m)
    outfile <- sprintf("figs/sim-noise_n%03d_m%05d-qq.pdf", n, m)

    pdf(outfile,
        width = sum(w, mai[c(2,4)]),
        height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    sim <- readRDS(file = infile)

    nrep <- nrow(sim$rss)
    f <- (1:nrep - 0.5) / nrep
    df <- (1 + sqrt(n/m))^2
    df.resid <- n - df
    x <- qchisq(f, df = df.resid)
    y <- sort(sim$rss[,1])
    lim <- range(c(x, y))

    plot(x, y, xlim=lim, ylim=lim, t="n",
         xlab="Chi-Squared Quantile",
         ylab="Residual Sum of Squares ")
    abline(0, 1, col="gray", lwd=1)
    points(x, y, cex=0.4, col=2)
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)

    dev.off()
})()





