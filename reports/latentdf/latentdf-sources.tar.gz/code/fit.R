# code/fit.R


fit.model <- function(y, x = NULL, z = NULL, nfactor = 0) {
    if (is.null(x)) {
        x <- matrix(NA, nrow(y), 0)
    }
    if (is.null(z)) {
        z <- matrix(NA, ncol(y), 0)
    }

    stopifnot(nrow(y) == nrow(x))
    stopifnot(ncol(y) == nrow(z))
    stopifnot(nfactor >= 0L)

    # determine problem dimensions
    n <- nrow(y)
    m <- ncol(y)
    p <- ncol(x)
    q <- ncol(z)
    r <- nfactor



    # fit regression coefficients and determine residuals
    qr.x <- qr(x)
    qr.z <- qr(z)

    gamma <- t(qr.coef(qr.z, t(qr.coef(qr.x, y))))
    alpha <- t(qr.coef(qr.z, t(qr.resid(qr.x, y))))
    beta  <- t(qr.coef(qr.x, t(qr.resid(qr.z, t(y)))))

    resid0 <- t(qr.resid(qr.z, t(qr.resid(qr.x, y))))


    # fit the factors from the residuals
    if (r == 0L) {
        u <- matrix(NA, n, 0L)
        v <- matrix(NA, m, 0L)
        resid <- resid0
        df.factor <- matrix(NA, m, 0L)
    } else {
        svd <- svd(resid0)
        ix <- seq_len(r)
        u <- sqrt(n) * svd$u[,ix, drop=FALSE]
        v <- svd$v[,ix, drop=FALSE] %*% diag(svd$d[ix] / sqrt(n), r, r)
        resid <- resid0 - u %*% t(v)


        Qz <- qr.Q(qr.z)
        s2 <- 1 - rowSums(Qz^2)

        df.factor <- ((n - p) * (svd$v[,ix,drop=FALSE])^2 / s2
                      + (1 + sqrt((n - p)/(m - q)))^2)
    }

    # assign degrees of freedom
    df <- p                                     # regression
    df.resid <- n - df - rowSums(df.factor)     # residuals


    # estimate the response-specific noise standard deviations
    rss <- apply(resid^2, 2, sum)
    sigma <- sqrt(rss / df.resid)


    # compute the coefficient standard errors and t statistics
    if (p > 0L) {
        se <- cbind(sigma) %*% rbind(sqrt(diag(solve(t(x) %*% x))))
        tstat <- beta / se
    } else {
        tstat <- se <- beta
    }


    model <- list(y = y, x = x, z = z,
                  coef.x = beta, coef.z = alpha, coef.xz = gamma,
                  nfactor = r, factor.scores = u, factor.loadings = v,
                  sigma = sigma, resid = resid,
                  df = df, df.factor = df.factor, df.resid = df.resid,
                  tstat = tstat, se = se)
    # also compute the null (r = 0) quantities
    if (r == 0L) {
        model0 <- model
    } else {
        model0 <- fit.model(y, x, z, nfactor = 0)
    }

    model$sigma0 <- model0$sigma
    model$resid0 <- model0$resid
    model$df.resid0 <- model0$df.resid
    model$tstat0 <- model0$tstat
    model$se0 <- model0$se

    model
}


