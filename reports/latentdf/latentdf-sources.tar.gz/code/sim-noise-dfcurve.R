# code/sim-noise-dfcurve.R

source("code/palette.R")


data <- readRDS("data/cleaned/sim-noise.rds")


with(subset(data, nrow * ncol >= 1000), {
    par(mfrow=c(1,1))
    mar <- c(4.1, 4.1, 2.1, 4.1)
    mai <- mar * par("csi")
    w <- 3
    h <- 3

    pdf("figs/sim-noise-dfcurve.pdf",
        width = sum(w, mai[c(2,4)]),
        height = sum(h, mai[c(1,3)]))

    par(ps=10)
    par(las=1)
    par(mar=mar)

    x <- log10(nrow / ncol)
    y <- dfhat
    r <- dfhat.se

    plot(range(x), range(y - r, y + r), t="n",
         xlab=expression(Log[10](Rows/Columns)),
         ylab="Degrees of Freedom")
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)
    title(main="Noise", line = 1.25, outer = FALSE)

    fin <- par("fin")
    plt <- par("plt")
    usr <- par("usr")
    rscale <- (((usr[2] - usr[1])/(usr[4] - usr[3]))
                * ((fin[2] - mai[1] - mai[3]) / (fin[1] - mai[2] - mai[4])))

    xgrid <- 10^seq(usr[1], usr[2], len=100)
    lines(log10(xgrid), (1 + sqrt(xgrid))^2, col=1)
    symbols(x, y, circles=r * rscale, inches=FALSE, fg=2, add=TRUE)
    #segments(x, y - r, x, y + r, col=2)
    points(x, y, pch=2, col=2, cex=.25)

    dev.off()
    })

