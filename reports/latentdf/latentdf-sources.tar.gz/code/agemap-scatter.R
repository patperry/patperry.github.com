# code/agemap-scatter.R

require("RColorBrewer")



agemap.scatter <- function(sex, age, y, filename, ylab = "y",
                           solid = TRUE, w = 3, h = 3, ..., annotate = NULL)
{
    pch.0 <- if (solid) 15 else 0
    alpha <- if (solid) "CC" else ""

    mar <- c(4,6.1,1,6.1) + .1
    mai <- mar * par("csi")

    f.col <- brewer.pal(5, "Blues")[4]
    m.col <- brewer.pal(5, "Greens")[4]

    s.col <- paste(c(m.col, f.col), alpha, sep="")
    col <- s.col[1 + as.numeric(sex == "F")]


    if (!is.null(filename)) {
        pdf(filename,
            width=sum(w, mai[c(2,4)]),
            height=sum(h, mai[c(1,3)]))
    }
    par(mar=mar)
    par(ps=10)
    par(las=1)
    plot(age, y, t="p",
         pch=ifelse(sex == "F", 1, 2) + pch.0,
         col=col, xlab="Age (mo.)", ylab=ylab, axes=FALSE, ...)
    box()
    axis(1, at=c(1, 6, 16, 24), labels=TRUE)
    axis(2, labels=TRUE)
    axis(3, at=c(1, 6, 16, 24), labels=FALSE)
    axis(4, labels=FALSE)

    if (!is.null(annotate)) {
        annotate()
    }

    usr <- par("usr")
    cxy <- par("cxy")
    legend.x <- usr[2] + 3 * cxy[1]
    legend.y <- usr[3]
    legend(legend.x, legend.y, xjust=0, yjust=0, xpd=TRUE, bty="n",
           legend=c("Female", "Male"), title="Sex", title.adj=0,
           text.width=strwidth("Female"),
           pch=c(1,2) + pch.0, col=c(f.col, m.col))
    if (!is.null(filename)) {
        dev.off()
    }
}



agemap.scatter2 <- function(sex, age, x, y, filename, xlab = "x", ylab = "y",
                            solid = TRUE, w = 3, h = w, ..., annotate = NULL) {
    pch.0 <- if (solid) 15 else 0
    alpha <- if (solid) "CC" else ""

    mar <- c(4,6.1,1,6.1) + .1
    mai <- mar * par("csi")

    f.col <- brewer.pal(5, "Blues")[-(1)]
    m.col <- brewer.pal(5, "Greens")[-(1)]
    a.col <- paste(brewer.pal(5, "Greys")[-c(1)], alpha, sep="")
    s.col <- paste(c(m.col, f.col), alpha, sep="")
    col <- s.col[4 * as.numeric(sex == "F")
                 + as.numeric(as.factor(age))]


    pdf(filename,
        width=sum(w, mai[c(2,4)]),
        height=sum(h, mai[c(1,3)]))
    par(mar=mar)
    par(ps=10)
    par(las=1)
    plot(x, y, t="p",
         pch=ifelse(sex == "F", 1, 2) + pch.0,
         col=col, xlab=xlab, ylab=ylab, ...)
    axis(3, labels=FALSE)
    axis(4, labels=FALSE)

    usr <- par("usr")
    cxy <- par("cxy")
    legend.x <- usr[2] + 3 * cxy[1]
    legend.y1 <- usr[3] + 4 * cxy[2]
    legend.y2 <- usr[3]
    legend(legend.x, legend.y2, xjust=0, yjust=0, xpd=TRUE, bty="n",
           legend=c("Female", "Male"), title="Sex", title.adj=0,
           text.width=strwidth("Female"),
           pch=c(1,2) + pch.0, col=c(f.col[3], m.col[3]))
    legend(legend.x, legend.y1, xjust=0, yjust=0, xpd=TRUE, bty="n",
           title="Age (mo.)", title.adj=0,
           text.width=strwidth("Female"),
           legend=c("  1", "  6", "16", "24"),
           pch=15, col=a.col)

    if (!is.null(annotate)) {
        annotate()
    }

    dev.off()
}


